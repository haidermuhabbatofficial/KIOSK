using Microsoft.Win32;
using Microsoft.Extensions.Logging;

namespace KioskService;

/// <summary>
/// Applies well-known Windows Group-Policy-equivalent registry keys based on the
/// windowsLockdown flags in the device policy payload. Runs from the Windows
/// Service (LocalSystem) specifically because several of these keys live under
/// HKEY_LOCAL_MACHINE, which the interactive kiosk-client process — running as
/// whatever limited local user is signed into the kiosk — likely can't write.
///
/// These are the same registry values Windows itself reads for its built-in
/// Group Policy restrictions (System/Explorer policy keys) — nothing exotic, but
/// verify against a real Windows build before relying on them, since exact
/// enforcement can vary slightly by Windows version/edition.
/// </summary>
public class WindowsLockdownApplier
{
    private readonly ILogger<WindowsLockdownApplier> _logger;

    private const string SystemPoliciesPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System";
    private const string ExplorerPoliciesPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer";
    private const string UsbStorPath = @"SYSTEM\CurrentControlSet\Services\USBSTOR";

    public WindowsLockdownApplier(ILogger<WindowsLockdownApplier> logger)
    {
        _logger = logger;
    }

    public void Apply(WindowsLockdownConfig config)
    {
        try
        {
            SetPolicy(Registry.LocalMachine, SystemPoliciesPath, "DisableTaskMgr", config.DisableTaskManager);
            SetPolicy(Registry.LocalMachine, SystemPoliciesPath, "DisableRegistryTools", config.DisableRegistryEditor);
            // 1 = disable CMD entirely; 0 = allow. (The "allow but disable scripts" value is 2 — not exposed here.)
            SetPolicy(Registry.LocalMachine, SystemPoliciesPath, "DisableCMD", config.DisableCommandPrompt);
            SetPolicy(Registry.LocalMachine, ExplorerPoliciesPath, "NoControlPanel", config.DisableControlPanel);
            SetPolicy(Registry.LocalMachine, ExplorerPoliciesPath, "NoRun", config.DisableRun);

            // USB mass storage: Start=4 disables the driver (device won't mount); Start=3 is the Windows default (on-demand).
            using var usbKey = Registry.LocalMachine.OpenSubKey(UsbStorPath, writable: true);
            usbKey?.SetValue("Start", config.BlockUsbStorage ? 4 : 3, RegistryValueKind.DWord);

            _logger.LogInformation("Applied Windows lockdown policy: {Config}", config);
        }
        catch (Exception ex)
        {
            // A failed lockdown write should never crash the watchdog loop — log and move on;
            // it'll retry on the next policy check.
            _logger.LogError(ex, "Failed to apply Windows lockdown policy (are we running as LocalSystem?).");
        }
    }

    private static void SetPolicy(RegistryKey root, string path, string valueName, bool enabled)
    {
        using var key = root.CreateSubKey(path, writable: true);
        if (enabled)
        {
            key.SetValue(valueName, 1, RegistryValueKind.DWord);
        }
        else
        {
            key.DeleteValue(valueName, throwOnMissingValue: false);
        }
    }
}

public class WindowsLockdownConfig
{
    public bool DisableTaskManager { get; set; }
    public bool DisableControlPanel { get; set; }
    public bool DisableRegistryEditor { get; set; }
    public bool DisableCommandPrompt { get; set; }
    public bool DisableRun { get; set; }
    public bool BlockUsbStorage { get; set; }

    public override string ToString() =>
        $"TaskMgr={DisableTaskManager}, ControlPanel={DisableControlPanel}, RegEdit={DisableRegistryEditor}, " +
        $"Cmd={DisableCommandPrompt}, Run={DisableRun}, Usb={BlockUsbStorage}";
}
