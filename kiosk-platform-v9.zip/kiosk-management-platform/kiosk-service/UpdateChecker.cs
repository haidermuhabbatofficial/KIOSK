using System.Diagnostics;
using System.Net.Http.Json;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KioskService;

public class ClientVersionInfo
{
    public string Version { get; set; } = string.Empty;
    public string InstallerUrl { get; set; } = string.Empty;
    public string Sha256 { get; set; } = string.Empty;
}

/// <summary>
/// Polls the management server for a newer published client version (spec §29),
/// downloads the installer, verifies its SHA-256 before touching msiexec, and runs
/// it silently. Runs from the Windows Service, not the kiosk client itself, so an
/// update can replace the running client process cleanly.
/// </summary>
public class UpdateChecker
{
    private readonly ILogger<UpdateChecker> _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly string _kioskClientExePath;

    public UpdateChecker(IConfiguration config, ILogger<UpdateChecker> logger, IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;
        _kioskClientExePath = Environment.ExpandEnvironmentVariables(
            config["KioskClient:ExecutablePath"] ?? throw new InvalidOperationException("KioskClient:ExecutablePath not configured"));
    }

    public async Task CheckAndApplyAsync(CancellationToken ct)
    {
        var deviceConfig = SharedDeviceConfig.TryLoad();
        if (deviceConfig is null)
        {
            _logger.LogDebug("Kiosk not yet registered — skipping update check.");
            return;
        }

        var currentVersion = File.Exists(_kioskClientExePath)
            ? FileVersionInfo.GetVersionInfo(_kioskClientExePath).FileVersion ?? "0.0.0.0"
            : "0.0.0.0";

        using var http = _httpClientFactory.CreateClient();
        http.BaseAddress = new Uri(deviceConfig.ServerUrl);
        http.DefaultRequestHeaders.Add("Authorization", $"Bearer {deviceConfig.DeviceToken}");

        ClientVersionInfo? latest;
        try
        {
            latest = await http.GetFromJsonAsync<ClientVersionInfo>("/api/updates/client/latest", ct);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Update check failed — will retry on the next interval.");
            return;
        }

        if (latest is null || string.IsNullOrEmpty(latest.Version) || latest.Version == currentVersion)
        {
            return; // already current, or server had nothing to report
        }

        _logger.LogInformation("New client version {Version} available (current: {Current}). Downloading…",
            latest.Version, currentVersion);

        var tempPath = Path.Combine(Path.GetTempPath(), $"KioskClientUpdate-{latest.Version}.msi");

        try
        {
            await using (var stream = await http.GetStreamAsync(latest.InstallerUrl, ct))
            await using (var file = File.Create(tempPath))
            {
                await stream.CopyToAsync(file, ct);
            }

            if (!VerifyHash(tempPath, latest.Sha256))
            {
                _logger.LogError("Update package hash mismatch for version {Version}. Refusing to install.", latest.Version);
                return;
            }

            _logger.LogInformation("Hash verified. Installing update silently…");
            var proc = Process.Start(new ProcessStartInfo("msiexec.exe", $"/i \"{tempPath}\" /qn /norestart")
            {
                UseShellExecute = true,
            })!;
            await proc.WaitForExitAsync(ct);

            if (proc.ExitCode == 0)
            {
                _logger.LogInformation("Update to {Version} completed. The watchdog will relaunch the client.", latest.Version);
            }
            else
            {
                _logger.LogError("Update installer exited with code {Code}.", proc.ExitCode);
            }
        }
        finally
        {
            if (File.Exists(tempPath)) File.Delete(tempPath);
        }
    }

    private static bool VerifyHash(string filePath, string expectedSha256)
    {
        using var sha256 = SHA256.Create();
        using var stream = File.OpenRead(filePath);
        var hash = Convert.ToHexString(sha256.ComputeHash(stream));
        return string.Equals(hash, expectedSha256, StringComparison.OrdinalIgnoreCase);
    }
}
