using KioskService;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "KioskManagementService";
});

builder.Services.AddHttpClient();
builder.Services.AddSingleton<ProcessWatchdog>();
builder.Services.AddSingleton<UpdateChecker>();
builder.Services.AddSingleton<WindowsLockdownApplier>();
builder.Services.AddSingleton<LockdownPolicyChecker>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();
