using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace KioskService;

public class DevicePolicyResponse
{
    public WindowsLockdownConfig? WindowsLockdown { get; set; }
}

/// <summary>
/// Polls the same device policy endpoint the kiosk client uses (GET /api/kiosks/:id/policy),
/// but only cares about the windowsLockdown section — everything else (website rules, menu,
/// applications) is the client's concern, not the service's.
/// </summary>
public class LockdownPolicyChecker
{
    private readonly ILogger<LockdownPolicyChecker> _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly WindowsLockdownApplier _applier;

    public LockdownPolicyChecker(
        ILogger<LockdownPolicyChecker> logger,
        IHttpClientFactory httpClientFactory,
        WindowsLockdownApplier applier)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;
        _applier = applier;
    }

    public async Task CheckAndApplyAsync(CancellationToken ct)
    {
        var deviceConfig = SharedDeviceConfig.TryLoad();
        if (deviceConfig is null) return;

        using var http = _httpClientFactory.CreateClient();
        http.BaseAddress = new Uri(deviceConfig.ServerUrl);
        http.DefaultRequestHeaders.Add("Authorization", $"Bearer {deviceConfig.DeviceToken}");

        try
        {
            // since=0 forces the server to always return the full policy (it only omits
            // the body when the caller's version is already current) rather than needing
            // a separate lockdown-only endpoint.
            var policy = await http.GetFromJsonAsync<DevicePolicyResponse>(
                $"/api/kiosks/{deviceConfig.KioskId}/policy?since=0",
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true },
                ct);

            if (policy?.WindowsLockdown is not null)
            {
                _applier.Apply(policy.WindowsLockdown);
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Lockdown policy check failed — will retry on the next interval.");
        }
    }
}
