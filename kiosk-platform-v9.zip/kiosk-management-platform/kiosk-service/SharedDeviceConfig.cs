using System.Text.Json;

namespace KioskService;

public class SharedDeviceConfig
{
    public string ServerUrl { get; set; } = string.Empty;
    public string KioskId { get; set; } = string.Empty;
    public string DeviceToken { get; set; } = string.Empty;

    private const string ConfigPath = @"%PROGRAMDATA%\KioskClient\config.json";

    /// <summary>Returns null if the kiosk hasn't completed first-run registration yet.</summary>
    public static SharedDeviceConfig? TryLoad()
    {
        var path = Environment.ExpandEnvironmentVariables(ConfigPath);
        if (!File.Exists(path)) return null;

        try
        {
            var config = JsonSerializer.Deserialize<SharedDeviceConfig>(File.ReadAllText(path));
            return string.IsNullOrEmpty(config?.DeviceToken) ? null : config;
        }
        catch
        {
            return null;
        }
    }
}
