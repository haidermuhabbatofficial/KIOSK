using System.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KioskService;

/// <summary>
/// Detects that KioskClient.exe is not running and restarts it, with a rolling
/// rate limit so a client that crash-loops doesn't spin the machine forever
/// (spec §28: detect → restart → restore kiosk mode → reconnect → reapply policy;
/// the restart itself already reapplies the cached policy because MainWindow
/// reloads it from disk on every launch).
/// </summary>
public class ProcessWatchdog
{
    private readonly ILogger<ProcessWatchdog> _logger;
    private readonly string _executablePath;
    private readonly string _processName;
    private readonly int _maxRestartsPerHour;
    private readonly Queue<DateTime> _recentRestarts = new();

    public ProcessWatchdog(IConfiguration config, ILogger<ProcessWatchdog> logger)
    {
        _logger = logger;
        _executablePath = Environment.ExpandEnvironmentVariables(
            config["KioskClient:ExecutablePath"] ?? throw new InvalidOperationException("KioskClient:ExecutablePath not configured"));
        _processName = config["KioskClient:ProcessName"] ?? "KioskClient";
        _maxRestartsPerHour = int.Parse(config["KioskClient:MaxRestartAttemptsPerHour"] ?? "10");
    }

    public bool IsRunning() => Process.GetProcessesByName(_processName).Length > 0;

    public void EnsureRunning()
    {
        if (IsRunning()) return;

        PruneOldRestarts();
        if (_recentRestarts.Count >= _maxRestartsPerHour)
        {
            _logger.LogError(
                "KioskClient has crashed {Count} times in the last hour — pausing auto-restart. " +
                "This likely needs an admin to look at {LogPath}.",
                _recentRestarts.Count, @"%PROGRAMDATA%\KioskClient\logs\client-crash.log");
            return;
        }

        try
        {
            _logger.LogWarning("KioskClient is not running. Restarting from {Path}.", _executablePath);
            Process.Start(new ProcessStartInfo(_executablePath) { UseShellExecute = true });
            _recentRestarts.Enqueue(DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to restart KioskClient.");
        }
    }

    private void PruneOldRestarts()
    {
        var cutoff = DateTime.UtcNow.AddHours(-1);
        while (_recentRestarts.Count > 0 && _recentRestarts.Peek() < cutoff)
        {
            _recentRestarts.Dequeue();
        }
    }
}
