using Microsoft.Extensions.Configuration;

namespace KioskService;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly ProcessWatchdog _watchdog;
    private readonly UpdateChecker _updateChecker;
    private readonly LockdownPolicyChecker _lockdownChecker;
    private readonly TimeSpan _checkInterval;
    private readonly TimeSpan _updateCheckInterval;
    private readonly TimeSpan _lockdownCheckInterval;
    private DateTime _lastUpdateCheck = DateTime.MinValue;
    private DateTime _lastLockdownCheck = DateTime.MinValue;

    public Worker(
        ILogger<Worker> logger,
        ProcessWatchdog watchdog,
        UpdateChecker updateChecker,
        LockdownPolicyChecker lockdownChecker,
        IConfiguration config)
    {
        _logger = logger;
        _watchdog = watchdog;
        _updateChecker = updateChecker;
        _lockdownChecker = lockdownChecker;
        _checkInterval = TimeSpan.FromSeconds(
            int.Parse(config["KioskClient:RestartCheckIntervalSeconds"] ?? "5"));
        _updateCheckInterval = TimeSpan.FromMinutes(
            int.Parse(config["Update:CheckIntervalMinutes"] ?? "30"));
        _lockdownCheckInterval = TimeSpan.FromMinutes(
            int.Parse(config["Lockdown:CheckIntervalMinutes"] ?? "5"));
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("KioskManagementService started. Watching for KioskClient process.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                _watchdog.EnsureRunning();

                if (DateTime.UtcNow - _lastUpdateCheck >= _updateCheckInterval)
                {
                    _lastUpdateCheck = DateTime.UtcNow;
                    await _updateChecker.CheckAndApplyAsync(stoppingToken);
                }

                if (DateTime.UtcNow - _lastLockdownCheck >= _lockdownCheckInterval)
                {
                    _lastLockdownCheck = DateTime.UtcNow;
                    await _lockdownChecker.CheckAndApplyAsync(stoppingToken);
                }
            }
            catch (Exception ex)
            {
                // The watchdog loop itself must never die — that would silently disable
                // crash recovery, which is exactly the failure mode spec §28 exists to prevent.
                _logger.LogError(ex, "Unexpected error in watchdog loop.");
            }

            await Task.Delay(_checkInterval, stoppingToken);
        }
    }
}
