# Kiosk Management Platform — API Server

## What's implemented so far (real, working code — not stubs)

**Phase 1 — foundation**
- Full Prisma schema (`database/prisma/schema.prisma`) covering every table in spec §31,
  plus `Branch.exitPinHash` for the admin-exit PIN flow.
- Auth: login, refresh-token rotation with theft detection, Argon2id hashing.
- RBAC: `PermissionsGuard` (fails closed) + `BranchScopeGuard` (data-scoped by branch).
- Users, Branches modules — full CRUD, correctly scoped by role.
- Seed script: permissions, roles, demo branches/kiosks, one super-admin login.

**Phase 4 — kiosk client integration**
- Kiosks module: admin create + registration-code issuance, plus the device-facing
  endpoints the Windows client actually calls, all behind a **separate device JWT**
  (distinct secret/guard from admin tokens, ownership-checked against the route's
  kiosk id so one device's token can never touch another's data):
  - `POST /api/kiosks/register` — one-time-code registration (unauthenticated by design;
    the code itself is what's protected: short TTL, single use, revocable)
  - `POST /api/kiosks/:id/heartbeat`
  - `GET /api/kiosks/:id/policy?since=<version>`
  - `POST /api/kiosks/:id/website-logs`
  - `POST /api/kiosks/:id/verify-exit-pin`
- **Websites module** — the allowlist/blocklist rule engine's admin side: rule CRUD
  (domain/exact/wildcard, allow/block), categories with enable/disable, and — critically —
  every mutation bumps the affected kiosks' `policyVersion` so the client's poll picks up
  the change (miss this and a rule change silently never reaches devices).
- **Updates module** — publish/list client versions, plus the device-facing
  `GET /api/updates/client/latest` the Windows service polls for auto-updates (spec §29).

**Phase 8 — remote support (WebRTC)**
- Remote Sessions module: start/end lifecycle with a one-time session token
  (returned once, hashed at rest), 30-minute expiry, role-scoped start permission
  (Super Admin → any kiosk, Branch Admin → own branch, Kiosk Admin → only assigned
  kiosks), and audit logging on both start and end (with session duration).
- Remote Signaling gateway (`/ws/remote-support`, plain WebSocket via `WsAdapter` —
  not socket.io, so the .NET agent can speak it with `ClientWebSocket`): relays
  opaque SDP/ICE payloads between exactly two parties per session room. The server
  never touches the actual screen/input traffic — that flows peer-to-peer over the
  WebRTC DataChannel once signaling completes.
- Device-facing `GET /api/remote/sessions/pending/:kioskId` — the kiosk agent polls
  this with its own device JWT to discover a session waiting for it, rather than
  needing the admin's one-time token pushed to it out-of-band.

**Phase 6 — users/roles + applications**
- Roles module: list roles with their permissions, list all permission keys, and a
  permission-matrix update endpoint (`PATCH /api/roles/:id/permissions`) — SUPER_ADMIN's
  grants are hard-blocked from editing at the service layer, not just hidden in the UI.
- Applications module: allowlist CRUD, per-application version publishing (name,
  executable path, installer URL, SHA-256), approve/disable — every mutation bumps
  affected kiosks' `policyVersion`, same pattern as the websites module.

**Phase 7 — kiosk menu builder + audit log viewer**
- Kiosk Menus module: menu CRUD, menu-item CRUD, and kiosk assignment — assigning or
  editing a menu bumps that kiosk's `policyVersion` (menu items ride along in the same
  policy payload the client already polls for website rules).
- Audit Logs module: filterable, branch-scoped query endpoint (`action`, `userId`,
  `kioskId`, `result`, date range) over the `AuditLog` table every other module already
  writes to.

**Phase 9 — Policies, Settings, monitoring, remote-support extras**
- Policies module: versioned per-branch config for WINDOWS (lockdown toggles),
  SECURITY (session timeout, auto-restart, lock screen), and BROWSER
  (blocked-navigation behavior, downloads) scopes — folded into the device policy
  payload kiosks already poll for.
- Settings module: instance-wide key-value config (`SystemSetting` table),
  Super-Admin only.
- Metrics module: `/metrics` (Prometheus format) — request count/latency, blocked
  website attempts, failed auth attempts, policy syncs, online-kiosks and
  active-remote-sessions gauges.
- Remote sessions: `fileTransferAllowed`/`clipboardSyncAllowed` now returned from
  session start so both the admin viewer and kiosk agent know what's permitted.

## Not yet built

CI/CD's actual deployment step (build+test only, no auto-deploy), file-storage-
backed application/installer uploads (currently URL-referenced rather than
uploaded through the API), multi-region/HA database setup, alerting rules on top
of the Prometheus metrics (dashboards exist, alerts don't yet).

## Running it locally

```bash
docker compose -f ../infrastructure/docker/docker-compose.dev.yml up -d
npm install
cp .env.example .env   # set real JWT secrets before anything but local dev
npx prisma migrate dev --name init
npm run prisma:seed
npm run start:dev
```

Swagger docs: `http://localhost:3000/api/docs`. Seed login: `superadmin` / `ChangeMe123!`.

## Notable design decisions

- **Permissions are baked into the JWT**, not re-queried per request — a permission
  change takes effect on next login/refresh, not instantly. Add a short-TTL permission
  cache check if you need instant revocation.
- **Device tokens are a separate JWT type/secret from admin tokens** and carry zero
  permissions — a leaked device token can reach only that one kiosk's device-facing
  routes, never any admin endpoint.
- **A rule with no `branchId` is global** and affects every kiosk on creation/update/
  delete. Only `SUPER_ADMIN` may create global rules; branch/kiosk admins are restricted
  to their own branch by `assertCanWriteBranch`.
- **JSON casing**: NestJS speaks camelCase; the kiosk client's C# models default to
  PascalCase. `ApiClient` in the client explicitly configures `CamelCase` +
  case-insensitive `JsonSerializerOptions` for every call rather than relying on
  matching conventions by accident.
