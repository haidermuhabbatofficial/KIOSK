import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, WebSocket } from 'ws';
import { RemoteSessionsService } from './remote-sessions.service';

interface JoinMessage {
  sessionId: string;
  role: 'admin' | 'device';
  token?: string; // required for role: 'admin' — the one-time token from POST /api/remote/sessions
  deviceToken?: string; // required for role: 'device' — the kiosk's normal device JWT
}

interface RelayMessage {
  sessionId: string;
  payload: unknown; // SDP offer/answer, ICE candidate, or an app-level {type: 'frame'|'input'|...} message
}

interface SocketMeta {
  sessionId: string;
  role: 'admin' | 'device';
}

/**
 * Deliberately minimal: this gateway only relays opaque payloads between exactly
 * two parties (admin + device) per session room. It never inspects SDP/ICE content
 * and never touches the media itself — actual screen frames and input events flow
 * peer-to-peer over the WebRTC DataChannel once signaling completes, not through
 * this server after that point. Spec §21/§34: server never becomes a permanent
 * relay for the actual remote-control traffic.
 */
@WebSocketGateway({ path: '/ws/remote-support' })
export class RemoteSignalingGateway implements OnGatewayConnection, OnGatewayDisconnect {
  private readonly logger = new Logger(RemoteSignalingGateway.name);

  @WebSocketServer()
  server: Server;

  // sessionId -> { admin?: WebSocket, device?: WebSocket }
  private rooms = new Map<string, { admin?: WebSocket; device?: WebSocket }>();
  private socketMeta = new WeakMap<WebSocket, SocketMeta>();

  constructor(
    private readonly remoteSessionsService: RemoteSessionsService,
    private readonly jwtService: JwtService,
  ) {}

  handleConnection(client: WebSocket) {
    // Nothing to do until the client sends a 'join' message — the WsAdapter gives
    // us no HTTP request context here to authenticate up front, so auth happens
    // per-message on 'join' instead.
  }

  handleDisconnect(client: WebSocket) {
    const meta = this.socketMeta.get(client);
    if (!meta) return;

    const room = this.rooms.get(meta.sessionId);
    if (!room) return;

    room[meta.role] = undefined;
    const other = meta.role === 'admin' ? room.device : room.admin;
    other?.send(JSON.stringify({ event: 'peer-disconnected' }));

    if (!room.admin && !room.device) {
      this.rooms.delete(meta.sessionId);
    }
  }

  @SubscribeMessage('join')
  async handleJoin(@ConnectedSocket() client: WebSocket, @MessageBody() msg: JoinMessage) {
    const { sessionId, role } = msg;

    if (role === 'admin') {
      if (!msg.token) return this.reject(client, 'Missing session token');
      const session = await this.remoteSessionsService.validateToken(sessionId, msg.token);
      if (!session) return this.reject(client, 'Invalid or expired session token');
    } else {
      if (!msg.deviceToken) return this.reject(client, 'Missing device token');
      let payload: { sub: string; type: string };
      try {
        payload = await this.jwtService.verifyAsync(msg.deviceToken, {
          secret: process.env.JWT_DEVICE_SECRET ?? process.env.JWT_ACCESS_SECRET,
        });
      } catch {
        return this.reject(client, 'Invalid device token');
      }
      const session = await this.remoteSessionsService.findPendingForKiosk(payload.sub);
      if (!session || session.id !== sessionId) {
        return this.reject(client, 'No matching session for this device');
      }
    }

    const room = this.rooms.get(sessionId) ?? {};
    room[role] = client;
    this.rooms.set(sessionId, room);
    this.socketMeta.set(client, { sessionId, role });

    client.send(JSON.stringify({ event: 'joined', role }));

    if (room.admin && room.device) {
      await this.remoteSessionsService.markActive(sessionId);
      room.admin.send(JSON.stringify({ event: 'peer-ready' }));
      room.device.send(JSON.stringify({ event: 'peer-ready' }));
      this.logger.log(`Remote session ${sessionId} is now active (both peers connected).`);
    }
  }

  /** Relays an opaque signaling or data payload to the other party in the same session. */
  @SubscribeMessage('signal')
  handleSignal(@ConnectedSocket() client: WebSocket, @MessageBody() msg: RelayMessage) {
    const meta = this.socketMeta.get(client);
    if (!meta || meta.sessionId !== msg.sessionId) return;

    const room = this.rooms.get(msg.sessionId);
    const target = meta.role === 'admin' ? room?.device : room?.admin;
    target?.send(JSON.stringify({ event: 'signal', payload: msg.payload }));
  }

  @SubscribeMessage('end')
  handleEnd(@ConnectedSocket() client: WebSocket, @MessageBody() msg: { sessionId: string }) {
    const room = this.rooms.get(msg.sessionId);
    room?.admin?.send(JSON.stringify({ event: 'ended' }));
    room?.device?.send(JSON.stringify({ event: 'ended' }));
    room?.admin?.close();
    room?.device?.close();
    this.rooms.delete(msg.sessionId);
  }

  private reject(client: WebSocket, reason: string) {
    client.send(JSON.stringify({ event: 'rejected', reason }));
    client.close();
  }
}
