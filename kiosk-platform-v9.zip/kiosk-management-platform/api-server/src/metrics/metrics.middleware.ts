import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { MetricsService } from './metrics.service';

@Injectable()
export class MetricsMiddleware implements NestMiddleware {
  constructor(private readonly metrics: MetricsService) {}

  use(req: Request, res: Response, next: NextFunction) {
    const start = process.hrtime.bigint();

    res.on('finish', () => {
      // Route path (e.g. "/api/kiosks/:id") rather than the raw URL, so per-kiosk
      // requests don't create a distinct time series per kiosk id.
      const path = req.route?.path ?? req.path;
      const durationSeconds = Number(process.hrtime.bigint() - start) / 1e9;

      this.metrics.httpRequestsTotal.inc({ method: req.method, path, status: res.statusCode });
      this.metrics.httpRequestDurationSeconds.observe({ method: req.method, path }, durationSeconds);
    });

    next();
  }
}
