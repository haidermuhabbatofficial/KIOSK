import { Injectable, OnModuleInit } from '@nestjs/common';
import * as client from 'prom-client';

/**
 * A single shared registry so every module increments the same counters rather
 * than each owning its own prom-client instance. Spec §38's metric list:
 * API requests/latency are covered by the HTTP middleware in metrics.middleware.ts;
 * the rest are incremented directly by the services that know when they happen
 * (blocked website attempts in kiosks.service.ts, remote sessions in
 * remote-sessions.service.ts, failed logins in auth.service.ts).
 */
@Injectable()
export class MetricsService implements OnModuleInit {
  public readonly registry = new client.Registry();

  public httpRequestsTotal!: client.Counter<string>;
  public httpRequestDurationSeconds!: client.Histogram<string>;
  public onlineKiosksGauge!: client.Gauge<string>;
  public activeRemoteSessionsGauge!: client.Gauge<string>;
  public blockedWebsiteAttemptsTotal!: client.Counter<string>;
  public failedAuthAttemptsTotal!: client.Counter<string>;
  public policySyncsTotal!: client.Counter<string>;

  onModuleInit() {
    client.collectDefaultMetrics({ register: this.registry });

    this.httpRequestsTotal = new client.Counter({
      name: 'http_requests_total',
      help: 'Total HTTP requests handled',
      labelNames: ['method', 'path', 'status'],
      registers: [this.registry],
    });

    this.httpRequestDurationSeconds = new client.Histogram({
      name: 'http_request_duration_seconds',
      help: 'HTTP request latency in seconds',
      labelNames: ['method', 'path'],
      buckets: [0.01, 0.05, 0.1, 0.3, 0.5, 1, 2, 5],
      registers: [this.registry],
    });

    this.onlineKiosksGauge = new client.Gauge({
      name: 'kiosks_online',
      help: 'Number of kiosks currently reporting ONLINE status',
      registers: [this.registry],
    });

    this.activeRemoteSessionsGauge = new client.Gauge({
      name: 'remote_sessions_active',
      help: 'Number of remote support sessions currently PENDING or ACTIVE',
      registers: [this.registry],
    });

    this.blockedWebsiteAttemptsTotal = new client.Counter({
      name: 'blocked_website_attempts_total',
      help: 'Total website navigation attempts blocked by policy',
      registers: [this.registry],
    });

    this.failedAuthAttemptsTotal = new client.Counter({
      name: 'failed_auth_attempts_total',
      help: 'Total failed login attempts',
      registers: [this.registry],
    });

    this.policySyncsTotal = new client.Counter({
      name: 'policy_syncs_total',
      help: 'Total policy fetches served to kiosk devices',
      registers: [this.registry],
    });
  }
}
