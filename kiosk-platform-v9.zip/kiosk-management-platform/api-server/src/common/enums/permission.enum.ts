// Permission keys correspond 1:1 with the Permission.key rows seeded in the database.
// A role is authorized for an action only if one of its assigned permissions matches.
export enum Permission {
  DASHBOARD_VIEW = 'dashboard.view',

  BRANCHES_VIEW = 'branches.view',
  BRANCHES_MANAGE = 'branches.manage',

  KIOSKS_VIEW = 'kiosks.view',
  KIOSKS_MANAGE = 'kiosks.manage',
  KIOSKS_RESTART = 'kiosks.restart',
  KIOSKS_SHUTDOWN = 'kiosks.shutdown',
  KIOSKS_LOCK = 'kiosks.lock',

  USERS_VIEW = 'users.view',
  USERS_MANAGE = 'users.manage',

  ROLES_MANAGE = 'roles.manage',

  WEBSITES_VIEW = 'websites.view',
  WEBSITES_MANAGE = 'websites.manage',

  APPLICATIONS_VIEW = 'applications.view',
  APPLICATIONS_MANAGE = 'applications.manage',

  KIOSK_MENU_VIEW = 'kiosk_menu.view',
  KIOSK_MENU_MANAGE = 'kiosk_menu.manage',

  DOWNLOADS_VIEW = 'downloads.view',

  POLICIES_VIEW = 'policies.view',
  POLICIES_MANAGE = 'policies.manage',

  REMOTE_SUPPORT_VIEW = 'remote_support.view',
  REMOTE_SUPPORT_START = 'remote_support.start',

  LOGS_VIEW = 'logs.view',

  CONFIGURATION_MANAGE = 'configuration.manage',
  UPDATES_MANAGE = 'updates.manage',
}
