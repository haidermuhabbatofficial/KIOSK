import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

@Injectable()
export class DeviceOwnershipGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const device = request.user as { kioskId: string } | undefined;
    const routeKioskId = request.params?.id ?? request.params?.kioskId;

    if (!device || device.kioskId !== routeKioskId) {
      throw new ForbiddenException('Device token does not match the target kiosk');
    }
    return true;
  }
}
