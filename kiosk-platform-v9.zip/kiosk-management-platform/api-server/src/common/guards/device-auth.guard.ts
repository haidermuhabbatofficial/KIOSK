import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class DeviceAuthGuard extends AuthGuard('jwt-device') {}
