import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { RoleName } from '../enums/role.enum';
import { AuthenticatedUser } from '../decorators/current-user.decorator';

/**
 * A SUPER_ADMIN may act on any branch. A BRANCH_ADMIN or KIOSK_ADMIN may only act
 * on their own assigned branch. Applies to routes where the target branch id is
 * present as :branchId in the route params or branchId in the request body.
 *
 * This guard enforces data-scope, not feature-scope — pair it with PermissionsGuard.
 */
@Injectable()
export class BranchScopeGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user: AuthenticatedUser = request.user;

    if (!user) {
      throw new ForbiddenException('Not authenticated');
    }

    if (user.roles.includes(RoleName.SUPER_ADMIN)) {
      return true;
    }

    const targetBranchId: string | undefined =
      request.params?.branchId ?? request.body?.branchId ?? request.query?.branchId;

    // No branch on the request (e.g. list endpoints) — the service layer is
    // responsible for filtering results to the caller's branch in that case.
    if (!targetBranchId) {
      return true;
    }

    if (targetBranchId !== user.branchId) {
      throw new ForbiddenException('You do not have access to this branch');
    }

    return true;
  }
}
