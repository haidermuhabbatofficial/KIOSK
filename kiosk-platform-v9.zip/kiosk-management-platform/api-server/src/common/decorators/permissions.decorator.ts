import { SetMetadata } from '@nestjs/common';
import { Permission } from '../enums/permission.enum';

export const PERMISSIONS_KEY = 'permissions';

/**
 * Marks a route as requiring one or more permissions.
 * The user must hold at least one of the listed permissions (OR semantics).
 * Combine with @RequireAll() semantics inside the guard if AND semantics are ever needed.
 */
export const RequirePermissions = (...permissions: Permission[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);
