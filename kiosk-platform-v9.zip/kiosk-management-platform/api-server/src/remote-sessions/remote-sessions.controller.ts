import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RemoteSessionsService } from './remote-sessions.service';
import { StartRemoteSessionDto } from './dto/start-remote-session.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { DeviceAuthGuard } from '../common/guards/device-auth.guard';
import { DeviceOwnershipGuard } from '../common/guards/device-ownership.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('remote-sessions')
@Controller('api/remote/sessions')
export class RemoteSessionsController {
  constructor(private readonly remoteSessionsService: RemoteSessionsService) {}

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post()
  @RequirePermissions(Permission.REMOTE_SUPPORT_START)
  start(@Body() dto: StartRemoteSessionDto, @CurrentUser() user: AuthenticatedUser) {
    return this.remoteSessionsService.start(dto, user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Get()
  @RequirePermissions(Permission.REMOTE_SUPPORT_VIEW)
  findActive(@CurrentUser() user: AuthenticatedUser) {
    return this.remoteSessionsService.findActive(user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Delete(':id')
  @RequirePermissions(Permission.REMOTE_SUPPORT_START)
  end(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.remoteSessionsService.end(id, user);
  }

  // Device-facing: the kiosk agent polls this (its own device JWT) to discover
  // that an admin has started a session targeting it — no session token needed
  // here, since the device JWT already proves which kiosk is asking.
  @UseGuards(DeviceAuthGuard, DeviceOwnershipGuard)
  @Get('pending/:kioskId')
  findPending(@Param('kioskId') kioskId: string) {
    return this.remoteSessionsService.findPendingForKiosk(kioskId);
  }
}
