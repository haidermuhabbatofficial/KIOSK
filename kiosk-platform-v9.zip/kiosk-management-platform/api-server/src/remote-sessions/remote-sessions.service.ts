import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { StartRemoteSessionDto } from './dto/start-remote-session.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';
import { MetricsService } from '../metrics/metrics.service';

const SESSION_TTL_MINUTES = 30;

@Injectable()
export class RemoteSessionsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly metrics: MetricsService,
  ) {}

  private hashToken(token: string) {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Spec §22: Super Admin -> any kiosk; Branch Admin -> kiosks in their branch;
   * Kiosk Admin -> only kiosks explicitly assigned to them; User -> never.
   */
  private async assertCanControl(requester: AuthenticatedUser, kioskId: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) return;

    const kiosk = await this.prisma.kiosk.findUniqueOrThrow({ where: { id: kioskId } });

    if (requester.roles.includes(RoleName.BRANCH_ADMIN)) {
      if (kiosk.branchId !== requester.branchId) {
        throw new ForbiddenException('This kiosk is outside your branch');
      }
      return;
    }

    if (requester.roles.includes(RoleName.KIOSK_ADMIN)) {
      const assigned = await this.prisma.kioskAdminAssignment.findUnique({
        where: { userId_kioskId: { userId: requester.id, kioskId } },
      });
      if (!assigned) throw new ForbiddenException('This kiosk is not assigned to you');
      return;
    }

    throw new ForbiddenException('Your role cannot start remote support sessions');
  }

  /**
   * Creates a PENDING session with a random one-time token (spec §21). The token is
   * only ever returned once, here, to the admin who started the session — the
   * WebSocket gateway checks its hash, never the plaintext, and the kiosk-side agent
   * receives it out-of-band by polling for a pending session, never by admin's token
   * being sent through this endpoint's response.
   */
  async start(dto: StartRemoteSessionDto, requester: AuthenticatedUser) {
    await this.assertCanControl(requester, dto.kioskId);

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + SESSION_TTL_MINUTES * 60 * 1000);

    const session = await this.prisma.remoteSession.create({
      data: {
        kioskId: dto.kioskId,
        adminId: requester.id,
        tokenHash: this.hashToken(token),
        status: 'PENDING',
        expiresAt,
        fileTransferAllowed: dto.fileTransferAllowed ?? false,
        clipboardSyncAllowed: dto.clipboardSyncAllowed ?? false,
      },
    });

    await this.prisma.auditLog.create({
      data: {
        userId: requester.id,
        kioskId: dto.kioskId,
        action: 'remote_support.session_started',
        entityType: 'RemoteSession',
        entityId: session.id,
        result: 'SUCCESS',
      },
    });

    // Plaintext token is returned exactly once — the admin's browser uses it
    // to join the signaling channel as this session's controller.
    this.refreshActiveSessionsGauge();
    return {
      sessionId: session.id,
      token,
      expiresAt: session.expiresAt,
      fileTransferAllowed: session.fileTransferAllowed,
      clipboardSyncAllowed: session.clipboardSyncAllowed,
    };
  }

  /** Called by the kiosk agent to discover a session waiting for it, using its device token for auth. */
  async findPendingForKiosk(kioskId: string) {
    return this.prisma.remoteSession.findFirst({
      where: { kioskId, status: { in: ['PENDING', 'ACTIVE'] }, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findActive(requester: AuthenticatedUser) {
    const branchScope = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? {}
      : { kiosk: { branchId: requester.branchId ?? '__none__' } };

    return this.prisma.remoteSession.findMany({
      where: { ...branchScope, status: { in: ['PENDING', 'ACTIVE'] } },
      include: { kiosk: true, admin: { select: { name: true, username: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async end(id: string, requester: AuthenticatedUser) {
    const session = await this.prisma.remoteSession.findUnique({ where: { id } });
    if (!session) throw new NotFoundException('Session not found');

    await this.assertCanControl(requester, session.kioskId);

    await this.prisma.remoteSession.update({
      where: { id },
      data: { status: 'ENDED', endedAt: new Date() },
    });
    this.refreshActiveSessionsGauge();

    const durationMinutes = session.startedAt
      ? Math.round((Date.now() - session.startedAt.getTime()) / 60000)
      : 0;

    await this.prisma.auditLog.create({
      data: {
        userId: requester.id,
        kioskId: session.kioskId,
        action: 'remote_support.session_ended',
        entityType: 'RemoteSession',
        entityId: session.id,
        result: 'SUCCESS',
        metadata: { durationMinutes },
      },
    });

    return { ended: true };
  }

  private refreshActiveSessionsGauge() {
    this.prisma.remoteSession.count({ where: { status: { in: ['PENDING', 'ACTIVE'] } } }).then((count) => {
      this.metrics.activeRemoteSessionsGauge.set(count);
    });
  }

  /** Used only by the signaling gateway — validates a presented token against the stored hash. */
  async validateToken(sessionId: string, token: string) {
    const session = await this.prisma.remoteSession.findUnique({ where: { id: sessionId } });
    if (!session) return null;
    if (session.status === 'ENDED' || session.status === 'REVOKED') return null;
    if (session.expiresAt < new Date()) return null;
    if (session.tokenHash !== this.hashToken(token)) return null;
    return session;
  }

  async markActive(sessionId: string) {
    await this.prisma.remoteSession.updateMany({
      where: { id: sessionId, status: 'PENDING' },
      data: { status: 'ACTIVE', startedAt: new Date() },
    });
  }
}
