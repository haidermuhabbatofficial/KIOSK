import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsOptional, IsUUID } from 'class-validator';

export class StartRemoteSessionDto {
  @ApiProperty()
  @IsUUID()
  kioskId: string;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  fileTransferAllowed?: boolean;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  clipboardSyncAllowed?: boolean;
}
