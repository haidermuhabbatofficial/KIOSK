import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { RemoteSessionsService } from './remote-sessions.service';
import { RemoteSessionsController } from './remote-sessions.controller';
import { RemoteSignalingGateway } from '../remote-signaling/remote-signaling.gateway';

@Module({
  imports: [JwtModule.register({})],
  controllers: [RemoteSessionsController],
  providers: [RemoteSessionsService, RemoteSignalingGateway],
  exports: [RemoteSessionsService],
})
export class RemoteSessionsModule {}
