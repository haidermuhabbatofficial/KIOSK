import { Body, Controller, Delete, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { KioskMenusService } from './kiosk-menus.service';
import { CreateKioskMenuDto, CreateMenuItemDto } from './dto/kiosk-menu.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('kiosk-menus')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('api/kiosk-menus')
export class KioskMenusController {
  constructor(private readonly kioskMenusService: KioskMenusService) {}

  @Post()
  @RequirePermissions(Permission.KIOSK_MENU_MANAGE)
  create(@Body() dto: CreateKioskMenuDto, @CurrentUser() user: AuthenticatedUser) {
    return this.kioskMenusService.create(dto, user);
  }

  @Get()
  @RequirePermissions(Permission.KIOSK_MENU_VIEW)
  findAll(@CurrentUser() user: AuthenticatedUser) {
    return this.kioskMenusService.findAll(user);
  }

  @Get(':id')
  @RequirePermissions(Permission.KIOSK_MENU_VIEW)
  findOne(@Param('id') id: string) {
    return this.kioskMenusService.findOne(id);
  }

  @Post(':id/items')
  @RequirePermissions(Permission.KIOSK_MENU_MANAGE)
  addItem(@Param('id') id: string, @Body() dto: CreateMenuItemDto, @CurrentUser() user: AuthenticatedUser) {
    return this.kioskMenusService.addItem(id, dto, user);
  }

  @Delete(':id/items/:itemId')
  @RequirePermissions(Permission.KIOSK_MENU_MANAGE)
  removeItem(@Param('id') id: string, @Param('itemId') itemId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.kioskMenusService.removeItem(id, itemId, user);
  }

  @Post(':id/assign/:kioskId')
  @RequirePermissions(Permission.KIOSK_MENU_MANAGE)
  assign(@Param('id') id: string, @Param('kioskId') kioskId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.kioskMenusService.assignToKiosk(id, kioskId, user);
  }
}
