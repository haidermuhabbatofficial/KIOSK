import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsInt, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateKioskMenuDto {
  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty({ example: 'Default Menu' })
  @IsString()
  name: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  theme?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  backgroundUrl?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  logoUrl?: string;
}

export class CreateMenuItemDto {
  @ApiProperty({ example: 'Student Portal' })
  @IsString()
  label: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  iconUrl?: string;

  @ApiProperty({ enum: ['WEBSITE', 'APPLICATION'] })
  @IsIn(['WEBSITE', 'APPLICATION'])
  targetType: 'WEBSITE' | 'APPLICATION';

  @ApiProperty({ description: 'A URL for WEBSITE items, or an application id for APPLICATION items' })
  @IsString()
  targetValue: string;

  @ApiProperty({ required: false, default: 0 })
  @IsOptional()
  @IsInt()
  sortOrder?: number;
}
