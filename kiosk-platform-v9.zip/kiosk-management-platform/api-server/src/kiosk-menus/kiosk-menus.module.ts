import { Module } from '@nestjs/common';
import { KioskMenusService } from './kiosk-menus.service';
import { KioskMenusController } from './kiosk-menus.controller';

@Module({
  controllers: [KioskMenusController],
  providers: [KioskMenusService],
})
export class KioskMenusModule {}
