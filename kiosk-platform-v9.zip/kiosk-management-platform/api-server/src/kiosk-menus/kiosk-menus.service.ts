import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateKioskMenuDto, CreateMenuItemDto } from './dto/kiosk-menu.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class KioskMenusService {
  constructor(private readonly prisma: PrismaService) {}

  private assertCanWriteBranch(requester: AuthenticatedUser, branchId: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) return;
    if (branchId !== requester.branchId) {
      throw new ForbiddenException('You can only manage kiosk menus for your own branch');
    }
  }

  async create(dto: CreateKioskMenuDto, requester: AuthenticatedUser) {
    this.assertCanWriteBranch(requester, dto.branchId);
    return this.prisma.kioskMenu.create({
      data: {
        branchId: dto.branchId,
        name: dto.name,
        theme: dto.theme,
        backgroundUrl: dto.backgroundUrl,
        logoUrl: dto.logoUrl,
      },
    });
  }

  async findAll(requester: AuthenticatedUser) {
    const where = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? {}
      : { branchId: requester.branchId ?? '__none__' };

    return this.prisma.kioskMenu.findMany({
      where,
      include: { items: { orderBy: { sortOrder: 'asc' } }, kiosks: true },
    });
  }

  async findOne(id: string) {
    const menu = await this.prisma.kioskMenu.findUnique({
      where: { id },
      include: { items: { orderBy: { sortOrder: 'asc' } }, kiosks: true },
    });
    if (!menu) throw new NotFoundException('Kiosk menu not found');
    return menu;
  }

  async addItem(menuId: string, dto: CreateMenuItemDto, requester: AuthenticatedUser) {
    const menu = await this.findOne(menuId);
    this.assertCanWriteBranch(requester, menu.branchId);

    const item = await this.prisma.kioskMenuItem.create({
      data: {
        menuId,
        label: dto.label,
        iconUrl: dto.iconUrl,
        targetType: dto.targetType,
        targetValue: dto.targetValue,
        sortOrder: dto.sortOrder ?? 0,
      },
    });

    await this.bumpAssignedKiosks(menuId);
    return item;
  }

  async removeItem(menuId: string, itemId: string, requester: AuthenticatedUser) {
    const menu = await this.findOne(menuId);
    this.assertCanWriteBranch(requester, menu.branchId);

    await this.prisma.kioskMenuItem.delete({ where: { id: itemId } });
    await this.bumpAssignedKiosks(menuId);
    return { deleted: true };
  }

  /** Assigns a menu to a kiosk (spec §7 — one menu per kiosk) and bumps that kiosk's policy version. */
  async assignToKiosk(menuId: string, kioskId: string, requester: AuthenticatedUser) {
    const menu = await this.findOne(menuId);
    const kiosk = await this.prisma.kiosk.findUniqueOrThrow({ where: { id: kioskId } });

    this.assertCanWriteBranch(requester, menu.branchId);
    if (kiosk.branchId !== menu.branchId) {
      throw new ForbiddenException('A kiosk can only use a menu from its own branch');
    }

    return this.prisma.kiosk.update({
      where: { id: kioskId },
      data: { kioskMenuId: menuId, policyVersion: { increment: 1 } },
    });
  }

  private async bumpAssignedKiosks(menuId: string) {
    await this.prisma.kiosk.updateMany({
      where: { kioskMenuId: menuId },
      data: { policyVersion: { increment: 1 } },
    });
  }
}
