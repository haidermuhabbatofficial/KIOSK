import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { UpdatesService } from './updates.service';
import { PublishClientVersionDto } from './dto/publish-client-version.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { DeviceAuthGuard } from '../common/guards/device-auth.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';

@ApiTags('updates')
@Controller('api/updates')
export class UpdatesController {
  constructor(private readonly updatesService: UpdatesService) {}

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post('client')
  @RequirePermissions(Permission.UPDATES_MANAGE)
  publish(@Body() dto: PublishClientVersionDto) {
    return this.updatesService.publish(dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Get('client')
  @RequirePermissions(Permission.UPDATES_MANAGE)
  findAll() {
    return this.updatesService.findAll();
  }

  // Device-facing: kiosk-service polls this with its device token (spec §29).
  @UseGuards(DeviceAuthGuard)
  @Get('client/latest')
  findLatest() {
    return this.updatesService.findLatestActive();
  }
}
