import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PublishClientVersionDto } from './dto/publish-client-version.dto';

@Injectable()
export class UpdatesService {
  constructor(private readonly prisma: PrismaService) {}

  async publish(dto: PublishClientVersionDto) {
    // Deactivate prior versions so "latest active" is unambiguous — keeps history
    // for audit purposes (spec §29) without a separate "isLatest" flag to drift out of sync.
    await this.prisma.clientVersion.updateMany({ where: { isActive: true }, data: { isActive: false } });

    return this.prisma.clientVersion.create({
      data: {
        version: dto.version,
        installerUrl: dto.installerUrl,
        sha256: dto.sha256,
        releaseNotes: dto.releaseNotes,
        requiredVersion: dto.requiredVersion,
        isActive: true,
      },
    });
  }

  async findAll() {
    return this.prisma.clientVersion.findMany({ orderBy: { releaseDate: 'desc' } });
  }

  /** Called by kiosk-service's UpdateChecker — device-authenticated, read-only. */
  async findLatestActive() {
    const latest = await this.prisma.clientVersion.findFirst({ where: { isActive: true } });
    if (!latest) return null;
    return { version: latest.version, installerUrl: latest.installerUrl, sha256: latest.sha256 };
  }
}
