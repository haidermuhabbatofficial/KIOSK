import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class PublishClientVersionDto {
  @ApiProperty({ example: '1.1.0.0' })
  @IsString()
  version: string;

  @ApiProperty({ description: 'Publicly reachable URL the kiosk service can download the MSI from' })
  @IsString()
  installerUrl: string;

  @ApiProperty()
  @IsString()
  sha256: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  releaseNotes?: string;

  @ApiProperty({ required: false, description: 'Minimum version that must upgrade (for forced rollouts)' })
  @IsOptional()
  @IsString()
  requiredVersion?: string;
}
