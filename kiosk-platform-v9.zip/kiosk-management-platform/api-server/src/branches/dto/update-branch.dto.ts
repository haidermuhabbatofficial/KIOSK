import { PartialType, ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { CreateBranchDto } from './create-branch.dto';

export enum BranchStatusDto {
  ACTIVE = 'ACTIVE',
  DISABLED = 'DISABLED',
}

export class UpdateBranchDto extends PartialType(CreateBranchDto) {
  @ApiProperty({ enum: BranchStatusDto, required: false })
  @IsOptional()
  @IsEnum(BranchStatusDto)
  status?: BranchStatusDto;
}
