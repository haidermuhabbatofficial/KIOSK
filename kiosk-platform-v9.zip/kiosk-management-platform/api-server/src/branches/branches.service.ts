import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateBranchDto } from './dto/create-branch.dto';
import { UpdateBranchDto } from './dto/update-branch.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class BranchesService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateBranchDto) {
    const existing = await this.prisma.branch.findUnique({ where: { code: dto.code } });
    if (existing) throw new ConflictException('Branch code already exists');

    return this.prisma.branch.create({ data: dto });
  }

  /** Super admins see every branch; everyone else sees only their own. */
  async findAll(requester: AuthenticatedUser) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) {
      return this.prisma.branch.findMany({ where: { deletedAt: null } });
    }
    return this.prisma.branch.findMany({
      where: { deletedAt: null, id: requester.branchId ?? '__none__' },
    });
  }

  async findOne(id: string) {
    const branch = await this.prisma.branch.findUnique({ where: { id } });
    if (!branch || branch.deletedAt) throw new NotFoundException('Branch not found');
    return branch;
  }

  async update(id: string, dto: UpdateBranchDto) {
    await this.findOne(id);
    return this.prisma.branch.update({ where: { id }, data: dto });
  }

  async disable(id: string) {
    await this.findOne(id);
    return this.prisma.branch.update({ where: { id }, data: { status: 'DISABLED' } });
  }
}
