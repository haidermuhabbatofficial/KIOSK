import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private userInclude = {
    branch: true,
    userRoles: { include: { role: true } },
  } as const;

  async create(dto: CreateUserDto) {
    const existing = await this.prisma.user.findFirst({
      where: { OR: [{ username: dto.username }, { email: dto.email }] },
    });
    if (existing) {
      throw new ConflictException('Username or email already in use');
    }

    const passwordHash = await argon2.hash(dto.password, { type: argon2.argon2id });

    const roles = await this.prisma.role.findMany({ where: { name: { in: dto.roles } } });
    if (roles.length !== dto.roles.length) {
      throw new NotFoundException('One or more roles do not exist — seed roles first');
    }

    return this.prisma.user.create({
      data: {
        name: dto.name,
        username: dto.username,
        email: dto.email,
        passwordHash,
        branchId: dto.branchId,
        userRoles: {
          create: roles.map((role) => ({ roleId: role.id })),
        },
      },
      include: this.userInclude,
    });
  }

  /** Applies branch scoping: non-super-admins only ever see users in their own branch. */
  async findAll(requester: AuthenticatedUser) {
    const where = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? { deletedAt: null }
      : { deletedAt: null, branchId: requester.branchId };

    return this.prisma.user.findMany({ where, include: this.userInclude });
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({ where: { id }, include: this.userInclude });
    if (!user || user.deletedAt) throw new NotFoundException('User not found');
    return user;
  }

  async update(id: string, dto: UpdateUserDto) {
    await this.findOne(id);

    let roleUpdate = {};
    if (dto.roles) {
      const roles = await this.prisma.role.findMany({ where: { name: { in: dto.roles } } });
      roleUpdate = {
        userRoles: {
          deleteMany: {},
          create: roles.map((role) => ({ roleId: role.id })),
        },
      };
    }

    return this.prisma.user.update({
      where: { id },
      data: {
        name: dto.name,
        email: dto.email,
        branchId: dto.branchId,
        isActive: dto.isActive,
        ...roleUpdate,
      },
      include: this.userInclude,
    });
  }

  async softDelete(id: string) {
    await this.findOne(id);
    await this.prisma.user.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
  }
}
