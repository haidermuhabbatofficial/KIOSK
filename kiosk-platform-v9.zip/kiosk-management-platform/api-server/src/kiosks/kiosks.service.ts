import { BadRequestException, ConflictException, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import * as crypto from 'crypto';
import { HeartbeatDto } from './dto/heartbeat.dto';
import { WebsiteLogDto } from './dto/website-log.dto';
import { PoliciesService } from '../policies/policies.service';
import { MetricsService } from '../metrics/metrics.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateKioskDto } from './dto/create-kiosk.dto';
import { RegisterKioskDto } from './dto/register-kiosk.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

const REGISTRATION_CODE_TTL_MINUTES = 30;

@Injectable()
export class KiosksService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly policiesService: PoliciesService,
    private readonly metrics: MetricsService,
  ) {}

  /**
   * Long-lived, device-scoped token — distinct from admin JWTs. Carries only a
   * kiosk id and a fixed "device" role so a leaked device token can never be used
   * to reach admin endpoints (it doesn't carry any admin permissions to check).
   */
  private async issueDeviceToken(kioskId: string): Promise<string> {
    return this.jwtService.signAsync(
      { sub: kioskId, type: 'device' },
      { secret: process.env.JWT_DEVICE_SECRET ?? process.env.JWT_ACCESS_SECRET, expiresIn: '3650d' },
    );
  }

  async create(dto: CreateKioskDto) {
    const existing = await this.prisma.kiosk.findUnique({ where: { kioskCode: dto.kioskCode } });
    if (existing) throw new ConflictException('Kiosk code already exists');

    return this.prisma.kiosk.create({
      data: {
        kioskCode: dto.kioskCode,
        deviceName: dto.deviceName,
        branchId: dto.branchId,
      },
    });
  }

  /** Generates a short-lived, single-use registration code for a not-yet-installed kiosk. */
  async generateRegistrationCode(branchId: string) {
    const code = crypto.randomBytes(6).toString('hex').toUpperCase();
    const expiresAt = new Date(Date.now() + REGISTRATION_CODE_TTL_MINUTES * 60 * 1000);

    return this.prisma.registrationCode.create({
      data: { code, branchId, expiresAt },
    });
  }

  /** Called by the Windows installer/client on first run — not behind admin auth. */
  async registerDevice(dto: RegisterKioskDto) {
    const registrationCode = await this.prisma.registrationCode.findUnique({
      where: { code: dto.registrationCode },
    });

    if (!registrationCode) throw new NotFoundException('Invalid registration code');
    if (registrationCode.status !== 'ACTIVE') throw new BadRequestException('Registration code already used or revoked');
    if (registrationCode.expiresAt < new Date()) {
      await this.prisma.registrationCode.update({
        where: { id: registrationCode.id },
        data: { status: 'EXPIRED' },
      });
      throw new BadRequestException('Registration code has expired');
    }

    const kiosk = await this.prisma.kiosk.create({
      data: {
        kioskCode: `PENDING-${registrationCode.code}`,
        deviceName: `New Kiosk (${dto.macAddress})`,
        branchId: registrationCode.branchId,
        macAddress: dto.macAddress,
        windowsVersion: dto.windowsVersion,
        clientVersion: dto.clientVersion,
        ipAddress: dto.ipAddress,
        status: 'ACTIVE',
        onlineStatus: 'ONLINE',
        registrationCodeId: registrationCode.id,
      },
    });

    await this.prisma.registrationCode.update({
      where: { id: registrationCode.id },
      data: { status: 'USED', usedAt: new Date() },
    });

    const deviceToken = await this.issueDeviceToken(kiosk.id);

    return { id: kiosk.id, kioskCode: kiosk.kioskCode, deviceToken };
  }

  /** Super admins see all kiosks; branch admins see their branch; kiosk admins see only assigned kiosks. */
  async findAll(requester: AuthenticatedUser) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) {
      return this.prisma.kiosk.findMany({ where: { deletedAt: null } });
    }
    if (requester.roles.includes(RoleName.BRANCH_ADMIN)) {
      return this.prisma.kiosk.findMany({
        where: { deletedAt: null, branchId: requester.branchId ?? '__none__' },
      });
    }
    return this.prisma.kiosk.findMany({
      where: { deletedAt: null, adminAssignments: { some: { userId: requester.id } } },
    });
  }

  async findOne(id: string) {
    const kiosk = await this.prisma.kiosk.findUnique({ where: { id } });
    if (!kiosk || kiosk.deletedAt) throw new NotFoundException('Kiosk not found');
    return kiosk;
  }

  private async recordAudit(
    userId: string,
    kioskId: string,
    action: string,
    result: 'SUCCESS' | 'FAILURE' | 'BLOCKED' = 'SUCCESS',
  ) {
    await this.prisma.auditLog.create({
      data: { userId, kioskId, action, entityType: 'Kiosk', entityId: kioskId, result },
    });
  }

  async restart(id: string, requester: AuthenticatedUser) {
    await this.findOne(id);
    await this.recordAudit(requester.id, id, 'kiosk.restart');
    // Actual delivery happens over the kiosk's persistent WebSocket connection.
    return { kioskId: id, command: 'RESTART', queued: true };
  }

  async shutdown(id: string, requester: AuthenticatedUser) {
    await this.findOne(id);
    await this.recordAudit(requester.id, id, 'kiosk.shutdown');
    return { kioskId: id, command: 'SHUTDOWN', queued: true };
  }

  async syncPolicy(id: string, requester: AuthenticatedUser) {
    const kiosk = await this.findOne(id);
    await this.recordAudit(requester.id, id, 'kiosk.sync_policy');
    return { kioskId: id, command: 'SYNC_POLICY', currentPolicyVersion: kiosk.policyVersion, queued: true };
  }

  // ── Device-facing endpoints (called by kiosk-client, not admin users) ──────

  async recordHeartbeat(kioskId: string, dto: HeartbeatDto) {
    await this.prisma.$transaction([
      this.prisma.heartbeat.create({
        data: {
          kioskId,
          ipAddress: dto.ipAddress,
          windowsVersion: dto.windowsVersion,
          clientVersion: dto.clientVersion,
          cpuUsage: dto.cpuUsage,
          ramUsage: dto.ramUsage,
          diskUsage: dto.diskUsage,
        },
      }),
      this.prisma.kiosk.update({
        where: { id: kioskId },
        data: {
          onlineStatus: 'ONLINE',
          ipAddress: dto.ipAddress,
          windowsVersion: dto.windowsVersion,
          clientVersion: dto.clientVersion,
        },
      }),
    ]);
    // A best-effort gauge, not an authoritative count: re-derives from the table
    // rather than incrementing, since heartbeats don't map 1:1 to "newly online".
    this.prisma.kiosk.count({ where: { onlineStatus: 'ONLINE' } }).then((count) => {
      this.metrics.onlineKiosksGauge.set(count);
    });
    return { received: true };
  }

  /**
   * Assembles the policy payload the client caches to disk. This is a first working
   * version built directly off the raw tables — the dedicated policy-versioning engine
   * (explicit-block > explicit-allow > default, per §11) lands as its own module next;
   * this already gives the client something real to enforce and cache today.
   */
  async getPolicyForDevice(kioskId: string, sinceVersion: number) {
    const kiosk = await this.prisma.kiosk.findUniqueOrThrow({
      where: { id: kioskId },
      include: { branch: true, kioskMenu: { include: { items: true } } },
    });

    if (kiosk.policyVersion <= sinceVersion) {
      return null; // client's cached version is already current
    }

    this.metrics.policySyncsTotal.inc();

    const websiteRules = await this.prisma.websiteRule.findMany({
      where: {
        isActive: true,
        OR: [{ branchId: kiosk.branchId }, { branchId: null }],
      },
      include: { category: true },
    });
    // A rule under a disabled category stops applying without needing its own
    // isActive toggled — respects §12's "enable/disable whole categories".
    const effectiveRules = websiteRules.filter((r) => !r.category || r.category.enabled);

    const applications = await this.prisma.application.findMany({
      where: { status: 'APPROVED', OR: [{ branchId: kiosk.branchId }, { branchId: null }] },
      include: { versions: { where: { isActive: true } } },
    });

    const [windowsLockdown, security, browser] = await Promise.all([
      this.policiesService.getLatestConfig(kiosk.branchId, 'WINDOWS'),
      this.policiesService.getLatestConfig(kiosk.branchId, 'SECURITY'),
      this.policiesService.getLatestConfig(kiosk.branchId, 'BROWSER'),
    ]);

    return {
      policyVersion: kiosk.policyVersion,
      allowlistMode: true,
      // Mapped to PascalCase names to match the kiosk client's C# enum members exactly
      // (Domain/ExactUrl/Wildcard, Allow/Block) — see KioskClient.Models.KioskPolicy.
      websiteRules: effectiveRules.map((r) => ({
        type: { DOMAIN: 'Domain', EXACT_URL: 'ExactUrl', WILDCARD: 'Wildcard' }[r.type],
        action: { ALLOW: 'Allow', BLOCK: 'Block' }[r.action],
        pattern: r.pattern,
      })),
      blockedNavigationBehavior: (browser.blockedNavigationBehavior as string) ?? 'RedirectToHome',
      branchPortalUrl: '',
      homeUrl: 'kiosk://home',
      allowedApplicationExecutables: applications.flatMap((a) => a.versions.map((v) => v.executablePath).filter(Boolean)),
      menuItems: (kiosk.kioskMenu?.items ?? []).map((i) => ({
        label: i.label,
        iconUrl: i.iconUrl ?? '',
        targetType: i.targetType,
        targetValue: i.targetValue,
        sortOrder: i.sortOrder,
      })),
      branchName: kiosk.branch.name,
      kioskDisplayName: kiosk.deviceName,
      logoUrl: kiosk.branch.logoUrl ?? '',
      downloadsBlocked: browser.allowDownloads === true ? false : true,
      // Windows lockdown + security config (spec §18) — applied by kiosk-service
      // via registry policy keys (HKLM, needs LocalSystem) since the interactive
      // kiosk-client process may not hold rights to write them itself.
      windowsLockdown: {
        disableTaskManager: !!windowsLockdown.disableTaskManager,
        disableControlPanel: !!windowsLockdown.disableControlPanel,
        disableRegistryEditor: !!windowsLockdown.disableRegistryEditor,
        disableCommandPrompt: !!windowsLockdown.disableCommandPrompt,
        disableRun: !!windowsLockdown.disableRun,
        blockUsbStorage: !!windowsLockdown.blockUsbStorage,
      },
      security: {
        sessionTimeoutMinutes: (security.sessionTimeoutMinutes as number) ?? 0,
        autoRestartTime: (security.autoRestartTime as string) ?? '',
        lockScreenEnabled: !!security.lockScreenEnabled,
      },
    };
  }

  async logWebsiteAttempt(kioskId: string, dto: WebsiteLogDto) {
    // dto.action arrives as "Allow" | "Block" (client-side enum name); the Prisma
    // enum stores ALLOW | BLOCK — normalize here rather than coupling the two.
    const action = dto.action.toUpperCase() as 'ALLOW' | 'BLOCK';

    if (action === 'BLOCK') {
      this.metrics.blockedWebsiteAttemptsTotal.inc();
    }

    await this.prisma.websiteAccessLog.create({
      data: {
        kioskId,
        requestedUrl: dto.requestedUrl,
        domain: dto.domain,
        policyVersion: dto.policyVersion,
        action,
        result: action === 'BLOCK' ? 'BLOCKED' : 'SUCCESS',
      },
    });
    return { logged: true };
  }

  async verifyExitPin(kioskId: string, pin: string) {
    const kiosk = await this.prisma.kiosk.findUniqueOrThrow({
      where: { id: kioskId },
      include: { branch: true },
    });

    if (!kiosk.branch.exitPinHash) {
      // Fail secure: no PIN configured means exit is not permitted via PIN at all —
      // an admin must use full credentials through the admin panel instead.
      throw new UnauthorizedException('No exit PIN configured for this branch');
    }

    const valid = await argon2.verify(kiosk.branch.exitPinHash, pin);
    if (!valid) throw new UnauthorizedException('Incorrect PIN');

    await this.recordAudit(kioskId, kioskId, 'kiosk.exit_pin_used');
    return { authorized: true };
  }
}
