import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { KiosksService } from './kiosks.service';
import { CreateKioskDto } from './dto/create-kiosk.dto';
import { RegisterKioskDto } from './dto/register-kiosk.dto';
import { HeartbeatDto } from './dto/heartbeat.dto';
import { WebsiteLogDto } from './dto/website-log.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { BranchScopeGuard } from '../common/guards/branch-scope.guard';
import { DeviceAuthGuard } from '../common/guards/device-auth.guard';
import { DeviceOwnershipGuard } from '../common/guards/device-ownership.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('kiosks')
@Controller('api/kiosks')
export class KiosksController {
  constructor(private readonly kiosksService: KiosksService) {}

  // ── Device-facing: called by the Windows installer during first run.
  // Authenticated by the one-time registration code itself, not a user session.
  @Post('register')
  register(@Body() dto: RegisterKioskDto) {
    return this.kiosksService.registerDevice(dto);
  }

  // ── Device-facing: everything below authenticates with the device token
  // issued at registration (DeviceAuthGuard), and DeviceOwnershipGuard makes sure
  // a token for kiosk A can never be replayed against kiosk B's :id.
  @UseGuards(DeviceAuthGuard, DeviceOwnershipGuard)
  @Post(':id/heartbeat')
  heartbeat(@Param('id') id: string, @Body() dto: HeartbeatDto) {
    return this.kiosksService.recordHeartbeat(id, dto);
  }

  @UseGuards(DeviceAuthGuard, DeviceOwnershipGuard)
  @Get(':id/policy')
  getPolicy(@Param('id') id: string, @Query('since') since: string) {
    return this.kiosksService.getPolicyForDevice(id, Number(since) || 0);
  }

  @UseGuards(DeviceAuthGuard, DeviceOwnershipGuard)
  @Post(':id/website-logs')
  logWebsite(@Param('id') id: string, @Body() dto: WebsiteLogDto) {
    return this.kiosksService.logWebsiteAttempt(id, dto);
  }

  @UseGuards(DeviceAuthGuard, DeviceOwnershipGuard)
  @Post(':id/verify-exit-pin')
  verifyExitPin(@Param('id') id: string, @Body('pin') pin: string) {
    return this.kiosksService.verifyExitPin(id, pin);
  }

  // ── Admin-facing routes below all require a valid session + permission.
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard, BranchScopeGuard)
  @Post()
  @RequirePermissions(Permission.KIOSKS_MANAGE)
  create(@Body() dto: CreateKioskDto) {
    return this.kiosksService.create(dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post('registration-codes')
  @RequirePermissions(Permission.KIOSKS_MANAGE)
  generateRegistrationCode(@Body('branchId') branchId: string) {
    return this.kiosksService.generateRegistrationCode(branchId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Get()
  @RequirePermissions(Permission.KIOSKS_VIEW)
  findAll(@CurrentUser() user: AuthenticatedUser) {
    return this.kiosksService.findAll(user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Get(':id')
  @RequirePermissions(Permission.KIOSKS_VIEW)
  findOne(@Param('id') id: string) {
    return this.kiosksService.findOne(id);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post(':id/restart')
  @RequirePermissions(Permission.KIOSKS_RESTART)
  restart(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.kiosksService.restart(id, user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post(':id/shutdown')
  @RequirePermissions(Permission.KIOSKS_SHUTDOWN)
  shutdown(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.kiosksService.shutdown(id, user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @Post(':id/sync')
  @RequirePermissions(Permission.KIOSKS_MANAGE)
  sync(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.kiosksService.syncPolicy(id, user);
  }
}
