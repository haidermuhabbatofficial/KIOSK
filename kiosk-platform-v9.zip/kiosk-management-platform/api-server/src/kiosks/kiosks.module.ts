import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { KiosksService } from './kiosks.service';
import { KiosksController } from './kiosks.controller';
import { PoliciesModule } from '../policies/policies.module';

@Module({
  imports: [JwtModule.register({}), PoliciesModule],
  controllers: [KiosksController],
  providers: [KiosksService],
  exports: [KiosksService],
})
export class KiosksModule {}
