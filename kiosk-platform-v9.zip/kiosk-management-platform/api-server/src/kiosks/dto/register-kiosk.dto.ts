import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class RegisterKioskDto {
  @ApiProperty({ description: 'One-time registration code shown to the installer' })
  @IsString()
  registrationCode: string;

  @ApiProperty()
  @IsString()
  macAddress: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  windowsVersion?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  clientVersion?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  ipAddress?: string;
}
