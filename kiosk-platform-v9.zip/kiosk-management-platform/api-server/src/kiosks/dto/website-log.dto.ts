import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsInt, IsString } from 'class-validator';

export class WebsiteLogDto {
  @ApiProperty()
  @IsString()
  requestedUrl: string;

  @ApiProperty()
  @IsString()
  domain: string;

  @ApiProperty({ enum: ['Allow', 'Block'] })
  @IsIn(['Allow', 'Block'])
  action: string;

  @ApiProperty()
  @IsInt()
  policyVersion: number;
}
