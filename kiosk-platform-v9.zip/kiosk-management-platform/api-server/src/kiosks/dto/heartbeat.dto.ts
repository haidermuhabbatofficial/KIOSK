import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class HeartbeatDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  ipAddress?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  windowsVersion?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  clientVersion?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  cpuUsage?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  ramUsage?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  diskUsage?: number;
}
