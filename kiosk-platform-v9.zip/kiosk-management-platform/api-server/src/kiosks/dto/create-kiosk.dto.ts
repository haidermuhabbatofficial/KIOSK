import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsUUID } from 'class-validator';

export class CreateKioskDto {
  @ApiProperty({ example: 'OKR-KIOSK-001' })
  @IsString()
  kioskCode: string;

  @ApiProperty({ example: 'Front Desk Kiosk' })
  @IsString()
  deviceName: string;

  @ApiProperty()
  @IsUUID()
  branchId: string;
}
