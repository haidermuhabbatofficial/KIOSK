import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';

export enum WebsiteRuleTypeDto {
  DOMAIN = 'DOMAIN',
  EXACT_URL = 'EXACT_URL',
  WILDCARD = 'WILDCARD',
}

export enum WebsiteRuleActionDto {
  ALLOW = 'ALLOW',
  BLOCK = 'BLOCK',
}

export class CreateWebsiteRuleDto {
  @ApiProperty({ required: false, description: 'Omit for a global rule applied to every branch' })
  @IsOptional()
  @IsUUID()
  branchId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiProperty({ enum: WebsiteRuleTypeDto })
  @IsEnum(WebsiteRuleTypeDto)
  type: WebsiteRuleTypeDto;

  @ApiProperty({ enum: WebsiteRuleActionDto })
  @IsEnum(WebsiteRuleActionDto)
  action: WebsiteRuleActionDto;

  @ApiProperty({ example: 'google.com' })
  @IsString()
  pattern: string;
}

export class UpdateWebsiteRuleDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  pattern?: string;

  @ApiProperty({ required: false, enum: WebsiteRuleActionDto })
  @IsOptional()
  @IsEnum(WebsiteRuleActionDto)
  action?: WebsiteRuleActionDto;
}
