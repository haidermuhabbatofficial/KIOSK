import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsOptional, IsString } from 'class-validator';

export class CreateWebsiteCategoryDto {
  @ApiProperty({ example: 'Education' })
  @IsString()
  name: string;
}

export class UpdateWebsiteCategoryDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  enabled?: boolean;
}
