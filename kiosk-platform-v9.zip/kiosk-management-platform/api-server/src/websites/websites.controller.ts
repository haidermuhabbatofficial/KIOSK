import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { WebsitesService } from './websites.service';
import { CreateWebsiteRuleDto, UpdateWebsiteRuleDto } from './dto/website-rule.dto';
import { CreateWebsiteCategoryDto, UpdateWebsiteCategoryDto } from './dto/website-category.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('websites')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('api/websites')
export class WebsitesController {
  constructor(private readonly websitesService: WebsitesService) {}

  @Post('rules')
  @RequirePermissions(Permission.WEBSITES_MANAGE)
  createRule(@Body() dto: CreateWebsiteRuleDto, @CurrentUser() user: AuthenticatedUser) {
    return this.websitesService.createRule(dto, user);
  }

  @Get('rules')
  @RequirePermissions(Permission.WEBSITES_VIEW)
  findAllRules(@CurrentUser() user: AuthenticatedUser, @Query('branchId') branchId?: string) {
    return this.websitesService.findAllRules(user, branchId);
  }

  @Patch('rules/:id')
  @RequirePermissions(Permission.WEBSITES_MANAGE)
  updateRule(@Param('id') id: string, @Body() dto: UpdateWebsiteRuleDto, @CurrentUser() user: AuthenticatedUser) {
    return this.websitesService.updateRule(id, dto, user);
  }

  @Delete('rules/:id')
  @RequirePermissions(Permission.WEBSITES_MANAGE)
  deleteRule(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.websitesService.deleteRule(id, user);
  }

  @Post('categories')
  @RequirePermissions(Permission.WEBSITES_MANAGE)
  createCategory(@Body() dto: CreateWebsiteCategoryDto) {
    return this.websitesService.createCategory(dto);
  }

  @Get('categories')
  @RequirePermissions(Permission.WEBSITES_VIEW)
  findAllCategories() {
    return this.websitesService.findAllCategories();
  }

  @Patch('categories/:id')
  @RequirePermissions(Permission.WEBSITES_MANAGE)
  updateCategory(@Param('id') id: string, @Body() dto: UpdateWebsiteCategoryDto) {
    return this.websitesService.updateCategory(id, dto);
  }

  @Get('access-logs')
  @RequirePermissions(Permission.LOGS_VIEW)
  findAccessLogs(@CurrentUser() user: AuthenticatedUser, @Query('kioskId') kioskId?: string) {
    return this.websitesService.findAccessLogs(user, kioskId);
  }
}
