import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateWebsiteRuleDto, UpdateWebsiteRuleDto } from './dto/website-rule.dto';
import { CreateWebsiteCategoryDto, UpdateWebsiteCategoryDto } from './dto/website-category.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class WebsitesService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * The client only re-fetches policy when a kiosk's stored policyVersion advances
   * past what it has cached (see kiosks.service.ts getPolicyForDevice). Every mutation
   * that changes what a kiosk is allowed to reach MUST bump the relevant kiosks'
   * policyVersion here — forgetting this is how a rule change silently fails to reach
   * devices. A null branchId (global rule) affects every kiosk everywhere.
   */
  private async bumpPolicyVersion(branchId: string | null | undefined) {
    await this.prisma.kiosk.updateMany({
      where: branchId ? { branchId } : {},
      data: { policyVersion: { increment: 1 } },
    });
  }

  /** Only SUPER_ADMIN may create global rules (branchId omitted); everyone else must scope to their own branch. */
  private assertCanWriteBranch(requester: AuthenticatedUser, branchId?: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) return;
    if (!branchId) {
      throw new ForbiddenException('Only a super admin may create a global (all-branch) website rule');
    }
    if (branchId !== requester.branchId) {
      throw new ForbiddenException('You can only manage website rules for your own branch');
    }
  }

  // ── Rules ──────────────────────────────────────────────────────────

  async createRule(dto: CreateWebsiteRuleDto, requester: AuthenticatedUser) {
    this.assertCanWriteBranch(requester, dto.branchId);

    const rule = await this.prisma.websiteRule.create({
      data: {
        branchId: dto.branchId,
        categoryId: dto.categoryId,
        type: dto.type,
        action: dto.action,
        pattern: dto.pattern.toLowerCase(),
      },
    });

    await this.bumpPolicyVersion(dto.branchId);
    return rule;
  }

  async findAllRules(requester: AuthenticatedUser, branchId?: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) {
      return this.prisma.websiteRule.findMany({
        where: branchId ? { OR: [{ branchId }, { branchId: null }] } : {},
        include: { category: true },
      });
    }
    return this.prisma.websiteRule.findMany({
      where: { OR: [{ branchId: requester.branchId ?? '__none__' }, { branchId: null }] },
      include: { category: true },
    });
  }

  async updateRule(id: string, dto: UpdateWebsiteRuleDto, requester: AuthenticatedUser) {
    const existing = await this.prisma.websiteRule.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('Website rule not found');
    this.assertCanWriteBranch(requester, existing.branchId ?? undefined);

    const updated = await this.prisma.websiteRule.update({
      where: { id },
      data: {
        isActive: dto.isActive,
        pattern: dto.pattern?.toLowerCase(),
        action: dto.action,
      },
    });

    await this.bumpPolicyVersion(existing.branchId);
    return updated;
  }

  async deleteRule(id: string, requester: AuthenticatedUser) {
    const existing = await this.prisma.websiteRule.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException('Website rule not found');
    this.assertCanWriteBranch(requester, existing.branchId ?? undefined);

    await this.prisma.websiteRule.delete({ where: { id } });
    await this.bumpPolicyVersion(existing.branchId);
    return { deleted: true };
  }

  // ── Categories ─────────────────────────────────────────────────────

  async createCategory(dto: CreateWebsiteCategoryDto) {
    return this.prisma.websiteCategory.create({ data: { name: dto.name } });
  }

  async findAllCategories() {
    return this.prisma.websiteCategory.findMany({ include: { rules: true } });
  }

  /** Enabling/disabling a whole category can affect kiosks across every branch, so this bumps globally. */
  async updateCategory(id: string, dto: UpdateWebsiteCategoryDto) {
    const category = await this.prisma.websiteCategory.findUnique({ where: { id } });
    if (!category) throw new NotFoundException('Category not found');

    const updated = await this.prisma.websiteCategory.update({
      where: { id },
      data: { enabled: dto.enabled },
    });

    await this.bumpPolicyVersion(null);
    return updated;
  }

  // ── Access logs (spec §13) ──────────────────────────────────────────

  async findAccessLogs(requester: AuthenticatedUser, kioskId?: string) {
    const kioskFilter = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? {}
      : { kiosk: { branchId: requester.branchId ?? '__none__' } };

    return this.prisma.websiteAccessLog.findMany({
      where: { ...kioskFilter, ...(kioskId ? { kioskId } : {}) },
      include: { kiosk: true },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }
}
