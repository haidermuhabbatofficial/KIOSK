import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { LoggerModule } from 'nestjs-pino';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { BranchesModule } from './branches/branches.module';
import { KiosksModule } from './kiosks/kiosks.module';
import { WebsitesModule } from './websites/websites.module';
import { UpdatesModule } from './updates/updates.module';
import { ApplicationsModule } from './applications/applications.module';
import { RolesModule } from './roles/roles.module';
import { KioskMenusModule } from './kiosk-menus/kiosk-menus.module';
import { AuditLogsModule } from './audit-logs/audit-logs.module';
import { RemoteSessionsModule } from './remote-sessions/remote-sessions.module';
import { PoliciesModule } from './policies/policies.module';
import { SettingsModule } from './settings/settings.module';
import { MetricsModule } from './metrics/metrics.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    LoggerModule.forRoot({
      pinoHttp: {
        level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
        redact: ['req.headers.authorization'],
      },
    }),
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]),
    PrismaModule,
    AuthModule,
    UsersModule,
    BranchesModule,
    KiosksModule,
    WebsitesModule,
    UpdatesModule,
    ApplicationsModule,
    RolesModule,
    KioskMenusModule,
    AuditLogsModule,
    RemoteSessionsModule,
    PoliciesModule,
    SettingsModule,
    MetricsModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
