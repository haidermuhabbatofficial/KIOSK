import { Body, Controller, Get, Put, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PoliciesService } from './policies.service';
import { UpsertPolicyDto } from './dto/upsert-policy.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('policies')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('api/policies')
export class PoliciesController {
  constructor(private readonly policiesService: PoliciesService) {}

  @Get()
  @RequirePermissions(Permission.POLICIES_VIEW)
  findForBranch(@Query('branchId') branchId: string) {
    return this.policiesService.findForBranch(branchId);
  }

  @Put()
  @RequirePermissions(Permission.POLICIES_MANAGE)
  upsert(@Body() dto: UpsertPolicyDto, @CurrentUser() user: AuthenticatedUser) {
    return this.policiesService.upsert(dto, user);
  }
}
