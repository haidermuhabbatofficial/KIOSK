import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsObject, IsUUID } from 'class-validator';

export enum PolicyScopeDto {
  BROWSER = 'BROWSER',
  WINDOWS = 'WINDOWS',
  APPLICATION = 'APPLICATION',
  SECURITY = 'SECURITY',
}

export class UpsertPolicyDto {
  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty({ enum: PolicyScopeDto })
  @IsEnum(PolicyScopeDto)
  scope: PolicyScopeDto;

  @ApiProperty({
    description:
      'Freeform config matching the scope. WINDOWS: {disableTaskManager, disableControlPanel, ' +
      'disableRegistryEditor, disableCommandPrompt, disableRun, blockUsbStorage}. ' +
      'SECURITY: {sessionTimeoutMinutes, autoRestartTime, lockScreenEnabled}. ' +
      'BROWSER: {blockedNavigationBehavior, allowDownloads, allowPopups, allowPrivateBrowsing}.',
  })
  @IsObject()
  config: Record<string, unknown>;
}
