import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpsertPolicyDto } from './dto/upsert-policy.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class PoliciesService {
  constructor(private readonly prisma: PrismaService) {}

  private assertCanWriteBranch(requester: AuthenticatedUser, branchId: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) return;
    if (branchId !== requester.branchId) {
      throw new ForbiddenException('You can only manage policies for your own branch');
    }
  }

  async findForBranch(branchId: string) {
    const policies = await this.prisma.policy.findMany({
      where: { branchId },
      include: { versions: { orderBy: { version: 'desc' }, take: 1 } },
    });

    return policies.map((p) => ({
      id: p.id,
      scope: p.scope,
      config: p.versions[0]?.config ?? {},
      version: p.versions[0]?.version ?? 0,
    }));
  }

  /**
   * Creates the Policy row on first write for a branch+scope, then appends a new
   * PolicyVersion every time (full history, per spec §31's policy_versions table)
   * rather than mutating config in place. Bumps every kiosk in the branch so the
   * change reaches devices on their next sync — same pattern as websites/applications.
   */
  async upsert(dto: UpsertPolicyDto, requester: AuthenticatedUser) {
    this.assertCanWriteBranch(requester, dto.branchId);

    const policy = await this.prisma.policy.upsert({
      where: { branchId_scope: { branchId: dto.branchId, scope: dto.scope } },
      update: {},
      create: { branchId: dto.branchId, scope: dto.scope, name: `${dto.scope} Policy` },
    });

    const lastVersion = await this.prisma.policyVersion.findFirst({
      where: { policyId: policy.id },
      orderBy: { version: 'desc' },
    });
    const nextVersion = (lastVersion?.version ?? 0) + 1;

    const version = await this.prisma.policyVersion.create({
      data: { policyId: policy.id, version: nextVersion, config: dto.config, createdBy: requester.id },
    });

    await this.prisma.kiosk.updateMany({
      where: { branchId: dto.branchId },
      data: { policyVersion: { increment: 1 } },
    });

    return { scope: policy.scope, config: version.config, version: version.version };
  }

  /** Used by kiosks.service.ts to fold Windows/Security/Browser policy into the device payload. */
  async getLatestConfig(branchId: string, scope: 'WINDOWS' | 'SECURITY' | 'BROWSER'): Promise<Record<string, unknown>> {
    const policy = await this.prisma.policy.findUnique({
      where: { branchId_scope: { branchId, scope } },
      include: { versions: { orderBy: { version: 'desc' }, take: 1 } },
    });
    return (policy?.versions[0]?.config as Record<string, unknown>) ?? {};
  }
}
