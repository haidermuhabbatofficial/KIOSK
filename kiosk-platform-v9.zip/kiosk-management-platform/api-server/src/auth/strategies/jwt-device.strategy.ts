import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

interface DeviceTokenPayload {
  sub: string; // kioskId
  type: string;
}

export interface AuthenticatedDevice {
  kioskId: string;
}

/**
 * Separate strategy/secret from admin JWTs by design: a device token only ever
 * proves "I am kiosk X", never carries permissions, and is checked against the
 * :id route param by DeviceOwnershipGuard so kiosk A can never call kiosk B's endpoints.
 */
@Injectable()
export class JwtDeviceStrategy extends PassportStrategy(Strategy, 'jwt-device') {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_DEVICE_SECRET ?? process.env.JWT_ACCESS_SECRET,
    });
  }

  async validate(payload: DeviceTokenPayload): Promise<AuthenticatedDevice> {
    if (payload.type !== 'device') {
      throw new UnauthorizedException('Not a device token');
    }
    return { kioskId: payload.sub };
  }
}
