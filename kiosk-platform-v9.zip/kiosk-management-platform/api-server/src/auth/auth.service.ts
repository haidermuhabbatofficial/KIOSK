import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { MetricsService } from '../metrics/metrics.service';

interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly metrics: MetricsService,
  ) {}

  private hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  private async loadAuthenticatedUser(userId: string): Promise<AuthenticatedUser> {
    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId },
      include: {
        userRoles: {
          include: {
            role: { include: { rolePermissions: { include: { permission: true } } } },
          },
        },
      },
    });

    const roles = user.userRoles.map((ur) => ur.role.name);
    const permissions = Array.from(
      new Set(
        user.userRoles.flatMap((ur) => ur.role.rolePermissions.map((rp) => rp.permission.key)),
      ),
    );

    return {
      id: user.id,
      username: user.username,
      email: user.email,
      branchId: user.branchId,
      roles,
      permissions,
    };
  }

  async validateCredentials(username: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { username } });

    if (!user || !user.isActive || user.deletedAt) {
      this.metrics.failedAuthAttemptsTotal.inc();
      throw new UnauthorizedException('Invalid credentials');
    }

    const passwordValid = await argon2.verify(user.passwordHash, password);
    if (!passwordValid) {
      this.metrics.failedAuthAttemptsTotal.inc();
      throw new UnauthorizedException('Invalid credentials');
    }

    return user;
  }

  async login(username: string, password: string, meta: { ip?: string; userAgent?: string }): Promise<TokenPair> {
    const user = await this.validateCredentials(username, password);
    const authUser = await this.loadAuthenticatedUser(user.id);

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    return this.issueTokenPair(authUser, meta);
  }

  private async issueTokenPair(
    authUser: AuthenticatedUser,
    meta: { ip?: string; userAgent?: string },
  ): Promise<TokenPair> {
    const accessExpiresIn = process.env.JWT_ACCESS_EXPIRES_IN ?? '15m';
    const refreshExpiresIn = process.env.JWT_REFRESH_EXPIRES_IN ?? '7d';

    const accessToken = await this.jwtService.signAsync(
      {
        sub: authUser.id,
        username: authUser.username,
        email: authUser.email,
        branchId: authUser.branchId,
        roles: authUser.roles,
        permissions: authUser.permissions,
      },
      { secret: process.env.JWT_ACCESS_SECRET, expiresIn: accessExpiresIn },
    );

    const refreshTokenId = crypto.randomUUID();
    const refreshToken = await this.jwtService.signAsync(
      { sub: authUser.id, jti: refreshTokenId },
      { secret: process.env.JWT_REFRESH_SECRET, expiresIn: refreshExpiresIn },
    );

    const expiresAt = new Date();
    expiresAt.setSeconds(expiresAt.getSeconds() + this.parseExpiresInSeconds(refreshExpiresIn));

    await this.prisma.refreshToken.create({
      data: {
        userId: authUser.id,
        tokenHash: this.hashToken(refreshToken),
        expiresAt,
        ipAddress: meta.ip,
        userAgent: meta.userAgent,
      },
    });

    return { accessToken, refreshToken, expiresIn: accessExpiresIn };
  }

  private parseExpiresInSeconds(value: string): number {
    const match = /^(\d+)([smhd])$/.exec(value);
    if (!match) return 7 * 24 * 60 * 60;
    const amount = Number(match[1]);
    const unit = match[2];
    const multiplier = { s: 1, m: 60, h: 3600, d: 86400 }[unit] ?? 1;
    return amount * multiplier;
  }

  /**
   * Refresh-token rotation: the presented token is validated, immediately revoked,
   * and replaced with a new pair. Reuse of a revoked token is treated as a signal
   * of compromise and revokes the entire token family for the user.
   */
  async refresh(refreshToken: string, meta: { ip?: string; userAgent?: string }): Promise<TokenPair> {
    let payload: { sub: string; jti: string };
    try {
      payload = await this.jwtService.verifyAsync(refreshToken, {
        secret: process.env.JWT_REFRESH_SECRET,
      });
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const tokenHash = this.hashToken(refreshToken);
    const stored = await this.prisma.refreshToken.findUnique({ where: { tokenHash } });

    if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
      if (stored?.revokedAt) {
        // Reused a revoked token — likely theft. Revoke every active token for this user.
        await this.prisma.refreshToken.updateMany({
          where: { userId: payload.sub, revokedAt: null },
          data: { revokedAt: new Date() },
        });
      }
      throw new UnauthorizedException('Refresh token is no longer valid');
    }

    const authUser = await this.loadAuthenticatedUser(payload.sub);
    const newPair = await this.issueTokenPair(authUser, meta);

    await this.prisma.refreshToken.update({
      where: { tokenHash },
      data: { revokedAt: new Date(), replacedBy: this.hashToken(newPair.refreshToken) },
    });

    return newPair;
  }

  async logout(refreshToken: string): Promise<void> {
    const tokenHash = this.hashToken(refreshToken);
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  async getAuthenticatedUser(userId: string): Promise<AuthenticatedUser> {
    return this.loadAuthenticatedUser(userId);
  }
}
