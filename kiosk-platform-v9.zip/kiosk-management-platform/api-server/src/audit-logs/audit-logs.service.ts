import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

export interface AuditLogFilters {
  action?: string;
  userId?: string;
  kioskId?: string;
  result?: 'SUCCESS' | 'FAILURE' | 'BLOCKED';
  from?: string;
  to?: string;
}

@Injectable()
export class AuditLogsService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(requester: AuthenticatedUser, filters: AuditLogFilters) {
    const branchScope = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? {}
      : {
          OR: [
            { user: { branchId: requester.branchId ?? '__none__' } },
            { kiosk: { branchId: requester.branchId ?? '__none__' } },
          ],
        };

    return this.prisma.auditLog.findMany({
      where: {
        ...branchScope,
        ...(filters.action ? { action: { contains: filters.action } } : {}),
        ...(filters.userId ? { userId: filters.userId } : {}),
        ...(filters.kioskId ? { kioskId: filters.kioskId } : {}),
        ...(filters.result ? { result: filters.result } : {}),
        ...(filters.from || filters.to
          ? {
              createdAt: {
                ...(filters.from ? { gte: new Date(filters.from) } : {}),
                ...(filters.to ? { lte: new Date(filters.to) } : {}),
              },
            }
          : {}),
      },
      include: { user: { select: { name: true, username: true } }, kiosk: { select: { deviceName: true, kioskCode: true } } },
      orderBy: { createdAt: 'desc' },
      take: 300,
    });
  }
}
