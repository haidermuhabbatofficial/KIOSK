import { Body, Controller, Get, Param, Patch, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RolesService } from './roles.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';

@ApiTags('roles')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('api')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  @Get('roles')
  @RequirePermissions(Permission.ROLES_MANAGE)
  findAll() {
    return this.rolesService.findAll();
  }

  @Get('permissions')
  @RequirePermissions(Permission.ROLES_MANAGE)
  findAllPermissions() {
    return this.rolesService.findAllPermissionKeys();
  }

  @Patch('roles/:id/permissions')
  @RequirePermissions(Permission.ROLES_MANAGE)
  updatePermissions(@Param('id') id: string, @Body('permissions') permissions: string[]) {
    return this.rolesService.updatePermissions(id, permissions);
  }
}
