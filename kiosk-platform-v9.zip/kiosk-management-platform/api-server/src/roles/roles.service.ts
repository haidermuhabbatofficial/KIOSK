import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Permission } from '../common/enums/permission.enum';

@Injectable()
export class RolesService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll() {
    const roles = await this.prisma.role.findMany({
      include: { rolePermissions: { include: { permission: true } } },
    });
    return roles.map((r) => ({
      id: r.id,
      name: r.name,
      permissions: r.rolePermissions.map((rp) => rp.permission.key),
    }));
  }

  findAllPermissionKeys(): string[] {
    return Object.values(Permission);
  }

  /**
   * Replaces a role's full permission set. SUPER_ADMIN's grants are intentionally
   * NOT editable through this endpoint — removing them here would be an easy way to
   * accidentally lock every admin out of the system, so it's excluded at the service
   * layer rather than relying on the UI to not offer the option.
   */
  async updatePermissions(roleId: string, permissionKeys: string[]) {
    const role = await this.prisma.role.findUnique({ where: { id: roleId } });
    if (!role) throw new NotFoundException('Role not found');
    if (role.name === 'SUPER_ADMIN') {
      throw new BadRequestException('Super Admin permissions cannot be modified');
    }

    const permissions = await this.prisma.permission.findMany({ where: { key: { in: permissionKeys } } });
    if (permissions.length !== permissionKeys.length) {
      throw new BadRequestException('One or more permission keys are invalid');
    }

    await this.prisma.$transaction([
      this.prisma.rolePermission.deleteMany({ where: { roleId } }),
      this.prisma.rolePermission.createMany({
        data: permissions.map((p) => ({ roleId, permissionId: p.id })),
      }),
    ]);

    return this.findAll();
  }
}
