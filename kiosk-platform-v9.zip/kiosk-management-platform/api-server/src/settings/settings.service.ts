import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

// The fixed set of known settings this build actually reads/uses elsewhere.
// Unknown keys are still stored (forward-compatible) but won't do anything yet.
const DEFAULTS: Record<string, unknown> = {
  platformName: 'Kiosk Management Platform',
  registrationCodeTtlMinutes: 30,
  remoteSessionTtlMinutes: 30,
  defaultBlockedNavigationBehavior: 'REDIRECT_TO_HOME',
};

@Injectable()
export class SettingsService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(): Promise<Record<string, unknown>> {
    const rows = await this.prisma.systemSetting.findMany();
    const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return { ...DEFAULTS, ...stored };
  }

  async set(key: string, value: unknown) {
    await this.prisma.systemSetting.upsert({
      where: { key },
      update: { value: value as any },
      create: { key, value: value as any },
    });
    return this.findAll();
  }
}
