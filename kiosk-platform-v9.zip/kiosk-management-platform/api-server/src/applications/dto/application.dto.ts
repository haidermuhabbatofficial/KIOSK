import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateApplicationDto {
  @ApiProperty({ example: 'Microsoft Word' })
  @IsString()
  name: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  publisher?: string;

  @ApiProperty({ required: false, description: 'Omit for an application approved across every branch' })
  @IsOptional()
  @IsUUID()
  branchId?: string;
}

export class CreateApplicationVersionDto {
  @ApiProperty({ example: '1.0.0' })
  @IsString()
  version: string;

  @ApiProperty({ required: false, description: 'Path the kiosk client launches, e.g. C:\\Program Files\\...\\winword.exe' })
  @IsOptional()
  @IsString()
  executablePath?: string;

  @ApiProperty({ required: false, description: 'Where the kiosk downloads the installer from' })
  @IsOptional()
  @IsString()
  installerUrl?: string;

  @ApiProperty()
  @IsString()
  sha256: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  releaseNotes?: string;
}
