import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateApplicationDto, CreateApplicationVersionDto } from './dto/application.dto';
import { AuthenticatedUser } from '../common/decorators/current-user.decorator';
import { RoleName } from '../common/enums/role.enum';

@Injectable()
export class ApplicationsService {
  constructor(private readonly prisma: PrismaService) {}

  private assertCanWriteBranch(requester: AuthenticatedUser, branchId?: string) {
    if (requester.roles.includes(RoleName.SUPER_ADMIN)) return;
    if (!branchId) {
      throw new ForbiddenException('Only a super admin may approve an application for every branch');
    }
    if (branchId !== requester.branchId) {
      throw new ForbiddenException('You can only manage applications for your own branch');
    }
  }

  async create(dto: CreateApplicationDto, requester: AuthenticatedUser) {
    this.assertCanWriteBranch(requester, dto.branchId);
    return this.prisma.application.create({
      data: { name: dto.name, publisher: dto.publisher, branchId: dto.branchId },
    });
  }

  async findAll(requester: AuthenticatedUser) {
    const where = requester.roles.includes(RoleName.SUPER_ADMIN)
      ? { deletedAt: null }
      : { deletedAt: null, OR: [{ branchId: requester.branchId ?? '__none__' }, { branchId: null }] };

    return this.prisma.application.findMany({
      where,
      include: { versions: { orderBy: { releaseDate: 'desc' } } },
    });
  }

  async findOne(id: string) {
    const app = await this.prisma.application.findUnique({
      where: { id },
      include: { versions: { orderBy: { releaseDate: 'desc' } } },
    });
    if (!app || app.deletedAt) throw new NotFoundException('Application not found');
    return app;
  }

  /**
   * Publishing a new version bumps every kiosk that can see this application, the
   * same way a website rule change does — an application isn't actually "approved"
   * on-device until the kiosk's next policy sync picks it up.
   */
  async addVersion(applicationId: string, dto: CreateApplicationVersionDto, requester: AuthenticatedUser) {
    const app = await this.findOne(applicationId);
    this.assertCanWriteBranch(requester, app.branchId ?? undefined);

    const version = await this.prisma.applicationVersion.create({
      data: {
        applicationId,
        version: dto.version,
        executablePath: dto.executablePath,
        installerUrl: dto.installerUrl,
        sha256: dto.sha256,
        releaseNotes: dto.releaseNotes,
      },
    });

    await this.prisma.kiosk.updateMany({
      where: app.branchId ? { branchId: app.branchId } : {},
      data: { policyVersion: { increment: 1 } },
    });

    return version;
  }

  async setStatus(id: string, status: 'APPROVED' | 'DISABLED', requester: AuthenticatedUser) {
    const app = await this.findOne(id);
    this.assertCanWriteBranch(requester, app.branchId ?? undefined);

    const updated = await this.prisma.application.update({ where: { id }, data: { status } });
    await this.prisma.kiosk.updateMany({
      where: app.branchId ? { branchId: app.branchId } : {},
      data: { policyVersion: { increment: 1 } },
    });
    return updated;
  }
}
