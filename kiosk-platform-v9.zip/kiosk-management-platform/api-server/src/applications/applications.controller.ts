import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApplicationsService } from './applications.service';
import { CreateApplicationDto, CreateApplicationVersionDto } from './dto/application.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermissions } from '../common/decorators/permissions.decorator';
import { Permission } from '../common/enums/permission.enum';
import { CurrentUser, AuthenticatedUser } from '../common/decorators/current-user.decorator';

@ApiTags('applications')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('api/applications')
export class ApplicationsController {
  constructor(private readonly applicationsService: ApplicationsService) {}

  @Post()
  @RequirePermissions(Permission.APPLICATIONS_MANAGE)
  create(@Body() dto: CreateApplicationDto, @CurrentUser() user: AuthenticatedUser) {
    return this.applicationsService.create(dto, user);
  }

  @Get()
  @RequirePermissions(Permission.APPLICATIONS_VIEW)
  findAll(@CurrentUser() user: AuthenticatedUser) {
    return this.applicationsService.findAll(user);
  }

  @Get(':id')
  @RequirePermissions(Permission.APPLICATIONS_VIEW)
  findOne(@Param('id') id: string) {
    return this.applicationsService.findOne(id);
  }

  @Post(':id/versions')
  @RequirePermissions(Permission.APPLICATIONS_MANAGE)
  addVersion(@Param('id') id: string, @Body() dto: CreateApplicationVersionDto, @CurrentUser() user: AuthenticatedUser) {
    return this.applicationsService.addVersion(id, dto, user);
  }

  @Patch(':id/disable')
  @RequirePermissions(Permission.APPLICATIONS_MANAGE)
  disable(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.applicationsService.setStatus(id, 'DISABLED', user);
  }

  @Patch(':id/approve')
  @RequirePermissions(Permission.APPLICATIONS_MANAGE)
  approve(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.applicationsService.setStatus(id, 'APPROVED', user);
  }
}
