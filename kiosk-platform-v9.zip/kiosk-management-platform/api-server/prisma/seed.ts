import { PrismaClient, RoleName } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

const ALL_PERMISSIONS = [
  'dashboard.view',
  'branches.view', 'branches.manage',
  'kiosks.view', 'kiosks.manage', 'kiosks.restart', 'kiosks.shutdown', 'kiosks.lock',
  'users.view', 'users.manage',
  'roles.manage',
  'websites.view', 'websites.manage',
  'applications.view', 'applications.manage',
  'kiosk_menu.view', 'kiosk_menu.manage',
  'downloads.view',
  'policies.view', 'policies.manage',
  'remote_support.view', 'remote_support.start',
  'logs.view',
  'configuration.manage',
  'updates.manage',
];

// Which permissions each role gets by default. Adjust freely from the admin UI later —
// this is only the seeded starting point.
const ROLE_PERMISSIONS: Record<RoleName, string[]> = {
  SUPER_ADMIN: ALL_PERMISSIONS,
  BRANCH_ADMIN: [
    'dashboard.view',
    'branches.view',
    'kiosks.view', 'kiosks.manage', 'kiosks.restart', 'kiosks.shutdown', 'kiosks.lock',
    'users.view', 'users.manage',
    'websites.view', 'websites.manage',
    'applications.view', 'applications.manage',
    'kiosk_menu.view', 'kiosk_menu.manage',
    'downloads.view',
    'policies.view', 'policies.manage',
    'remote_support.view', 'remote_support.start',
    'logs.view',
  ],
  KIOSK_ADMIN: [
    'dashboard.view',
    'kiosks.view', 'kiosks.restart', 'kiosks.shutdown', 'kiosks.lock',
    'websites.view',
    'applications.view',
    'kiosk_menu.view',
    'downloads.view',
    'remote_support.view', 'remote_support.start',
    'logs.view',
  ],
  USER: [],
};

async function main() {
  console.log('Seeding permissions…');
  const permissionRecords = await Promise.all(
    ALL_PERMISSIONS.map((key) =>
      prisma.permission.upsert({ where: { key }, update: {}, create: { key } }),
    ),
  );
  const permissionByKey = new Map(permissionRecords.map((p) => [p.key, p]));

  console.log('Seeding roles…');
  for (const roleName of Object.values(RoleName)) {
    const role = await prisma.role.upsert({
      where: { name: roleName },
      update: {},
      create: { name: roleName },
    });

    const grantedKeys = ROLE_PERMISSIONS[roleName];
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: grantedKeys.map((key) => ({
        roleId: role.id,
        permissionId: permissionByKey.get(key)!.id,
      })),
    });
  }

  console.log('Seeding demo branches…');
  const branchDefs = [
    { name: 'Okara Campus', code: 'OKR-01' },
    { name: 'Sahiwal Campus', code: 'SAH-01' },
    { name: 'Lahore Campus', code: 'LAH-01' },
  ];
  const branches = await Promise.all(
    branchDefs.map((b) => prisma.branch.upsert({ where: { code: b.code }, update: {}, create: b })),
  );

  console.log('Seeding demo kiosks…');
  const kioskDefs = [
    { kioskCode: 'OKR-KIOSK-001', deviceName: 'Okara Front Desk', branchCode: 'OKR-01' },
    { kioskCode: 'OKR-KIOSK-002', deviceName: 'Okara Library', branchCode: 'OKR-01' },
    { kioskCode: 'SAH-KIOSK-001', deviceName: 'Sahiwal Front Desk', branchCode: 'SAH-01' },
    { kioskCode: 'LAH-KIOSK-001', deviceName: 'Lahore Front Desk', branchCode: 'LAH-01' },
  ];
  for (const k of kioskDefs) {
    const branch = branches.find((b) => b.code === k.branchCode)!;
    await prisma.kiosk.upsert({
      where: { kioskCode: k.kioskCode },
      update: {},
      create: { kioskCode: k.kioskCode, deviceName: k.deviceName, branchId: branch.id },
    });
  }

  console.log('Seeding super admin user…');
  const superAdminRole = await prisma.role.findUniqueOrThrow({ where: { name: 'SUPER_ADMIN' } });
  const passwordHash = await argon2.hash('ChangeMe123!', { type: argon2.argon2id });
  const admin = await prisma.user.upsert({
    where: { username: 'superadmin' },
    update: {},
    create: {
      name: 'Super Admin',
      username: 'superadmin',
      email: 'superadmin@example.com',
      passwordHash,
    },
  });
  await prisma.userRole.upsert({
    where: { userId_roleId: { userId: admin.id, roleId: superAdminRole.id } },
    update: {},
    create: { userId: admin.id, roleId: superAdminRole.id },
  });

  console.log('Done. Login with username "superadmin" / password "ChangeMe123!" — change it immediately.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
