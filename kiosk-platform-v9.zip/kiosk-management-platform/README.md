# Windows Kiosk Management Platform

A centralized platform for managing Windows kiosk computers across multiple branches:
branch/kiosk management, RBAC, website & application allowlisting, remote configuration,
AnyDesk-style remote support, and centralized policy enforcement that fails secure during
a server outage.

This repo is being built incrementally, phase by phase, each one a genuinely working
slice rather than a UI mockup. See each subproject's own README for what's implemented,
what isn't yet, and how to run it.

## Subprojects

| Path | What it is |
|---|---|
| `api-server/` | NestJS + PostgreSQL/Prisma backend — auth, RBAC, all admin + device-facing APIs, WebRTC signaling gateway |
| `admin-web/` | Next.js admin panel — branches, kiosks, websites, applications, users/roles, kiosk menu, audit logs, remote support |
| `kiosk-client/` | WPF + WebView2 Windows kiosk app — policy enforcement, kiosk UI, remote-support agent |
| `kiosk-service/` | .NET Worker Service — crash watchdog, auto-updates |
| `installer/` | WiX MSI installer + `install.ps1` one-line PowerShell bootstrapper |
| `database/` | Prisma schema (single source of truth for the data model) |
| `infrastructure/` | Docker Compose (app + monitoring), Prometheus/Grafana config, backup script |
| `docs/` | Backup & disaster recovery procedure |
| `.github/workflows/` | CI — lint/build/test for api-server, admin-web, and the .NET projects |

## Build history

1. **Database + Auth/RBAC** — full schema, JWT auth with refresh-token rotation, permission-based access control
2. **Windows client integration** — WPF kiosk client, policy engine, Windows service watchdog, WiX installer, `install.ps1`
3. **Admin panel foundation** — Next.js app: login, dashboard, branches, kiosks, website allowlist UI
4. **Applications + Roles/Permissions** — application allowlist with versioning, a clickable permission matrix per role
5. **Kiosk Menu builder + Audit Logs viewer**
6. **Remote Support (WebRTC)** — session lifecycle (start/end, time-limited, audited), a signaling gateway relaying SDP/ICE between the admin browser and the kiosk's C# agent, and an admin-side viewer rendering the kiosk's screen with mouse/keyboard control
7. **Policies, Settings, Monitoring, Backup/DR** — Windows lockdown + security policy UI (applied via registry keys from the Windows service), instance-wide settings page, file transfer/clipboard sync added to remote support, Prometheus metrics + starter Grafana dashboard, GitHub Actions CI, and a documented backup-restore procedure

## Quick start

```bash
# 1. Infra
docker compose -f infrastructure/docker/docker-compose.dev.yml up -d

# 2. API
cd api-server
npm install && cp .env.example .env
npx prisma migrate dev --name init && npm run prisma:seed
npm run start:dev

# 3. Admin panel (separate terminal)
cd admin-web
npm install && cp .env.local.example .env.local
npm run dev
```

Log in at `http://localhost:3001` (or whatever port Next.js picks) with
`superadmin` / `ChangeMe123!` from the seed script.

The Windows-side pieces (`kiosk-client`, `kiosk-service`, `installer`) need a Windows
machine with the .NET 8 SDK and WiX Toolset to build — see their own READMEs.

## What's still not built

Deeper application/browser policy config beyond what's implemented, CI/CD's actual
deployment step (build+test only, no auto-deploy), file-storage-backed installer
uploads (currently URL-referenced), alerting rules on top of the Prometheus metrics.

## Honesty about what hasn't been tested

None of this has been compiled or run end-to-end — there's no Windows machine, .NET
SDK, or Node runtime in the environment this was built in. The API server's TypeScript
is the most likely to be correct as-is; the C# kiosk client and especially the WebRTC
remote-support agent (which leans on SIPSorcery, a less commonly used library) are the
parts most worth building and testing carefully before trusting them in production.
