'use client';

import { useEffect, useRef, useState } from 'react';
import { getWsUrl } from '@/lib/api-client';
import { Button } from '@/components/ui/button';

interface Props {
  sessionId: string;
  token: string;
  kioskName: string;
  fileTransferAllowed: boolean;
  clipboardSyncAllowed: boolean;
  onClose: () => void;
}

type SignalPayload =
  | { type: 'offer'; sdp: string }
  | { type: 'answer'; sdp: string }
  | { type: 'ice'; candidate: RTCIceCandidateInit };

/**
 * Admin side of the WebRTC remote-support session. The kiosk agent creates the
 * offer and the DataChannel (it's the one with something to share); this side
 * waits for both, answers, and renders whatever arrives on the channel.
 *
 * Screen sharing here is periodic JPEG frames pushed over the DataChannel rather
 * than a native RTCVideoTrack — a deliberate simplification to avoid needing a
 * full media-pipeline/codec setup on the .NET side (see kiosk-client's
 * RemoteAgentService.cs). It's genuinely WebRTC (DTLS-encrypted, peer-to-peer
 * after signaling) but will look like a slideshow rather than smooth video at
 * low frame rates — swap in a real video track later if that's not good enough.
 */
export function RemoteSessionViewer({
  sessionId,
  token,
  kioskName,
  fileTransferAllowed,
  clipboardSyncAllowed,
  onClose,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const channelRef = useRef<RTCDataChannel | null>(null);
  const [status, setStatus] = useState('Connecting…');
  const [sessionTimer, setSessionTimer] = useState(0);
  const lastClipboardRef = useRef('');

  useEffect(() => {
    const timerInterval = setInterval(() => setSessionTimer((t) => t + 1), 1000);

    const ws = new WebSocket(getWsUrl('/ws/remote-support'));
    wsRef.current = ws;

    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    pcRef.current = pc;

    pc.onicecandidate = (e) => {
      if (e.candidate) {
        sendSignal({ type: 'ice', candidate: e.candidate.toJSON() });
      }
    };

    pc.ondatachannel = (e) => {
      channelRef.current = e.channel;
      wireChannel(e.channel);
    };

    function sendSignal(payload: SignalPayload) {
      ws.send(JSON.stringify({ event: 'signal', data: { sessionId, payload } }));
    }

    function wireChannel(channel: RTCDataChannel) {
      channel.onopen = () => {
        setStatus('Live');
        if (clipboardSyncAllowed) {
          startClipboardPolling(channel);
        }
      };
      channel.onclose = () => setStatus('Disconnected');
      channel.onmessage = (msg) => {
        try {
          const data = JSON.parse(msg.data);
          if (data.type === 'frame') {
            drawFrame(data.jpegBase64);
          } else if (data.type === 'clipboard' && clipboardSyncAllowed) {
            lastClipboardRef.current = data.text;
            navigator.clipboard.writeText(data.text).catch(() => {});
          }
        } catch {
          // ignore malformed frames rather than crashing the session
        }
      };

      const canvas = canvasRef.current;
      if (!canvas) return;

      canvas.addEventListener('mousemove', (e) => sendInput(channel, canvas, e, 'mousemove'));
      canvas.addEventListener('mousedown', (e) => sendInput(channel, canvas, e, 'mousedown'));
      canvas.addEventListener('mouseup', (e) => sendInput(channel, canvas, e, 'mouseup'));
      canvas.tabIndex = 0;
      canvas.addEventListener('keydown', (e) => {
        e.preventDefault();
        channel.send(JSON.stringify({ type: 'keydown', key: e.key, code: e.code }));
      });
      canvas.addEventListener('keyup', (e) => {
        e.preventDefault();
        channel.send(JSON.stringify({ type: 'keyup', key: e.key, code: e.code }));
      });
    }

    function drawFrame(base64: string) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);
      };
      img.src = `data:image/jpeg;base64,${base64}`;
    }

    function startClipboardPolling(channel: RTCDataChannel) {
      // Polling rather than a clipboard-change event because the browser Clipboard
      // API has no reliable cross-browser change notification — 1.5s is a modest
      // compromise between responsiveness and not hammering the permission prompt.
      const interval = setInterval(async () => {
        if (channel.readyState !== 'open') return;
        try {
          const text = await navigator.clipboard.readText();
          if (text && text !== lastClipboardRef.current) {
            lastClipboardRef.current = text;
            channel.send(JSON.stringify({ type: 'clipboard', text }));
          }
        } catch {
          // Clipboard permission not granted — sync silently does nothing rather than erroring the session.
        }
      }, 1500);
      channel.addEventListener('close', () => clearInterval(interval));
    }

    ws.onopen = () => {
      ws.send(JSON.stringify({ event: 'join', data: { sessionId, role: 'admin', token } }));
    };

    ws.onmessage = async (msg) => {
      const data = JSON.parse(msg.data);

      switch (data.event) {
        case 'joined':
          setStatus('Waiting for kiosk to connect…');
          break;
        case 'peer-ready':
          setStatus('Negotiating connection…');
          break;
        case 'signal': {
          const payload: SignalPayload = data.payload;
          if (payload.type === 'offer') {
            await pc.setRemoteDescription({ type: 'offer', sdp: payload.sdp });
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            sendSignal({ type: 'answer', sdp: answer.sdp! });
          } else if (payload.type === 'ice') {
            await pc.addIceCandidate(payload.candidate);
          }
          break;
        }
        case 'peer-disconnected':
          setStatus('Kiosk disconnected');
          break;
        case 'ended':
          setStatus('Session ended');
          cleanup();
          break;
        case 'rejected':
          setStatus(`Rejected: ${data.reason}`);
          break;
      }
    };

    function cleanup() {
      clearInterval(timerInterval);
      pc.close();
      ws.close();
    }

    return cleanup;
  }, [sessionId, token]);

  function sendInput(channel: RTCDataChannel, canvas: HTMLCanvasElement, e: MouseEvent, type: string) {
    if (channel.readyState !== 'open') return;
    const rect = canvas.getBoundingClientRect();
    // Normalized 0..1 coordinates — the kiosk agent maps these back to its own
    // screen resolution, since the admin's canvas size won't match the kiosk's display.
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    channel.send(JSON.stringify({ type, x, y, button: e.button }));
  }

  function endSession() {
    wsRef.current?.send(JSON.stringify({ event: 'end', data: { sessionId } }));
    onClose();
  }

  async function sendFile(file: File) {
    const channel = channelRef.current;
    if (!channel || channel.readyState !== 'open') return;

    const CHUNK_SIZE = 16 * 1024; // stay well under typical SCTP message-size limits
    const buffer = await file.arrayBuffer();
    const totalChunks = Math.ceil(buffer.byteLength / CHUNK_SIZE);

    channel.send(JSON.stringify({ type: 'file-start', name: file.name, size: buffer.byteLength }));

    for (let i = 0; i < totalChunks; i++) {
      const chunk = buffer.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
      const base64 = btoa(String.fromCharCode(...new Uint8Array(chunk)));
      channel.send(JSON.stringify({ type: 'file-chunk', index: i, data: base64 }));
      // Yield between chunks so a large file doesn't starve the input/frame traffic
      // sharing the same DataChannel.
      await new Promise((resolve) => setTimeout(resolve, 5));
    }

    channel.send(JSON.stringify({ type: 'file-end', name: file.name, totalChunks }));
  }

  const minutes = Math.floor(sessionTimer / 60);
  const seconds = sessionTimer % 60;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      <div className="flex items-center justify-between bg-neutral-900 px-4 py-2 text-sm text-white">
        <span>
          Remote session — <span className="font-medium">{kioskName}</span> — {status}
        </span>
        <div className="flex items-center gap-4">
          <span className="font-mono text-neutral-400">
            {minutes}:{seconds.toString().padStart(2, '0')}
          </span>
          {fileTransferAllowed && (
            <label className="cursor-pointer text-xs text-neutral-300 underline">
              Send file
              <input
                type="file"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) sendFile(file);
                  e.target.value = '';
                }}
              />
            </label>
          )}
          {clipboardSyncAllowed && <span className="text-xs text-neutral-500">Clipboard sync on</span>}
          <Button variant="destructive" onClick={endSession}>
            End Session
          </Button>
        </div>
      </div>
      <div className="flex flex-1 items-center justify-center overflow-auto">
        <canvas ref={canvasRef} className="max-h-full max-w-full cursor-none border border-neutral-800" />
      </div>
    </div>
  );
}
