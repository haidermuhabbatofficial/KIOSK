export interface AuthenticatedUser {
  id: string;
  username: string;
  email: string;
  branchId: string | null;
  roles: string[];
  permissions: string[];
}

export interface Branch {
  id: string;
  name: string;
  code: string;
  address?: string | null;
  phone?: string | null;
  email?: string | null;
  logoUrl?: string | null;
  status: 'ACTIVE' | 'DISABLED';
  createdAt: string;
}

export interface Kiosk {
  id: string;
  kioskCode: string;
  deviceName: string;
  branchId: string;
  status: 'REGISTERED' | 'ACTIVE' | 'DISABLED' | 'DECOMMISSIONED';
  onlineStatus: 'ONLINE' | 'OFFLINE' | 'UPDATING';
  windowsVersion?: string | null;
  ipAddress?: string | null;
  clientVersion?: string | null;
  policyVersion: number;
  createdAt: string;
}

export interface WebsiteRule {
  id: string;
  branchId: string | null;
  categoryId: string | null;
  type: 'DOMAIN' | 'EXACT_URL' | 'WILDCARD';
  action: 'ALLOW' | 'BLOCK';
  pattern: string;
  isActive: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  branchId: string | null;
  isActive: boolean;
  userRoles: { role: { name: string } }[];
  branch: Branch | null;
}

export interface Role {
  id: string;
  name: 'SUPER_ADMIN' | 'BRANCH_ADMIN' | 'KIOSK_ADMIN' | 'USER';
  permissions: string[];
}

export interface ApplicationVersion {
  id: string;
  version: string;
  executablePath?: string | null;
  installerUrl?: string | null;
  sha256: string;
  releaseDate: string;
  isActive: boolean;
}

export interface Application {
  id: string;
  name: string;
  publisher?: string | null;
  branchId: string | null;
  status: 'APPROVED' | 'DISABLED';
  versions: ApplicationVersion[];
}

export interface KioskMenuItem {
  id: string;
  label: string;
  iconUrl?: string | null;
  targetType: 'WEBSITE' | 'APPLICATION';
  targetValue: string;
  sortOrder: number;
}

export interface KioskMenu {
  id: string;
  branchId: string;
  name: string;
  theme: string;
  backgroundUrl?: string | null;
  logoUrl?: string | null;
  items: KioskMenuItem[];
  kiosks: Kiosk[];
}

export interface AuditLog {
  id: string;
  action: string;
  result: 'SUCCESS' | 'FAILURE' | 'BLOCKED';
  entityType?: string | null;
  entityId?: string | null;
  createdAt: string;
  user?: { name: string; username: string } | null;
  kiosk?: { deviceName: string; kioskCode: string } | null;
}
