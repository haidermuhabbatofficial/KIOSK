'use client';

import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Settings {
  platformName: string;
  registrationCodeTtlMinutes: number;
  remoteSessionTtlMinutes: number;
  defaultBlockedNavigationBehavior: string;
}

export default function SettingsPage() {
  const queryClient = useQueryClient();
  const settingsQuery = useQuery({ queryKey: ['settings'], queryFn: () => api.get<Settings>('/api/settings') });
  const [form, setForm] = useState<Settings | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (settingsQuery.data) setForm(settingsQuery.data);
  }, [settingsQuery.data]);

  const saveField = useMutation({
    mutationFn: ({ key, value }: { key: string; value: unknown }) => api.put(`/api/settings/${key}`, { value }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['settings'] }),
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to save'),
  });

  if (!form) return null;

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">System Settings</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Instance-wide defaults. Per-branch behavior (website rules, applications, kiosk lockdown) lives on their
        own pages — this is only for platform-level configuration.
      </p>

      {error && <p className="mb-4 text-sm text-destructive">{error}</p>}

      <Card>
        <CardHeader>
          <CardTitle>General</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4 pt-0">
          <Field
            label="Platform Name"
            value={form.platformName}
            onChange={(v) => setForm({ ...form, platformName: v })}
            onSave={() => saveField.mutate({ key: 'platformName', value: form.platformName })}
            saving={saveField.isPending}
          />
          <Field
            label="Registration Code TTL (minutes)"
            type="number"
            value={String(form.registrationCodeTtlMinutes)}
            onChange={(v) => setForm({ ...form, registrationCodeTtlMinutes: Number(v) })}
            onSave={() => saveField.mutate({ key: 'registrationCodeTtlMinutes', value: form.registrationCodeTtlMinutes })}
            saving={saveField.isPending}
          />
          <Field
            label="Remote Support Session TTL (minutes)"
            type="number"
            value={String(form.remoteSessionTtlMinutes)}
            onChange={(v) => setForm({ ...form, remoteSessionTtlMinutes: Number(v) })}
            onSave={() => saveField.mutate({ key: 'remoteSessionTtlMinutes', value: form.remoteSessionTtlMinutes })}
            saving={saveField.isPending}
          />
        </CardContent>
      </Card>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  onSave,
  saving,
  type = 'text',
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onSave: () => void;
  saving: boolean;
  type?: string;
}) {
  return (
    <div className="flex items-end gap-3">
      <div className="flex-1 max-w-sm">
        <label className="mb-1 block text-xs font-medium text-muted-foreground">{label}</label>
        <Input type={type} value={value} onChange={(e) => onChange(e.target.value)} />
      </div>
      <Button variant="outline" onClick={onSave} disabled={saving}>
        Save
      </Button>
    </div>
  );
}
