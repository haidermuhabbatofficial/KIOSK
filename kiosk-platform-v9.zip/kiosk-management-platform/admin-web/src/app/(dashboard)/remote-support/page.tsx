'use client';

import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { RemoteSessionViewer } from '@/components/remote-session-viewer';
import type { Kiosk } from '@/types/api';

interface ActiveSession {
  sessionId: string;
  token: string;
  kioskName: string;
  fileTransferAllowed: boolean;
  clipboardSyncAllowed: boolean;
}

export default function RemoteSupportPage() {
  const kiosksQuery = useQuery({ queryKey: ['kiosks'], queryFn: () => api.get<Kiosk[]>('/api/kiosks') });
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fileTransferAllowed, setFileTransferAllowed] = useState(false);
  const [clipboardSyncAllowed, setClipboardSyncAllowed] = useState(false);

  const startSession = useMutation({
    mutationFn: (kiosk: Kiosk) =>
      api.post<{ sessionId: string; token: string; fileTransferAllowed: boolean; clipboardSyncAllowed: boolean }>(
        '/api/remote/sessions',
        { kioskId: kiosk.id, fileTransferAllowed, clipboardSyncAllowed },
      ),
    onSuccess: (data, kiosk) => {
      setActiveSession({
        sessionId: data.sessionId,
        token: data.token,
        kioskName: kiosk.deviceName,
        fileTransferAllowed: data.fileTransferAllowed,
        clipboardSyncAllowed: data.clipboardSyncAllowed,
      });
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to start remote session'),
  });

  const onlineKiosks = kiosksQuery.data?.filter((k) => k.onlineStatus === 'ONLINE') ?? [];
  const offlineKiosks = kiosksQuery.data?.filter((k) => k.onlineStatus !== 'ONLINE') ?? [];

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">Remote Support</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Sessions are disabled by default, time-limited, encrypted end-to-end (WebRTC/DTLS), and fully audited —
        starting one here is the only way it ever turns on for a kiosk.
      </p>

      {error && <p className="mb-4 text-sm text-destructive">{error}</p>}

      <div className="mb-4 flex flex-wrap gap-4 text-sm">
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={fileTransferAllowed}
            onChange={(e) => setFileTransferAllowed(e.target.checked)}
            className="h-4 w-4 accent-primary"
          />
          Allow file transfer for the next session
        </label>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={clipboardSyncAllowed}
            onChange={(e) => setClipboardSyncAllowed(e.target.checked)}
            className="h-4 w-4 accent-primary"
          />
          Allow clipboard sync for the next session
        </label>
      </div>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Kiosk</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody>
              {onlineKiosks.map((k) => (
                <tr key={k.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3">
                    <p className="font-medium">{k.deviceName}</p>
                    <p className="text-xs text-muted-foreground">{k.kioskCode}</p>
                  </td>
                  <td className="px-5 py-3">
                    <Badge tone="green">ONLINE</Badge>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <Button onClick={() => startSession.mutate(k)} disabled={startSession.isPending}>
                      Start Remote Session
                    </Button>
                  </td>
                </tr>
              ))}
              {offlineKiosks.map((k) => (
                <tr key={k.id} className="border-b border-border opacity-50 last:border-0">
                  <td className="px-5 py-3">
                    <p className="font-medium">{k.deviceName}</p>
                    <p className="text-xs text-muted-foreground">{k.kioskCode}</p>
                  </td>
                  <td className="px-5 py-3">
                    <Badge tone="red">{k.onlineStatus}</Badge>
                  </td>
                  <td className="px-5 py-3 text-right text-xs text-muted-foreground">Offline — can&apos;t connect</td>
                </tr>
              ))}
              {kiosksQuery.data?.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-5 py-6 text-center text-muted-foreground">
                    No kiosks registered yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {activeSession && (
        <RemoteSessionViewer
          sessionId={activeSession.sessionId}
          token={activeSession.token}
          kioskName={activeSession.kioskName}
          fileTransferAllowed={activeSession.fileTransferAllowed}
          clipboardSyncAllowed={activeSession.clipboardSyncAllowed}
          onClose={() => setActiveSession(null)}
        />
      )}
    </div>
  );
}
