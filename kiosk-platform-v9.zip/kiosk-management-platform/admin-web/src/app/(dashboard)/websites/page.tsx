'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch, WebsiteRule } from '@/types/api';

export default function WebsitesPage() {
  const queryClient = useQueryClient();
  const rulesQuery = useQuery({ queryKey: ['website-rules'], queryFn: () => api.get<WebsiteRule[]>('/api/websites/rules') });
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });

  const [pattern, setPattern] = useState('');
  const [type, setType] = useState<WebsiteRule['type']>('DOMAIN');
  const [action, setAction] = useState<WebsiteRule['action']>('ALLOW');
  const [branchId, setBranchId] = useState<string>(''); // empty = global rule
  const [error, setError] = useState<string | null>(null);

  const createRule = useMutation({
    mutationFn: () =>
      api.post<WebsiteRule>('/api/websites/rules', {
        pattern,
        type,
        action,
        branchId: branchId || undefined,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['website-rules'] });
      setPattern('');
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to create rule'),
  });

  const deleteRule = useMutation({
    mutationFn: (id: string) => api.delete(`/api/websites/rules/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['website-rules'] }),
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    createRule.mutate();
  }

  const branchName = (id: string | null) => (id ? branchesQuery.data?.find((b) => b.id === id)?.name ?? id : 'All branches');

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">Allowed Websites</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Priority: an explicit <span className="font-medium text-foreground">Block</span> always wins, then an
        explicit <span className="font-medium text-foreground">Allow</span>, then the kiosk&apos;s default (deny in
        allowlist mode).
      </p>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add Rule</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Pattern</label>
              <Input value={pattern} onChange={(e) => setPattern(e.target.value)} placeholder="google.com" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as WebsiteRule['type'])}
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="DOMAIN">Domain</option>
                <option value="EXACT_URL">Exact URL</option>
                <option value="WILDCARD">Wildcard</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Action</label>
              <select
                value={action}
                onChange={(e) => setAction(e.target.value as WebsiteRule['action'])}
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="ALLOW">Allow</option>
                <option value="BLOCK">Block</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="">All branches (global)</option>
                {branchesQuery.data?.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <Button type="submit" disabled={createRule.isPending}>
              {createRule.isPending ? 'Adding…' : 'Add Rule'}
            </Button>
          </form>
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Pattern</th>
                <th className="px-5 py-3">Type</th>
                <th className="px-5 py-3">Action</th>
                <th className="px-5 py-3">Scope</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody>
              {rulesQuery.data?.map((rule) => (
                <tr key={rule.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3 font-mono">{rule.pattern}</td>
                  <td className="px-5 py-3 text-muted-foreground">{rule.type}</td>
                  <td className="px-5 py-3">
                    <Badge tone={rule.action === 'ALLOW' ? 'green' : 'red'}>{rule.action}</Badge>
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{branchName(rule.branchId)}</td>
                  <td className="px-5 py-3 text-right">
                    <Button variant="ghost" onClick={() => deleteRule.mutate(rule.id)} disabled={deleteRule.isPending}>
                      Remove
                    </Button>
                  </td>
                </tr>
              ))}
              {rulesQuery.data?.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-6 text-center text-muted-foreground">
                    No rules yet — in allowlist mode, no rules means every site is blocked by default.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
