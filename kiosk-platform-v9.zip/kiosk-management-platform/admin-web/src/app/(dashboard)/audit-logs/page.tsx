'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import type { AuditLog } from '@/types/api';

const resultTone = { SUCCESS: 'green', FAILURE: 'red', BLOCKED: 'yellow' } as const;

export default function AuditLogsPage() {
  const [actionFilter, setActionFilter] = useState('');

  const logsQuery = useQuery({
    queryKey: ['audit-logs', actionFilter],
    queryFn: () =>
      api.get<AuditLog[]>(`/api/audit-logs${actionFilter ? `?action=${encodeURIComponent(actionFilter)}` : ''}`),
  });

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">Activity Logs</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Every security-sensitive action — branch/kiosk/website/policy changes, remote sessions, blocked-site
        attempts — most recent 300 shown.
      </p>

      <div className="mb-4 max-w-xs">
        <Input
          placeholder="Filter by action, e.g. kiosk.restart"
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
        />
      </div>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Time</th>
                <th className="px-5 py-3">Action</th>
                <th className="px-5 py-3">By</th>
                <th className="px-5 py-3">Kiosk</th>
                <th className="px-5 py-3">Result</th>
              </tr>
            </thead>
            <tbody>
              {logsQuery.data?.map((log) => (
                <tr key={log.id} className="border-b border-border last:border-0">
                  <td className="whitespace-nowrap px-5 py-2.5 text-muted-foreground">
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                  <td className="px-5 py-2.5 font-mono text-xs">{log.action}</td>
                  <td className="px-5 py-2.5 text-muted-foreground">{log.user?.username ?? '—'}</td>
                  <td className="px-5 py-2.5 text-muted-foreground">
                    {log.kiosk ? `${log.kiosk.deviceName} (${log.kiosk.kioskCode})` : '—'}
                  </td>
                  <td className="px-5 py-2.5">
                    <Badge tone={resultTone[log.result]}>{log.result}</Badge>
                  </td>
                </tr>
              ))}
              {logsQuery.data?.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-6 text-center text-muted-foreground">
                    No activity recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
