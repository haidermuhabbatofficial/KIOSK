'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Role } from '@/types/api';

export default function RolesPage() {
  const queryClient = useQueryClient();
  const rolesQuery = useQuery({ queryKey: ['roles'], queryFn: () => api.get<Role[]>('/api/roles') });
  const permissionsQuery = useQuery({
    queryKey: ['permissions'],
    queryFn: () => api.get<string[]>('/api/permissions'),
  });

  const updatePermissions = useMutation({
    mutationFn: ({ roleId, permissions }: { roleId: string; permissions: string[] }) =>
      api.patch(`/api/roles/${roleId}/permissions`, { permissions }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['roles'] }),
  });

  function toggle(role: Role, key: string) {
    const next = role.permissions.includes(key)
      ? role.permissions.filter((p) => p !== key)
      : [...role.permissions, key];
    updatePermissions.mutate({ roleId: role.id, permissions: next });
  }

  const roles = rolesQuery.data ?? [];
  const permissions = permissionsQuery.data ?? [];

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">Roles &amp; Permissions</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Super Admin always has every permission and can&apos;t be edited here — that&apos;s enforced by the API, not
        just hidden in this UI.
      </p>

      <Card>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="sticky left-0 bg-card px-5 py-3">Permission</th>
                {roles.map((role) => (
                  <th key={role.id} className="px-5 py-3 text-center">
                    {role.name.replace('_', ' ')}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {permissions.map((key) => (
                <tr key={key} className="border-b border-border last:border-0">
                  <td className="sticky left-0 bg-card px-5 py-2 font-mono text-xs">{key}</td>
                  {roles.map((role) => {
                    const isSuperAdmin = role.name === 'SUPER_ADMIN';
                    const checked = role.permissions.includes(key);
                    return (
                      <td key={role.id} className="px-5 py-2 text-center">
                        <input
                          type="checkbox"
                          checked={checked}
                          disabled={isSuperAdmin || updatePermissions.isPending}
                          onChange={() => toggle(role, key)}
                          className="h-4 w-4 accent-primary disabled:opacity-40"
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
