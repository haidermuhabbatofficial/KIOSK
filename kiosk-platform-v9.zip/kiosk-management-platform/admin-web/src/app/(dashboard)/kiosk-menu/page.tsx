'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch, Kiosk, KioskMenu } from '@/types/api';

export default function KioskMenuPage() {
  const queryClient = useQueryClient();
  const menusQuery = useQuery({ queryKey: ['kiosk-menus'], queryFn: () => api.get<KioskMenu[]>('/api/kiosk-menus') });
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });
  const kiosksQuery = useQuery({ queryKey: ['kiosks'], queryFn: () => api.get<Kiosk[]>('/api/kiosks') });

  const [menuName, setMenuName] = useState('');
  const [menuBranchId, setMenuBranchId] = useState('');
  const [error, setError] = useState<string | null>(null);

  const [itemMenuId, setItemMenuId] = useState<string | null>(null);
  const [label, setLabel] = useState('');
  const [targetType, setTargetType] = useState<'WEBSITE' | 'APPLICATION'>('WEBSITE');
  const [targetValue, setTargetValue] = useState('');

  const createMenu = useMutation({
    mutationFn: () => api.post<KioskMenu>('/api/kiosk-menus', { name: menuName, branchId: menuBranchId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kiosk-menus'] });
      setMenuName('');
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to create menu'),
  });

  const addItem = useMutation({
    mutationFn: () => api.post(`/api/kiosk-menus/${itemMenuId}/items`, { label, targetType, targetValue }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kiosk-menus'] });
      setLabel('');
      setTargetValue('');
    },
  });

  const removeItem = useMutation({
    mutationFn: ({ menuId, itemId }: { menuId: string; itemId: string }) =>
      api.delete(`/api/kiosk-menus/${menuId}/items/${itemId}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['kiosk-menus'] }),
  });

  const assignMenu = useMutation({
    mutationFn: ({ menuId, kioskId }: { menuId: string; kioskId: string }) =>
      api.post(`/api/kiosk-menus/${menuId}/assign/${kioskId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kiosk-menus'] });
      queryClient.invalidateQueries({ queryKey: ['kiosks'] });
    },
  });

  function handleCreateMenu(e: FormEvent) {
    e.preventDefault();
    createMenu.mutate();
  }

  function handleAddItem(e: FormEvent) {
    e.preventDefault();
    addItem.mutate();
  }

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold">Kiosk Menu</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Create Menu</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleCreateMenu} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Menu Name</label>
              <Input value={menuName} onChange={(e) => setMenuName(e.target.value)} placeholder="Default Menu" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch</label>
              <select
                value={menuBranchId}
                onChange={(e) => setMenuBranchId(e.target.value)}
                required
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="" disabled>
                  Select branch
                </option>
                {branchesQuery.data?.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <Button type="submit" disabled={createMenu.isPending}>
              {createMenu.isPending ? 'Creating…' : 'Create Menu'}
            </Button>
          </form>
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      <div className="space-y-4">
        {menusQuery.data?.map((menu) => {
          const branch = branchesQuery.data?.find((b) => b.id === menu.branchId);
          const branchKiosks = kiosksQuery.data?.filter((k) => k.branchId === menu.branchId) ?? [];

          return (
            <Card key={menu.id}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{menu.name}</p>
                    <p className="text-xs text-muted-foreground">{branch?.name}</p>
                  </div>
                  <Button variant="ghost" onClick={() => setItemMenuId(itemMenuId === menu.id ? null : menu.id)}>
                    + Menu Item
                  </Button>
                </div>

                {menu.items.length > 0 && (
                  <ul className="mt-3 space-y-1 text-sm">
                    {menu.items
                      .slice()
                      .sort((a, b) => a.sortOrder - b.sortOrder)
                      .map((item) => (
                        <li key={item.id} className="flex items-center justify-between rounded-md bg-muted px-3 py-1.5">
                          <span>
                            <span className="font-medium">{item.label}</span>{' '}
                            <span className="text-xs text-muted-foreground">
                              ({item.targetType.toLowerCase()}: {item.targetValue})
                            </span>
                          </span>
                          <button
                            className="text-xs text-destructive hover:underline"
                            onClick={() => removeItem.mutate({ menuId: menu.id, itemId: item.id })}
                          >
                            Remove
                          </button>
                        </li>
                      ))}
                  </ul>
                )}

                {itemMenuId === menu.id && (
                  <form onSubmit={handleAddItem} className="mt-4 flex flex-wrap items-end gap-3 border-t border-border pt-4">
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Label</label>
                      <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Student Portal" required />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">Type</label>
                      <select
                        value={targetType}
                        onChange={(e) => setTargetType(e.target.value as 'WEBSITE' | 'APPLICATION')}
                        className="h-10 rounded-md border border-border bg-card px-3 text-sm"
                      >
                        <option value="WEBSITE">Website</option>
                        <option value="APPLICATION">Application</option>
                      </select>
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-muted-foreground">
                        {targetType === 'WEBSITE' ? 'URL' : 'Application ID'}
                      </label>
                      <Input
                        value={targetValue}
                        onChange={(e) => setTargetValue(e.target.value)}
                        placeholder={targetType === 'WEBSITE' ? 'https://portal.example.edu' : 'app-uuid'}
                        className="w-72"
                        required
                      />
                    </div>
                    <Button type="submit" disabled={addItem.isPending}>
                      {addItem.isPending ? 'Adding…' : 'Add Item'}
                    </Button>
                  </form>
                )}

                {branchKiosks.length > 0 && (
                  <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-4">
                    <span className="text-xs font-medium text-muted-foreground">Assign to kiosk:</span>
                    {branchKiosks.map((k) => (
                      <Button
                        key={k.id}
                        variant="outline"
                        onClick={() => assignMenu.mutate({ menuId: menu.id, kioskId: k.id })}
                        disabled={assignMenu.isPending}
                        className="h-8 px-2 text-xs"
                      >
                        {k.deviceName}
                      </Button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}

        {menusQuery.data?.length === 0 && (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">No menus yet — create one above.</CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
