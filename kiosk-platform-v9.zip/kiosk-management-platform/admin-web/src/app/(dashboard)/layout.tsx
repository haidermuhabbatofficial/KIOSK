'use client';

import { ReactNode, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { LayoutDashboard, Building2, Monitor, Globe, Users, ShieldCheck, Package, LayoutGrid, ScrollText, Video, Lock, Settings as SettingsIcon, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/branches', label: 'Branches', icon: Building2 },
  { href: '/kiosks', label: 'Kiosks', icon: Monitor },
  { href: '/remote-support', label: 'Remote Support', icon: Video },
  { href: '/websites', label: 'Websites', icon: Globe },
  { href: '/applications', label: 'Applications', icon: Package },
  { href: '/kiosk-menu', label: 'Kiosk Menu', icon: LayoutGrid },
  { href: '/policies', label: 'Policies', icon: Lock },
  { href: '/users', label: 'Users', icon: Users },
  { href: '/roles', label: 'Roles & Permissions', icon: ShieldCheck },
  { href: '/audit-logs', label: 'Activity Logs', icon: ScrollText },
  { href: '/settings', label: 'System Settings', icon: SettingsIcon },
];

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { user, loading, logout } = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace('/login');
  }, [loading, user, router]);

  if (loading || !user) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="flex min-h-screen">
      <aside className="flex w-56 flex-col border-r border-border bg-card">
        <div className="border-b border-border px-4 py-4">
          <p className="text-sm font-semibold">Kiosk Platform</p>
          <p className="text-xs text-muted-foreground">{user.username}</p>
        </div>
        <nav className="flex-1 space-y-1 p-2">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-muted',
                pathname.startsWith(href) && 'bg-muted text-primary',
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          ))}
        </nav>
        <button
          onClick={logout}
          className="flex items-center gap-2 border-t border-border px-4 py-3 text-sm text-muted-foreground hover:text-foreground"
        >
          <LogOut size={16} /> Log out
        </button>
      </aside>
      <main className="flex-1 overflow-y-auto p-6">{children}</main>
    </div>
  );
}
