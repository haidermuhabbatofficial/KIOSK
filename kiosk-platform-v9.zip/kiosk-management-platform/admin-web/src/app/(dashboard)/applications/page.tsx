'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Application, Branch } from '@/types/api';

export default function ApplicationsPage() {
  const queryClient = useQueryClient();
  const appsQuery = useQuery({ queryKey: ['applications'], queryFn: () => api.get<Application[]>('/api/applications') });
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });

  const [name, setName] = useState('');
  const [publisher, setPublisher] = useState('');
  const [branchId, setBranchId] = useState('');
  const [error, setError] = useState<string | null>(null);

  const [versionAppId, setVersionAppId] = useState<string | null>(null);
  const [version, setVersion] = useState('');
  const [executablePath, setExecutablePath] = useState('');
  const [sha256, setSha256] = useState('');

  const createApp = useMutation({
    mutationFn: () => api.post<Application>('/api/applications', { name, publisher, branchId: branchId || undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['applications'] });
      setName('');
      setPublisher('');
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to create application'),
  });

  const addVersion = useMutation({
    mutationFn: () =>
      api.post(`/api/applications/${versionAppId}/versions`, { version, executablePath, sha256 }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['applications'] });
      setVersionAppId(null);
      setVersion('');
      setExecutablePath('');
      setSha256('');
    },
  });

  const toggleStatus = useMutation({
    mutationFn: ({ id, approve }: { id: string; approve: boolean }) =>
      api.patch(`/api/applications/${id}/${approve ? 'approve' : 'disable'}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['applications'] }),
  });

  function handleCreateApp(e: FormEvent) {
    e.preventDefault();
    createApp.mutate();
  }

  function handleAddVersion(e: FormEvent) {
    e.preventDefault();
    addVersion.mutate();
  }

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold">Applications</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add Application</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleCreateApp} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Microsoft Word" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Publisher</label>
              <Input value={publisher} onChange={(e) => setPublisher(e.target.value)} placeholder="Microsoft" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="">All branches (global)</option>
                {branchesQuery.data?.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <Button type="submit" disabled={createApp.isPending}>
              {createApp.isPending ? 'Adding…' : 'Add Application'}
            </Button>
          </form>
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      <div className="space-y-4">
        {appsQuery.data?.map((app) => (
          <Card key={app.id}>
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">
                    {app.name} {app.publisher && <span className="text-muted-foreground">— {app.publisher}</span>}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {app.branchId ? branchesQuery.data?.find((b) => b.id === app.branchId)?.name : 'All branches'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={app.status === 'APPROVED' ? 'green' : 'gray'}>{app.status}</Badge>
                  <Button
                    variant="outline"
                    onClick={() => toggleStatus.mutate({ id: app.id, approve: app.status !== 'APPROVED' })}
                  >
                    {app.status === 'APPROVED' ? 'Disable' : 'Approve'}
                  </Button>
                  <Button variant="ghost" onClick={() => setVersionAppId(versionAppId === app.id ? null : app.id)}>
                    + Version
                  </Button>
                </div>
              </div>

              {app.versions.length > 0 && (
                <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
                  {app.versions.map((v) => (
                    <li key={v.id} className="font-mono">
                      v{v.version} — sha256:{v.sha256.slice(0, 12)}… {v.isActive ? '' : '(inactive)'}
                    </li>
                  ))}
                </ul>
              )}

              {versionAppId === app.id && (
                <form onSubmit={handleAddVersion} className="mt-4 flex flex-wrap items-end gap-3 border-t border-border pt-4">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Version</label>
                    <Input value={version} onChange={(e) => setVersion(e.target.value)} placeholder="1.0.0" required />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Executable Path</label>
                    <Input
                      value={executablePath}
                      onChange={(e) => setExecutablePath(e.target.value)}
                      placeholder="C:\Program Files\..."
                      className="w-64"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">SHA-256</label>
                    <Input value={sha256} onChange={(e) => setSha256(e.target.value)} className="w-72 font-mono" required />
                  </div>
                  <Button type="submit" disabled={addVersion.isPending}>
                    {addVersion.isPending ? 'Publishing…' : 'Publish Version'}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        ))}

        {appsQuery.data?.length === 0 && (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">No applications yet — add one above.</CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
