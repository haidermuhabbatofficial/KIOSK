'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch } from '@/types/api';

export default function BranchesPage() {
  const queryClient = useQueryClient();
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });

  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const createBranch = useMutation({
    mutationFn: () => api.post<Branch>('/api/branches', { name, code }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      setName('');
      setCode('');
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to create branch'),
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    createBranch.mutate();
  }

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold">Branches</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add Branch</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch Name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Okara Campus" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch Code</label>
              <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="OKR-01" required />
            </div>
            <Button type="submit" disabled={createBranch.isPending}>
              {createBranch.isPending ? 'Adding…' : 'Add Branch'}
            </Button>
          </form>
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Name</th>
                <th className="px-5 py-3">Code</th>
                <th className="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {branchesQuery.data?.map((branch) => (
                <tr key={branch.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3 font-medium">{branch.name}</td>
                  <td className="px-5 py-3 text-muted-foreground">{branch.code}</td>
                  <td className="px-5 py-3">
                    <Badge tone={branch.status === 'ACTIVE' ? 'green' : 'gray'}>{branch.status}</Badge>
                  </td>
                </tr>
              ))}
              {branchesQuery.data?.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-5 py-6 text-center text-muted-foreground">
                    No branches yet — add one above.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
