'use client';

import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch } from '@/types/api';

interface WindowsLockdownConfig {
  disableTaskManager: boolean;
  disableControlPanel: boolean;
  disableRegistryEditor: boolean;
  disableCommandPrompt: boolean;
  disableRun: boolean;
  blockUsbStorage: boolean;
}

interface SecurityConfig {
  sessionTimeoutMinutes: number;
  autoRestartTime: string;
  lockScreenEnabled: boolean;
}

const LOCKDOWN_LABELS: Record<keyof WindowsLockdownConfig, string> = {
  disableTaskManager: 'Disable Task Manager',
  disableControlPanel: 'Disable Control Panel',
  disableRegistryEditor: 'Disable Registry Editor',
  disableCommandPrompt: 'Disable Command Prompt',
  disableRun: 'Disable Run dialog',
  blockUsbStorage: 'Block USB storage devices',
};

const EMPTY_LOCKDOWN: WindowsLockdownConfig = {
  disableTaskManager: false,
  disableControlPanel: false,
  disableRegistryEditor: false,
  disableCommandPrompt: false,
  disableRun: false,
  blockUsbStorage: false,
};

const EMPTY_SECURITY: SecurityConfig = { sessionTimeoutMinutes: 0, autoRestartTime: '', lockScreenEnabled: false };

export default function PoliciesPage() {
  const queryClient = useQueryClient();
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });
  const [branchId, setBranchId] = useState('');

  const policiesQuery = useQuery({
    queryKey: ['policies', branchId],
    queryFn: () => api.get<{ scope: string; config: Record<string, unknown> }[]>(`/api/policies?branchId=${branchId}`),
    enabled: !!branchId,
  });

  const [lockdown, setLockdown] = useState<WindowsLockdownConfig>(EMPTY_LOCKDOWN);
  const [security, setSecurity] = useState<SecurityConfig>(EMPTY_SECURITY);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!branchesQuery.data?.length) return;
    if (!branchId) setBranchId(branchesQuery.data[0].id);
  }, [branchesQuery.data, branchId]);

  useEffect(() => {
    const windowsPolicy = policiesQuery.data?.find((p) => p.scope === 'WINDOWS');
    const securityPolicy = policiesQuery.data?.find((p) => p.scope === 'SECURITY');
    setLockdown({ ...EMPTY_LOCKDOWN, ...(windowsPolicy?.config as Partial<WindowsLockdownConfig>) });
    setSecurity({ ...EMPTY_SECURITY, ...(securityPolicy?.config as Partial<SecurityConfig>) });
  }, [policiesQuery.data]);

  const saveLockdown = useMutation({
    mutationFn: () => api.put('/api/policies', { branchId, scope: 'WINDOWS', config: lockdown }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['policies', branchId] });
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to save'),
  });

  const saveSecurity = useMutation({
    mutationFn: () => api.put('/api/policies', { branchId, scope: 'SECURITY', config: security }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['policies', branchId] }),
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to save'),
  });

  return (
    <div>
      <h1 className="mb-1 text-2xl font-semibold">Policies</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Applied by the kiosk service via Windows registry policy keys — takes effect on the kiosk&apos;s next
        lockdown-policy check (every few minutes), no reboot required for most settings.
      </p>

      <div className="mb-6 max-w-xs">
        <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch</label>
        <select
          value={branchId}
          onChange={(e) => setBranchId(e.target.value)}
          className="h-10 w-full rounded-md border border-border bg-card px-3 text-sm"
        >
          {branchesQuery.data?.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      {error && <p className="mb-4 text-sm text-destructive">{error}</p>}

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Windows Lockdown</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 gap-3">
            {(Object.keys(LOCKDOWN_LABELS) as (keyof WindowsLockdownConfig)[]).map((key) => (
              <label key={key} className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={lockdown[key]}
                  onChange={(e) => setLockdown({ ...lockdown, [key]: e.target.checked })}
                  className="h-4 w-4 accent-primary"
                />
                {LOCKDOWN_LABELS[key]}
              </label>
            ))}
          </div>
          <Button className="mt-4" onClick={() => saveLockdown.mutate()} disabled={saveLockdown.isPending || !branchId}>
            {saveLockdown.isPending ? 'Saving…' : 'Save Windows Lockdown'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Security Policy</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap items-end gap-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Session Timeout (minutes)</label>
              <Input
                type="number"
                min={0}
                value={security.sessionTimeoutMinutes}
                onChange={(e) => setSecurity({ ...security, sessionTimeoutMinutes: Number(e.target.value) })}
                className="w-40"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Auto Restart Time (HH:mm)</label>
              <Input
                value={security.autoRestartTime}
                onChange={(e) => setSecurity({ ...security, autoRestartTime: e.target.value })}
                placeholder="03:00"
                className="w-40"
              />
            </div>
            <label className="flex items-center gap-2 pb-2 text-sm">
              <input
                type="checkbox"
                checked={security.lockScreenEnabled}
                onChange={(e) => setSecurity({ ...security, lockScreenEnabled: e.target.checked })}
                className="h-4 w-4 accent-primary"
              />
              Enable lock screen on idle
            </label>
          </div>
          <Button className="mt-4" onClick={() => saveSecurity.mutate()} disabled={saveSecurity.isPending || !branchId}>
            {saveSecurity.isPending ? 'Saving…' : 'Save Security Policy'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
