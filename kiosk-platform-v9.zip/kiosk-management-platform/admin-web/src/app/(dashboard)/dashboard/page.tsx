'use client';

import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch, Kiosk } from '@/types/api';

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{label}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-3xl font-semibold">{value}</p>
      </CardContent>
    </Card>
  );
}

export default function DashboardPage() {
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });
  const kiosksQuery = useQuery({ queryKey: ['kiosks'], queryFn: () => api.get<Kiosk[]>('/api/kiosks') });

  const kiosks = kiosksQuery.data ?? [];
  const online = kiosks.filter((k) => k.onlineStatus === 'ONLINE').length;
  const offline = kiosks.filter((k) => k.onlineStatus === 'OFFLINE').length;
  const updating = kiosks.filter((k) => k.onlineStatus === 'UPDATING').length;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold">Dashboard</h1>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
        <StatCard label="Total Branches" value={branchesQuery.data?.length ?? '—'} />
        <StatCard label="Total Kiosks" value={kiosks.length} />
        <StatCard label="Online Kiosks" value={online} />
        <StatCard label="Offline Kiosks" value={offline} />
        <StatCard label="Updating Kiosks" value={updating} />
      </div>

      {(branchesQuery.isError || kiosksQuery.isError) && (
        <p className="mt-6 text-sm text-destructive">
          Couldn&apos;t reach the API. Confirm it&apos;s running and NEXT_PUBLIC_API_URL is set correctly.
        </p>
      )}
    </div>
  );
}
