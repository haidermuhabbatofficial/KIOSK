'use client';

import { FormEvent, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Branch, Kiosk } from '@/types/api';

const statusTone = { ONLINE: 'green', OFFLINE: 'red', UPDATING: 'yellow' } as const;

export default function KiosksPage() {
  const queryClient = useQueryClient();
  const kiosksQuery = useQuery({ queryKey: ['kiosks'], queryFn: () => api.get<Kiosk[]>('/api/kiosks') });
  const branchesQuery = useQuery({ queryKey: ['branches'], queryFn: () => api.get<Branch[]>('/api/branches') });

  const [kioskCode, setKioskCode] = useState('');
  const [deviceName, setDeviceName] = useState('');
  const [branchId, setBranchId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [lastCode, setLastCode] = useState<{ kioskId: string; code: string } | null>(null);

  const createKiosk = useMutation({
    mutationFn: () => api.post<Kiosk>('/api/kiosks', { kioskCode, deviceName, branchId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kiosks'] });
      setKioskCode('');
      setDeviceName('');
      setError(null);
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Failed to create kiosk'),
  });

  const generateCode = useMutation({
    mutationFn: (targetBranchId: string) =>
      api.post<{ code: string; expiresAt: string }>('/api/kiosks/registration-codes', { branchId: targetBranchId }),
    onSuccess: (data, targetBranchId) => setLastCode({ kioskId: targetBranchId, code: data.code }),
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    createKiosk.mutate();
  }

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold">Kiosks</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add Kiosk</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Kiosk Code</label>
              <Input value={kioskCode} onChange={(e) => setKioskCode(e.target.value)} placeholder="OKR-KIOSK-001" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Device Name</label>
              <Input value={deviceName} onChange={(e) => setDeviceName(e.target.value)} placeholder="Front Desk" required />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Branch</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                required
                className="h-10 rounded-md border border-border bg-card px-3 text-sm"
              >
                <option value="" disabled>
                  Select branch
                </option>
                {branchesQuery.data?.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <Button type="submit" disabled={createKiosk.isPending}>
              {createKiosk.isPending ? 'Adding…' : 'Add Kiosk'}
            </Button>
            {branchId && (
              <Button type="button" variant="outline" onClick={() => generateCode.mutate(branchId)} disabled={generateCode.isPending}>
                Generate Registration Code
              </Button>
            )}
          </form>
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
          {lastCode && (
            <p className="mt-3 rounded-md bg-muted px-3 py-2 text-sm">
              Registration code: <span className="font-mono font-semibold">{lastCode.code}</span> — valid for 30
              minutes, single use. Pass it to <code>install.ps1</code> as <code>-RegistrationCode</code>.
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Kiosk</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Client Version</th>
                <th className="px-5 py-3">Policy Version</th>
                <th className="px-5 py-3">IP Address</th>
              </tr>
            </thead>
            <tbody>
              {kiosksQuery.data?.map((kiosk) => (
                <tr key={kiosk.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3">
                    <p className="font-medium">{kiosk.deviceName}</p>
                    <p className="text-xs text-muted-foreground">{kiosk.kioskCode}</p>
                  </td>
                  <td className="px-5 py-3">
                    <Badge tone={statusTone[kiosk.onlineStatus]}>{kiosk.onlineStatus}</Badge>
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{kiosk.clientVersion ?? '—'}</td>
                  <td className="px-5 py-3 text-muted-foreground">v{kiosk.policyVersion}</td>
                  <td className="px-5 py-3 text-muted-foreground">{kiosk.ipAddress ?? '—'}</td>
                </tr>
              ))}
              {kiosksQuery.data?.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-6 text-center text-muted-foreground">
                    No kiosks yet — add one above.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
