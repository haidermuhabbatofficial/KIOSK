import type { Metadata } from 'next';
import { QueryProvider } from '@/hooks/query-provider';
import { AuthProvider } from '@/hooks/use-auth';
import './globals.css';

export const metadata: Metadata = {
  title: 'Kiosk Management Platform',
  description: 'Central admin panel for branches, kiosks, policies, and remote support',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <QueryProvider>
          <AuthProvider>{children}</AuthProvider>
        </QueryProvider>
      </body>
    </html>
  );
}
