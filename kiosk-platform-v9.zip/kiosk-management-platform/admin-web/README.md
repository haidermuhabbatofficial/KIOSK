# Kiosk Management Platform — Admin Web

Next.js 15 (App Router) + TypeScript + Tailwind admin panel, talking directly to the
NestJS API. No mock data anywhere — every page is wired to a real endpoint from
`api-server`.

## What's implemented

- **Auth**: login page, token storage (access + refresh in `localStorage`), automatic
  refresh-on-401 with request coalescing, route-guarded dashboard layout.
- **Dashboard**: live stat cards (branches, kiosks, online/offline/updating counts).
- **Branches**: list + create.
- **Kiosks**: list with live status/version/policy-version columns, create, and
  **registration code generation** — the exact code your `install.ps1` /
  `RegistrationService.cs` flow expects.
- **Websites**: the allowlist/blocklist rule engine's admin UI — create/list/delete
  rules (domain/exact/wildcard, allow/block, global or branch-scoped), with the
  priority order spelled out on-screen so nobody has to guess it.
- **Applications**: allowlist CRUD, per-app version publishing (executable path +
  SHA-256), approve/disable toggle.
- **Users**: list + create with role and branch assignment, deactivate.
- **Roles & Permissions**: a permission matrix per role — click a checkbox, it PATCHes
  immediately. SUPER_ADMIN's row is disabled (matches the API's hard block).
- **Kiosk Menu**: create menus per branch, add/remove menu items (website or
  application targets), assign a menu to any kiosk in that branch.
- **Activity Logs**: filterable table over every audit-logged action across the platform.
- **Remote Support**: list online kiosks, start a session, and control the kiosk live —
  a real `RTCPeerConnection` connects through the signaling gateway, renders screen
  frames pushed over a DataChannel onto a canvas, and forwards mouse/keyboard events
  back the same way. Optional per-session file transfer and clipboard sync, gated by
  checkboxes at session start. See the note on frame delivery below.
- **Policies**: Windows lockdown toggles (Task Manager, Control Panel, Registry Editor,
  Command Prompt, Run, USB storage) and security policy (session timeout, auto-restart
  time, lock screen) per branch.
- **System Settings**: instance-wide config (platform name, registration code TTL,
  remote session TTL) — Super Admin only.

## Not yet built

Users/Roles UI is done; what's left against spec §35's full sidebar is mostly
deeper policy config (application/browser policy beyond what's here) and anything
tied to features not yet built server-side (e.g. file-storage-backed uploads).

## Note on the Remote Support viewer

Screen sharing is periodic JPEG frames pushed over the WebRTC DataChannel, not a
native `RTCVideoTrack` — genuinely WebRTC (DTLS-encrypted, peer-to-peer after
signaling) but it'll look like a slideshow at a couple of frames per second rather
than smooth video. This was a deliberate simplification to avoid needing a full
media-pipeline/codec setup on the .NET side (see `kiosk-client/Services/RemoteAgentService.cs`).
Swap in a real video track later if frame rate matters more than implementation
simplicity.

## Running it locally

```bash
npm install
cp .env.local.example .env.local   # point NEXT_PUBLIC_API_URL at your api-server
npm run dev
```

Requires `api-server` running (see its own README) and seeded — log in with
`superadmin` / `ChangeMe123!` from the seed script.

## Notes

- UI primitives (`components/ui/*`) are hand-written Tailwind components rather than
  the full shadcn/ui CLI scaffold, to keep this buildable without running the shadcn
  generator — swap in real shadcn components anytime; the class-name conventions
  (`cn()`, CSS variables in `globals.css`) already match shadcn's defaults.
- Tokens are stored in `localStorage`, not an httpOnly cookie — simplest for a
  same-origin-or-CORS SPA talking to a separate API host. If you need XSS-hardened
  token storage, move to httpOnly cookies + a Next.js API route proxy instead.
