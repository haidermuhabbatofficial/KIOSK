using KioskClient.Models;

namespace KioskClient.Services;

public enum NavigationDecision
{
    Allow,
    Block,
}

/// <summary>
/// Pure rule-evaluation logic, deliberately separated from WebView2 so it can be unit
/// tested without a browser control. Priority is fixed per spec §11:
///   Explicit Block  >  Explicit Allow  >  Default Policy (deny in allowlist mode).
/// </summary>
public class PolicyEngine
{
    public NavigationDecision Evaluate(KioskPolicy policy, Uri targetUri)
    {
        var host = targetUri.Host.ToLowerInvariant();
        var fullUrl = targetUri.ToString();

        WebsiteRule? matchedBlock = null;
        WebsiteRule? matchedAllow = null;

        foreach (var rule in policy.WebsiteRules)
        {
            if (!Matches(rule, host, fullUrl)) continue;

            if (rule.Action == WebsiteRuleAction.Block)
            {
                matchedBlock = rule;
                // An explicit block always wins outright — stop looking further.
                break;
            }
            else if (matchedAllow is null)
            {
                matchedAllow = rule;
            }
        }

        if (matchedBlock is not null) return NavigationDecision.Block;
        if (matchedAllow is not null) return NavigationDecision.Allow;

        // Default policy: allowlist mode denies anything not explicitly allowed.
        // Non-allowlist ("blocklist only") mode would default-allow instead —
        // exposed here as policy.AllowlistMode so admins can pick §8's mode.
        return policy.AllowlistMode ? NavigationDecision.Block : NavigationDecision.Allow;
    }

    private static bool Matches(WebsiteRule rule, string host, string fullUrl)
    {
        return rule.Type switch
        {
            WebsiteRuleType.Domain => MatchesDomain(rule.Pattern, host),
            WebsiteRuleType.Wildcard => MatchesWildcard(rule.Pattern, host),
            WebsiteRuleType.ExactUrl => string.Equals(
                fullUrl.TrimEnd('/'), rule.Pattern.TrimEnd('/'), StringComparison.OrdinalIgnoreCase),
            _ => false,
        };
    }

    /// <summary>"google.com" matches google.com and any subdomain, e.g. mail.google.com.</summary>
    private static bool MatchesDomain(string pattern, string host)
    {
        pattern = pattern.ToLowerInvariant().TrimStart('*', '.');
        return host == pattern || host.EndsWith("." + pattern, StringComparison.Ordinal);
    }

    /// <summary>"*.school.edu.pk" matches any subdomain but NOT the bare apex domain.</summary>
    private static bool MatchesWildcard(string pattern, string host)
    {
        pattern = pattern.ToLowerInvariant();
        if (pattern.StartsWith("*."))
        {
            var suffix = pattern[1..]; // keep the leading dot: ".school.edu.pk"
            return host.EndsWith(suffix, StringComparison.Ordinal) && host.Length > suffix.Length;
        }
        return host == pattern;
    }
}
