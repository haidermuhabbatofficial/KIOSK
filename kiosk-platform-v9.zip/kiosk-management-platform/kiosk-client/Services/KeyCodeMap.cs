namespace KioskClient.Services;

/// <summary>
/// Not exhaustive — covers letters, digits, navigation, and common control keys.
/// Extend as real-world remote-support usage surfaces missing keys.
/// </summary>
public static class KeyCodeMap
{
    private static readonly Dictionary<string, ushort> Map = BuildMap();

    public static ushort? ToVirtualKey(string browserCode)
    {
        return Map.TryGetValue(browserCode, out var vk) ? vk : null;
    }

    private static Dictionary<string, ushort> BuildMap()
    {
        var map = new Dictionary<string, ushort>();

        for (char c = 'A'; c <= 'Z'; c++) map[$"Key{c}"] = (ushort)c;
        for (char d = '0'; d <= '9'; d++) map[$"Digit{d}"] = (ushort)d;

        map["Enter"] = 0x0D;
        map["Escape"] = 0x1B;
        map["Backspace"] = 0x08;
        map["Tab"] = 0x09;
        map["Space"] = 0x20;
        map["ShiftLeft"] = 0xA0;
        map["ShiftRight"] = 0xA1;
        map["ControlLeft"] = 0xA2;
        map["ControlRight"] = 0xA3;
        map["AltLeft"] = 0xA4;
        map["AltRight"] = 0xA5;
        map["ArrowLeft"] = 0x25;
        map["ArrowUp"] = 0x26;
        map["ArrowRight"] = 0x27;
        map["ArrowDown"] = 0x28;
        map["Delete"] = 0x2E;
        map["Home"] = 0x24;
        map["End"] = 0x23;
        map["PageUp"] = 0x21;
        map["PageDown"] = 0x22;

        return map;
    }
}
