using System.Text.Json;

namespace KioskClient.Services;

/// <summary>
/// The installer (WiX) writes device identity + server URL to this file under
/// ProgramData at install time (see installer/wix/Product.wxs). The client only
/// ever reads it — it never re-derives or hardcodes server/device identity itself.
/// </summary>
public class ClientConfig
{
    public string ServerUrl { get; set; } = string.Empty;
    public string KioskId { get; set; } = string.Empty;
    public string KioskCode { get; set; } = string.Empty;
    public string DeviceToken { get; set; } = string.Empty; // issued at registration, scoped to this device only

    // Written by the installer (SERVERURL/REGCODE MSI properties, see install.ps1),
    // consumed exactly once by RegistrationService, then cleared from disk.
    public string? PendingRegistrationCode { get; set; }

    public int HeartbeatIntervalSeconds { get; set; } = 30;
    public int PolicySyncIntervalSeconds { get; set; } = 60;
    public string PolicyCachePath { get; set; } = @"%PROGRAMDATA%\KioskClient\policy-cache.json";

    public static readonly string ConfigPath = @"%PROGRAMDATA%\KioskClient\config.json";

    public static ClientConfig Load()
    {
        var path = Environment.ExpandEnvironmentVariables(ConfigPath);
        if (!File.Exists(path))
        {
            throw new InvalidOperationException(
                $"No device configuration found at {path}. The installer should have written this " +
                "during setup (ServerUrl + PendingRegistrationCode) — reinstall the kiosk client.");
        }

        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<ClientConfig>(json)
            ?? throw new InvalidOperationException("Device configuration file is corrupt.");
    }

    public void Save()
    {
        var path = Environment.ExpandEnvironmentVariables(ConfigPath);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(path, json);
    }

    public bool IsRegistered => !string.IsNullOrEmpty(KioskId) && !string.IsNullOrEmpty(DeviceToken);
}
