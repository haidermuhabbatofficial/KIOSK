using System.Runtime.InteropServices;

namespace KioskClient.Services;

/// <summary>
/// Thin wrapper around the Win32 SendInput API. Coordinates come in normalized
/// (0..1) from the admin's canvas and are mapped to absolute screen coordinates
/// here, since the admin's viewer resolution never matches the kiosk's display.
/// </summary>
public static class NativeInput
{
    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    private const int SM_CXSCREEN = 0;
    private const int SM_CYSCREEN = 1;

    private const uint INPUT_MOUSE = 0;
    private const uint INPUT_KEYBOARD = 1;

    private const uint MOUSEEVENTF_MOVE = 0x0001;
    private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;
    private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
    private const uint MOUSEEVENTF_RIGHTUP = 0x0010;

    private const uint KEYEVENTF_KEYUP = 0x0002;

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int dx, dy;
        public uint mouseData, dwFlags, time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk, wScan;
        public uint dwFlags, time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    public static (int width, int height) GetScreenSize() => (GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));

    /// <param name="normalizedX">0..1 across the kiosk's screen width</param>
    /// <param name="normalizedY">0..1 across the kiosk's screen height</param>
    public static void MoveMouse(double normalizedX, double normalizedY)
    {
        // SendInput's absolute coordinate space is 0..65535 regardless of resolution.
        var absX = (int)(normalizedX * 65535);
        var absY = (int)(normalizedY * 65535);

        var input = new INPUT
        {
            type = INPUT_MOUSE,
            U = new InputUnion { mi = new MOUSEINPUT { dx = absX, dy = absY, dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE } },
        };
        SendInput(1, new[] { input }, Marshal.SizeOf<INPUT>());
    }

    public static void MouseButton(int button, bool down)
    {
        // button: 0 = left, 2 = right (matches the browser MouseEvent.button convention)
        uint flag = button switch
        {
            0 => down ? MOUSEEVENTF_LEFTDOWN : MOUSEEVENTF_LEFTUP,
            2 => down ? MOUSEEVENTF_RIGHTDOWN : MOUSEEVENTF_RIGHTUP,
            _ => 0,
        };
        if (flag == 0) return;

        var input = new INPUT { type = INPUT_MOUSE, U = new InputUnion { mi = new MOUSEINPUT { dwFlags = flag } } };
        SendInput(1, new[] { input }, Marshal.SizeOf<INPUT>());
    }

    /// <param name="virtualKeyCode">Windows virtual-key code — the caller maps from the browser's KeyboardEvent.code.</param>
    public static void KeyPress(ushort virtualKeyCode, bool down)
    {
        var input = new INPUT
        {
            type = INPUT_KEYBOARD,
            U = new InputUnion { ki = new KEYBDINPUT { wVk = virtualKeyCode, dwFlags = down ? 0 : KEYEVENTF_KEYUP } },
        };
        SendInput(1, new[] { input }, Marshal.SizeOf<INPUT>());
    }
}
