using System.Net.Http.Json;
using System.Text.Json;
using KioskClient.Models;

namespace KioskClient.Services;

public class ApiClient
{
    private readonly HttpClient _http;
    private readonly string _kioskId;

    // The NestJS side speaks camelCase JSON (class-validator DTOs); .NET's default is
    // PascalCase property names, so every call through this client explicitly maps
    // between the two rather than relying on ASP.NET-style implicit conventions.
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
    };

    public ApiClient(string serverUrl, string kioskId, string deviceToken)
    {
        _http = new HttpClient { BaseAddress = new Uri(serverUrl), Timeout = TimeSpan.FromSeconds(10) };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {deviceToken}");
        _kioskId = kioskId;
    }

    /// <summary>
    /// Sends device health to the server. Failure is expected during outages and must
    /// never throw past this call — the caller just keeps enforcing the cached policy.
    /// </summary>
    public async Task<bool> SendHeartbeatAsync(HeartbeatPayload payload, CancellationToken ct = default)
    {
        try
        {
            var response = await _http.PostAsJsonAsync($"/api/kiosks/{_kioskId}/heartbeat", payload, JsonOptions, ct);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Fetches the current policy if the server reports a newer version than what's
    /// cached locally. Returns null on any failure so the caller falls back to cache.
    /// </summary>
    public async Task<KioskPolicy?> FetchPolicyIfNewerAsync(int currentVersion, CancellationToken ct = default)
    {
        try
        {
            var response = await _http.GetAsync($"/api/kiosks/{_kioskId}/policy?since={currentVersion}", ct);
            if (response.StatusCode == System.Net.HttpStatusCode.NotModified) return null;
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<KioskPolicy>(JsonOptions, ct);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>Fire-and-forget style logging — a blocked-site attempt must never stall the UI.</summary>
    public void LogWebsiteAttempt(string requestedUrl, string domain, string action, int policyVersion)
    {
        _ = Task.Run(async () =>
        {
            try
            {
                await _http.PostAsJsonAsync($"/api/kiosks/{_kioskId}/website-logs", new
                {
                    requestedUrl,
                    domain,
                    action,
                    policyVersion,
                }, JsonOptions);
            }
            catch
            {
                // Best-effort. Consider spooling failed log entries to disk and
                // retrying on the next successful heartbeat if audit completeness matters.
            }
        });
    }
}

public class HeartbeatPayload
{
    public string? IpAddress { get; set; }
    public string? WindowsVersion { get; set; }
    public string? ClientVersion { get; set; }
    public double CpuUsage { get; set; }
    public double RamUsage { get; set; }
    public double DiskUsage { get; set; }
}
