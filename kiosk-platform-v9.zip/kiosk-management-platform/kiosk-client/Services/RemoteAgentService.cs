using System.Drawing;
using System.Drawing.Imaging;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using SIPSorcery.Net;

namespace KioskClient.Services;

/*
 * NOTE ON VERIFICATION: this class has been written against SIPSorcery's public
 * RTCPeerConnection API as documented/exampled by the SIPSorcery project (methods
 * mirroring the browser WebRTC API: createDataChannel, createOffer,
 * setLocalDescription/setRemoteDescription, onicecandidate, ondatachannel). It has
 * NOT been compiled or run — there is no Windows/.NET environment available here.
 * Treat this as a strong starting point and check method names/signatures against
 * whatever SIPSorcery version you actually restore before relying on it.
 */

public class RemoteAgentService : IDisposable
{
    private readonly ClientConfig _config;
    private readonly HttpClient _http;
    private ClientWebSocket? _ws;
    private RTCPeerConnection? _pc;
    private RTCDataChannel? _channel;
    private CancellationTokenSource? _sessionCts;
    private System.Threading.Timer? _frameTimer;

    private const int FrameIntervalMs = 400; // ~2.5 fps — deliberately modest for a DataChannel-based "video" approach
    private const int JpegQuality = 50;
    private const int MaxFrameWidth = 1280;

    private bool _fileTransferAllowed;
    private bool _clipboardSyncAllowed;
    private System.Threading.Timer? _clipboardTimer;
    private string _lastClipboardText = "";
    private MemoryStream? _incomingFile;
    private string? _incomingFileName;

    public RemoteAgentService(ClientConfig config)
    {
        _config = config;
        _http = new HttpClient { BaseAddress = new Uri(config.ServerUrl), Timeout = TimeSpan.FromSeconds(10) };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {config.DeviceToken}");
    }

    /// <summary>Call periodically (e.g. every 5s) from MainWindow's existing timer infrastructure.</summary>
    public async Task PollForSessionAsync(CancellationToken ct)
    {
        if (_ws is { State: WebSocketState.Open }) return; // already in a session

        try
        {
            var response = await _http.GetAsync($"/api/remote/sessions/pending/{_config.KioskId}", ct);
            if (!response.IsSuccessStatusCode) return;

            var json = await response.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrWhiteSpace(json) || json == "null") return;

            using var doc = JsonDocument.Parse(json);
            var sessionId = doc.RootElement.GetProperty("id").GetString();
            if (sessionId is null) return;

            var fileTransferAllowed = doc.RootElement.TryGetProperty("fileTransferAllowed", out var fta) && fta.GetBoolean();
            var clipboardSyncAllowed = doc.RootElement.TryGetProperty("clipboardSyncAllowed", out var csa) && csa.GetBoolean();

            await ConnectAsync(sessionId, fileTransferAllowed, clipboardSyncAllowed, ct);
        }
        catch
        {
            // Transient network issues just mean we try again on the next poll.
        }
    }

    private async Task ConnectAsync(string sessionId, bool fileTransferAllowed, bool clipboardSyncAllowed, CancellationToken outerCt)
    {
        _fileTransferAllowed = fileTransferAllowed;
        _clipboardSyncAllowed = clipboardSyncAllowed;

        _sessionCts = CancellationTokenSource.CreateLinkedTokenSource(outerCt);
        var ct = _sessionCts.Token;

        _ws = new ClientWebSocket();
        var wsUri = new Uri(_config.ServerUrl.Replace("http", "ws") + "/ws/remote-support");
        await _ws.ConnectAsync(wsUri, ct);

        await SendWsAsync(new { @event = "join", data = new { sessionId, role = "device", deviceToken = _config.DeviceToken } });

        _pc = new RTCPeerConnection(new RTCConfiguration
        {
            iceServers = new List<RTCIceServer> { new() { urls = "stun:stun.l.google.com:19302" } },
        });

        _pc.onicecandidate += (candidate) =>
        {
            if (candidate is not null)
            {
                _ = SendWsAsync(new
                {
                    @event = "signal",
                    data = new { sessionId, payload = new { type = "ice", candidate = candidate.toJSON() } },
                });
            }
        };

        // The device is the one offering the data channel (it's the one with a screen to share).
        _channel = await _pc.createDataChannel("control");
        WireChannel();

        _ = ReceiveLoopAsync(sessionId, ct);
    }

    private void WireChannel()
    {
        if (_channel is null) return;

        _channel.onopen += () =>
        {
            _frameTimer = new System.Threading.Timer(_ => CaptureAndSendFrame(), null, 0, FrameIntervalMs);
            if (_clipboardSyncAllowed)
            {
                _clipboardTimer = new System.Threading.Timer(_ => CheckAndSendClipboard(), null, 0, 1500);
            }
        };

        _channel.onclose += () => StopSession();

        _channel.onmessage += (dc, protocol, data) =>
        {
            try
            {
                var text = Encoding.UTF8.GetString(data);
                using var doc = JsonDocument.Parse(text);
                HandleInputMessage(doc.RootElement);
            }
            catch
            {
                // Malformed input message — ignore rather than crash the session.
            }
        };
    }

    private void HandleInputMessage(JsonElement msg)
    {
        var type = msg.GetProperty("type").GetString();

        switch (type)
        {
            case "mousemove":
                NativeInput.MoveMouse(msg.GetProperty("x").GetDouble(), msg.GetProperty("y").GetDouble());
                break;
            case "mousedown":
                NativeInput.MouseButton(msg.GetProperty("button").GetInt32(), down: true);
                break;
            case "mouseup":
                NativeInput.MouseButton(msg.GetProperty("button").GetInt32(), down: false);
                break;
            case "keydown":
            case "keyup":
                var code = msg.GetProperty("code").GetString() ?? "";
                var vk = KeyCodeMap.ToVirtualKey(code);
                if (vk.HasValue) NativeInput.KeyPress(vk.Value, down: type == "keydown");
                break;
            case "clipboard":
                if (_clipboardSyncAllowed)
                {
                    var text = msg.GetProperty("text").GetString() ?? "";
                    _lastClipboardText = text;
                    // Clipboard access needs an STA thread — WPF's dispatcher already is one.
                    System.Windows.Application.Current?.Dispatcher.Invoke(() =>
                    {
                        try { System.Windows.Clipboard.SetText(text); } catch { /* clipboard busy — drop this update */ }
                    });
                }
                break;
            case "file-start":
                if (_fileTransferAllowed)
                {
                    _incomingFileName = msg.GetProperty("name").GetString();
                    _incomingFile = new MemoryStream();
                }
                break;
            case "file-chunk":
                if (_fileTransferAllowed && _incomingFile is not null)
                {
                    var chunkBytes = Convert.FromBase64String(msg.GetProperty("data").GetString() ?? "");
                    _incomingFile.Write(chunkBytes, 0, chunkBytes.Length);
                }
                break;
            case "file-end":
                if (_fileTransferAllowed && _incomingFile is not null && _incomingFileName is not null)
                {
                    SaveIncomingFile(_incomingFileName, _incomingFile);
                    _incomingFile = null;
                    _incomingFileName = null;
                }
                break;
        }
    }

    private static void SaveIncomingFile(string name, MemoryStream data)
    {
        try
        {
            var downloads = Environment.ExpandEnvironmentVariables(@"%PROGRAMDATA%\KioskClient\RemoteTransfers");
            Directory.CreateDirectory(downloads);
            // Sanitize to a bare filename — never trust a path from the remote side.
            var safeName = Path.GetFileName(name);
            File.WriteAllBytes(Path.Combine(downloads, safeName), data.ToArray());
        }
        catch
        {
            // A failed save shouldn't tear down the remote session over one file.
        }
    }

    private void CheckAndSendClipboard()
    {
        if (_channel?.readyState != RTCDataChannelState.open) return;

        try
        {
            string? text = null;
            System.Windows.Application.Current?.Dispatcher.Invoke(() =>
            {
                if (System.Windows.Clipboard.ContainsText()) text = System.Windows.Clipboard.GetText();
            });

            if (!string.IsNullOrEmpty(text) && text != _lastClipboardText)
            {
                _lastClipboardText = text;
                _channel.send(JsonSerializer.Serialize(new { type = "clipboard", text }));
            }
        }
        catch
        {
            // Clipboard can throw if another process holds it briefly — just skip this tick.
        }
    }

    private void CaptureAndSendFrame()
    {
        if (_channel?.readyState != RTCDataChannelState.open) return;

        try
        {
            var (screenWidth, screenHeight) = NativeInput.GetScreenSize();
            var scale = Math.Min(1.0, (double)MaxFrameWidth / screenWidth);
            var width = (int)(screenWidth * scale);
            var height = (int)(screenHeight * scale);

            using var fullBitmap = new Bitmap(screenWidth, screenHeight, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(fullBitmap))
            {
                g.CopyFromScreen(0, 0, 0, 0, new Size(screenWidth, screenHeight));
            }

            using var scaledBitmap = new Bitmap(fullBitmap, width, height);
            using var ms = new MemoryStream();

            var jpegEncoder = ImageCodecInfo.GetImageEncoders().First(c => c.FormatID == ImageFormat.Jpeg.Guid);
            var encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, JpegQuality);
            scaledBitmap.Save(ms, jpegEncoder, encoderParams);

            var base64 = Convert.ToBase64String(ms.ToArray());
            _channel.send(JsonSerializer.Serialize(new { type = "frame", jpegBase64 = base64 }));
        }
        catch
        {
            // A single dropped frame isn't worth tearing down the session over.
        }
    }

    private async Task ReceiveLoopAsync(string sessionId, CancellationToken ct)
    {
        var buffer = new byte[16 * 1024];
        try
        {
            while (_ws is { State: WebSocketState.Open } && !ct.IsCancellationRequested)
            {
                var result = await _ws.ReceiveAsync(buffer, ct);
                if (result.MessageType == WebSocketMessageType.Close) break;

                var text = Encoding.UTF8.GetString(buffer, 0, result.Count);
                using var doc = JsonDocument.Parse(text);
                var evt = doc.RootElement.GetProperty("event").GetString();

                switch (evt)
                {
                    case "peer-ready":
                        var offer = _pc!.createOffer();
                        await _pc.setLocalDescription(offer);
                        await SendWsAsync(new { @event = "signal", data = new { sessionId, payload = new { type = "offer", sdp = offer.sdp } } });
                        break;

                    case "signal":
                        var payload = doc.RootElement.GetProperty("payload");
                        var payloadType = payload.GetProperty("type").GetString();
                        if (payloadType == "answer")
                        {
                            var sdp = payload.GetProperty("sdp").GetString()!;
                            _pc!.setRemoteDescription(new RTCSessionDescriptionInit { type = RTCSdpType.answer, sdp = sdp });
                        }
                        else if (payloadType == "ice")
                        {
                            var candidateJson = payload.GetProperty("candidate").GetRawText();
                            _pc!.addIceCandidate(JsonSerializer.Deserialize<RTCIceCandidateInit>(candidateJson)!);
                        }
                        break;

                    case "ended":
                        StopSession();
                        return;
                }
            }
        }
        catch
        {
            // Connection dropped — StopSession cleans up either way.
        }
        finally
        {
            StopSession();
        }
    }

    private async Task SendWsAsync(object message)
    {
        if (_ws is not { State: WebSocketState.Open }) return;
        var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));
        await _ws.SendAsync(bytes, WebSocketMessageType.Text, true, CancellationToken.None);
    }

    private void StopSession()
    {
        _frameTimer?.Dispose();
        _frameTimer = null;
        _clipboardTimer?.Dispose();
        _clipboardTimer = null;
        _pc?.close();
        _pc = null;
        _channel = null;
        _sessionCts?.Cancel();

        if (_ws is { State: WebSocketState.Open })
        {
            _ = _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "session ended", CancellationToken.None);
        }
        _ws = null;
    }

    public void Dispose()
    {
        StopSession();
        _http.Dispose();
    }
}
