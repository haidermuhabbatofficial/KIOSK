using System.Text.Json;
using KioskClient.Models;

namespace KioskClient.Services;

/// <summary>
/// Persists the last successfully-fetched policy to disk so that if the management
/// server is unreachable, the kiosk keeps enforcing exactly the same restrictions
/// (spec §25/§37: a server outage must never loosen website/application restrictions).
/// </summary>
public class PolicyCacheService
{
    private readonly string _cachePath;

    public PolicyCacheService(string cachePath)
    {
        _cachePath = Environment.ExpandEnvironmentVariables(cachePath);
        Directory.CreateDirectory(Path.GetDirectoryName(_cachePath)!);
    }

    public KioskPolicy Load()
    {
        if (!File.Exists(_cachePath))
        {
            // No cache and no server reachable on first run: fail secure with an
            // empty allowlist rather than an implicit "allow everything".
            return new KioskPolicy { AllowlistMode = true, PolicyVersion = 0 };
        }

        try
        {
            var json = File.ReadAllText(_cachePath);
            return JsonSerializer.Deserialize<KioskPolicy>(json) ?? new KioskPolicy();
        }
        catch
        {
            // Corrupt cache — fail secure rather than crash or fall open.
            return new KioskPolicy { AllowlistMode = true, PolicyVersion = 0 };
        }
    }

    public void Save(KioskPolicy policy)
    {
        policy.CachedAtUtc = DateTime.UtcNow;
        var json = JsonSerializer.Serialize(policy, new JsonSerializerOptions { WriteIndented = true });
        var tempPath = _cachePath + ".tmp";
        File.WriteAllText(tempPath, json);
        File.Copy(tempPath, _cachePath, overwrite: true);
        File.Delete(tempPath);
    }
}
