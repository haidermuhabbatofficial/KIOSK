using System.Net.Http.Json;
using System.Net.NetworkInformation;
using System.Text.Json;

namespace KioskClient.Services;

public record RegisterResponse(string Id, string KioskCode, string DeviceToken);

/// <summary>
/// Completes the registration flow from spec §30: the installer writes the server URL
/// and a one-time registration code to config.json; on first launch, the client
/// exchanges that code for a permanent device identity + token via
/// POST /api/kiosks/register, then persists the result so this only ever runs once.
/// </summary>
public class RegistrationService
{
    public async Task<bool> EnsureRegisteredAsync(ClientConfig config)
    {
        if (config.IsRegistered) return true;

        if (string.IsNullOrEmpty(config.PendingRegistrationCode))
        {
            throw new InvalidOperationException(
                "Kiosk is not registered and no registration code was provided by the installer.");
        }

        using var http = new HttpClient { BaseAddress = new Uri(config.ServerUrl), Timeout = TimeSpan.FromSeconds(15) };

        var macAddress = GetPrimaryMacAddress();
        var response = await http.PostAsJsonAsync("/api/kiosks/register", new
        {
            registrationCode = config.PendingRegistrationCode,
            macAddress,
            windowsVersion = Environment.OSVersion.VersionString,
            clientVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version?.ToString(),
        });

        if (!response.IsSuccessStatusCode)
        {
            return false; // caller decides how to surface this (retry, show setup error screen, etc.)
        }

        // The API returns lowerCamelCase JSON keys (id, kioskCode, deviceToken);
        // case-insensitive matching avoids needing [JsonPropertyName] on every property.
        var result = await response.Content.ReadFromJsonAsync<RegisterResponse>(
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        if (result is null) return false;

        config.KioskId = result.Id;
        config.KioskCode = result.KioskCode;
        config.DeviceToken = result.DeviceToken;
        config.PendingRegistrationCode = null; // one-time code — never reused, never left on disk
        config.Save();

        return true;
    }

    private static string GetPrimaryMacAddress()
    {
        var nic = NetworkInterface.GetAllNetworkInterfaces()
            .FirstOrDefault(n => n.OperationalStatus == OperationalStatus.Up
                                  && n.NetworkInterfaceType != NetworkInterfaceType.Loopback);
        return nic?.GetPhysicalAddress().ToString() ?? "UNKNOWN";
    }
}
