# Kiosk Client (WPF + WebView2)

The full-screen Windows kiosk application: renders the branded menu, embeds a policy-
enforced WebView2 browser, and — as of this build — includes a WebRTC remote-support
agent.

## Structure

- `MainWindow.xaml(.cs)` — kiosk shell, WebView2 wiring, heartbeat/policy-sync loops, key lockdown
- `Services/PolicyEngine.cs` — the allowlist/blocklist rule matcher (unit-testable, no WebView2 dependency)
- `Services/PolicyCacheService.cs` — fail-secure local policy cache
- `Services/ApiClient.cs` — heartbeat, policy fetch, website-attempt logging
- `Services/RegistrationService.cs` — first-run device registration
- `Services/RemoteAgentService.cs` — WebRTC remote-support agent (see caveat below)
- `Services/NativeInput.cs`, `Services/KeyCodeMap.cs` — Win32 `SendInput` wrapper for simulating mouse/keyboard from remote-support commands
- `Views/ExitKioskDialog.xaml(.cs)` — server-verified admin exit PIN

## ✅ API usage verified against SIPSorcery's own docs/examples

Every core WebRTC call in `RemoteAgentService.cs` (`createDataChannel`, `createOffer`,
`setLocalDescription`, `setRemoteDescription`, `addIceCandidate`, `RTCIceCandidate.toJSON()`,
`RTCDataChannel` events/`send()`/`readyState`, `onicecandidate`, `close()`) has been
cross-checked against SIPSorcery's official API docs and the project's own reference
examples (`WebRTCReceiveAudio`, `signalrtc`, and a working code sample from a GitHub
issue) — all match exactly, no changes needed. Details in the project's chat history
if you want the specific sources.

**Still genuinely unverified** (not confirmed against a primary source, and can only
really be confirmed by compiling):
- `RTCConfiguration.iceServers` / `RTCIceServer.urls` property names — used by
  convention (matches every other SIPSorcery property's lowercase-first naming) but
  not directly confirmed.
- Whether a data-channel-only connection needs an explicit `Start()` call somewhere
  in the flow — none of the examples reviewed showed one being necessary, but it's
  worth watching for during your first test run.
- `WindowsLockdownApplier.cs`'s registry keys — well-known Windows policy keys, but
  exact enforcement can vary slightly by Windows version/edition.
- Everything here still needs an actual compile + real kiosk + real admin session to
  be considered production-ready. Verification against documentation reduces risk;
  it doesn't replace testing.

## Building

Requires the .NET 8 SDK and Windows (WPF + WebView2 + `System.Drawing.Common` are all
Windows-only).

```powershell
dotnet publish -c Release -r win-x64 --self-contained
```

Output feeds into the WiX installer (`installer/wix/Product.wxs`), which expects the
publish output at `kiosk-client\bin\Release\net8.0-windows\win-x64\publish\`.
