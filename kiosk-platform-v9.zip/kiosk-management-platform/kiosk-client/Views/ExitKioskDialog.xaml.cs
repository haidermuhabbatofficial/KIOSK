using System.Net.Http.Json;
using System.Windows;

namespace KioskClient.Views;

/// <summary>
/// Collects an admin PIN and verifies it against the server — the client never stores,
/// hardcodes, or locally validates the PIN itself (spec §19). If the server can't be
/// reached, exit is denied: a network outage must not become an escape hatch.
/// </summary>
public partial class ExitKioskDialog : Window
{
    private readonly HttpClient _http;
    private readonly string _kioskId;

    public bool Authorized { get; private set; }

    public ExitKioskDialog(HttpClient http, string kioskId)
    {
        InitializeComponent();
        _http = http;
        _kioskId = kioskId;
    }

    private async void Submit_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;
        var pin = PinBox.Password;

        if (string.IsNullOrWhiteSpace(pin))
        {
            return;
        }

        try
        {
            var response = await _http.PostAsJsonAsync(
                $"/api/kiosks/{_kioskId}/verify-exit-pin", new { pin });

            if (response.IsSuccessStatusCode)
            {
                Authorized = true;
                DialogResult = true;
                Close();
                return;
            }
        }
        catch
        {
            // Server unreachable — fall through to the generic error below.
            // Intentionally does NOT authorize exit on failure.
        }

        ErrorText.Text = "Incorrect PIN, or the management server is unreachable.";
        ErrorText.Visibility = Visibility.Visible;
        PinBox.Clear();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        Authorized = false;
        DialogResult = false;
        Close();
    }
}
