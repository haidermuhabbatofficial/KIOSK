using System.Text.Json.Serialization;

namespace KioskClient.Models;

// Server sends these as PascalCase strings (see kiosks.service.ts getPolicyForDevice) —
// JsonStringEnumConverter makes deserialization match by name instead of ordinal number.
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum WebsiteRuleType
{
    Domain,
    ExactUrl,
    Wildcard,
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum WebsiteRuleAction
{
    Allow,
    Block,
}

public class WebsiteRule
{
    public WebsiteRuleType Type { get; set; }
    public WebsiteRuleAction Action { get; set; }
    public string Pattern { get; set; } = string.Empty;
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum BlockedNavigationBehavior
{
    RedirectToHome,
    ShowAccessDenied,
    RedirectToBranchPortal,
}

public class MenuItem
{
    public string Label { get; set; } = string.Empty;
    public string IconUrl { get; set; } = string.Empty;
    public string TargetType { get; set; } = "WEBSITE"; // WEBSITE | APPLICATION
    public string TargetValue { get; set; } = string.Empty;
    public int SortOrder { get; set; }
}

/// <summary>
/// Everything the kiosk needs to enforce policy and render its menu, cached to disk
/// so enforcement continues unchanged during a server outage (spec §25/§26/§37 —
/// never fall back to unrestricted browsing).
/// </summary>
public class KioskPolicy
{
    public int PolicyVersion { get; set; }
    public bool AllowlistMode { get; set; } = true;
    public List<WebsiteRule> WebsiteRules { get; set; } = new();
    public BlockedNavigationBehavior BlockedNavigationBehavior { get; set; } = BlockedNavigationBehavior.RedirectToHome;
    public string BranchPortalUrl { get; set; } = string.Empty;
    public string HomeUrl { get; set; } = "kiosk://home";
    public List<string> AllowedApplicationExecutables { get; set; } = new();
    public List<MenuItem> MenuItems { get; set; } = new();
    public string BranchName { get; set; } = string.Empty;
    public string KioskDisplayName { get; set; } = string.Empty;
    public string LogoUrl { get; set; } = string.Empty;
    public bool DownloadsBlocked { get; set; } = true;
    public DateTime CachedAtUtc { get; set; } = DateTime.UtcNow;
}
