using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using KioskClient.Models;
using KioskClient.Services;
using KioskClient.Views;

namespace KioskClient;

public partial class MainWindow : Window
{
    private readonly ClientConfig _config;
    private readonly ApiClient _api;
    private readonly PolicyCacheService _cache;
    private readonly PolicyEngine _policyEngine = new();
    private readonly HttpClient _rawHttp;
    private readonly RemoteAgentService _remoteAgent;

    private KioskPolicy _policy;
    private DispatcherTimer? _heartbeatTimer;
    private DispatcherTimer? _policySyncTimer;
    private bool _serverReachable = false;

    public MainWindow()
    {
        InitializeComponent();

        _config = ClientConfig.Load();
        _cache = new PolicyCacheService(_config.PolicyCachePath);
        _policy = _cache.Load();
        _rawHttp = new HttpClient { BaseAddress = new Uri(_config.ServerUrl), Timeout = TimeSpan.FromSeconds(10) };
        _rawHttp.DefaultRequestHeaders.Add("Authorization", $"Bearer {_config.DeviceToken}");
        _api = new ApiClient(_config.ServerUrl, _config.KioskId, _config.DeviceToken);
        _remoteAgent = new RemoteAgentService(_config);

        PreviewKeyDown += MainWindow_PreviewKeyDown;
        Loaded += MainWindow_Loaded;
        Closing += (_, e) => e.Cancel = true; // the only way out is the admin PIN flow
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        RenderBranding();
        RenderMenu();

        await InitializeWebViewAsync();
        StartHeartbeatLoop();
        StartPolicySyncLoop();
        StartRemoteSupportPollingLoop();
    }

    // ── Branding / menu ─────────────────────────────────────────────

    private void RenderBranding()
    {
        BranchNameText.Text = _policy.BranchName;
        KioskNameText.Text = _policy.KioskDisplayName;
        BranchCodeText.Text = $"Branch: {_policy.BranchName}";
        if (!string.IsNullOrEmpty(_policy.LogoUrl))
        {
            try { LogoImage.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(_policy.LogoUrl)); }
            catch { /* missing/broken logo shouldn't block kiosk startup */ }
        }
    }

    private void RenderMenu()
    {
        MenuPanel.Children.Clear();
        foreach (var item in _policy.MenuItems.OrderBy(m => m.SortOrder))
        {
            var button = new Button
            {
                Content = item.Label,
                Width = 220,
                Height = 90,
                Margin = new Thickness(12),
                FontSize = 16,
                Tag = item,
            };
            button.Click += MenuButton_Click;
            MenuPanel.Children.Add(button);
        }
    }

    private void MenuButton_Click(object sender, RoutedEventArgs e)
    {
        var item = (MenuItem)((Button)sender).Tag;

        if (item.TargetType == "WEBSITE")
        {
            ShowBrowser();
            NavigateChecked(item.TargetValue);
        }
        else if (item.TargetType == "APPLICATION")
        {
            LaunchApprovedApplication(item.TargetValue);
        }
    }

    private void ShowBrowser()
    {
        MenuPanel.Visibility = Visibility.Collapsed;
        BrowserContainer.Visibility = Visibility.Visible;
    }

    private void ShowMenu()
    {
        BrowserContainer.Visibility = Visibility.Collapsed;
        MenuPanel.Visibility = Visibility.Visible;
    }

    // ── WebView2 + navigation enforcement (spec §8–§13) ─────────────

    private async Task InitializeWebViewAsync()
    {
        var env = await CoreWebView2Environment.CreateAsync(
            userDataFolder: Environment.ExpandEnvironmentVariables(@"%PROGRAMDATA%\KioskClient\WebView2"));
        await Browser.EnsureCoreWebView2Async(env);

        var core = Browser.CoreWebView2;
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.AreBrowserAcceleratorKeysEnabled = false;
        core.Settings.IsStatusBarEnabled = false;

        // Covers address-bar navigation, links, and script-initiated redirects (§10).
        core.NavigationStarting += Core_NavigationStarting;
        // Covers target="_blank" links and window.open() popups (§10).
        core.NewWindowRequested += Core_NewWindowRequested;
        // Covers downloads (§27) — default to "approved downloads only", enforced
        // server-side against the ApplicationDownloadCenter; here we simply respect
        // the cached DownloadsBlocked flag as a blanket switch.
        core.DownloadStarting += Core_DownloadStarting;
    }

    private void Core_NavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri))
        {
            e.Cancel = true;
            return;
        }

        var decision = _policyEngine.Evaluate(_policy, uri);
        _api.LogWebsiteAttempt(uri.ToString(), uri.Host, decision.ToString(), _policy.PolicyVersion);

        if (decision == NavigationDecision.Block)
        {
            e.Cancel = true;
            HandleBlockedNavigation();
        }
    }

    private void Core_NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        // No separate popup windows in a locked-down kiosk: redirect the same
        // enforcement path by navigating the single WebView2 instance instead.
        e.Handled = true;
        if (Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri))
        {
            NavigateChecked(uri.ToString());
        }
    }

    private void Core_DownloadStarting(object? sender, CoreWebView2DownloadStartingEventArgs e)
    {
        if (_policy.DownloadsBlocked)
        {
            e.Cancel = true;
        }
        // "Allow approved downloads only" requires hash-checking against the
        // Application Download Center — wire that up once §15's endpoints exist.
    }

    private async void HandleBlockedNavigation()
    {
        AccessRestrictedOverlay.Visibility = Visibility.Visible;
        await Task.Delay(2500);
        AccessRestrictedOverlay.Visibility = Visibility.Collapsed;

        switch (_policy.BlockedNavigationBehavior)
        {
            case BlockedNavigationBehavior.RedirectToBranchPortal when !string.IsNullOrEmpty(_policy.BranchPortalUrl):
                NavigateChecked(_policy.BranchPortalUrl);
                break;
            case BlockedNavigationBehavior.ShowAccessDenied:
                // Overlay already shown above; just return to the menu behind it.
                ShowMenu();
                break;
            default:
                ShowMenu();
                break;
        }
    }

    /// <summary>Navigates only after the same policy check used for in-browser navigation.</summary>
    private void NavigateChecked(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return;
        if (_policyEngine.Evaluate(_policy, uri) == NavigationDecision.Block)
        {
            HandleBlockedNavigation();
            return;
        }
        Browser.CoreWebView2?.Navigate(url);
    }

    private void LaunchApprovedApplication(string executablePath)
    {
        if (!_policy.AllowedApplicationExecutables.Contains(executablePath, StringComparer.OrdinalIgnoreCase))
        {
            return; // not on the allowlist — silently refuse, same as an unauthorized site
        }

        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(executablePath)
            {
                UseShellExecute = true,
            });
        }
        catch
        {
            // Missing/uninstalled application — surface via a toast in a future pass.
        }
    }

    // ── Heartbeat + policy sync (spec §24/§25) ──────────────────────

    private void StartHeartbeatLoop()
    {
        _heartbeatTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(_config.HeartbeatIntervalSeconds),
        };
        _heartbeatTimer.Tick += async (_, _) => await SendHeartbeatAsync();
        _heartbeatTimer.Start();
        _ = SendHeartbeatAsync();
    }

    private async Task SendHeartbeatAsync()
    {
        var payload = new HeartbeatPayload
        {
            WindowsVersion = Environment.OSVersion.VersionString,
            ClientVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version?.ToString(),
            // CPU/RAM/disk sampling intentionally left to the Windows Service (kiosk-service),
            // which already owns performance counters for the crash-recovery watchdog.
        };

        _serverReachable = await _api.SendHeartbeatAsync(payload);
        UpdateStatusIndicator();
    }

    private void StartPolicySyncLoop()
    {
        _policySyncTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(_config.PolicySyncIntervalSeconds),
        };
        _policySyncTimer.Tick += async (_, _) => await SyncPolicyAsync();
        _policySyncTimer.Start();
    }

    private async Task SyncPolicyAsync()
    {
        var updated = await _api.FetchPolicyIfNewerAsync(_policy.PolicyVersion);
        if (updated is null)
        {
            return; // unreachable, or no newer version — keep enforcing the cached policy unchanged
        }

        _policy = updated;
        _cache.Save(_policy);
        RenderBranding();
        RenderMenu();
    }

    private void UpdateStatusIndicator()
    {
        StatusText.Text = _serverReachable ? "Status: Online" : "Status: Offline (policy cached)";
        OnlineIndicator.Fill = _serverReachable
            ? System.Windows.Media.Brushes.LimeGreen
            : System.Windows.Media.Brushes.Red;

        ServerUnavailableOverlay.Visibility =
            (!_serverReachable && BrowserContainer.Visibility == Visibility.Visible)
                ? Visibility.Visible
                : Visibility.Collapsed;
    }

    // ── Remote support (spec §20-23) ────────────────────────────────

    private void StartRemoteSupportPollingLoop()
    {
        var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
        timer.Tick += async (_, _) => await _remoteAgent.PollForSessionAsync(CancellationToken.None);
        timer.Start();
    }

    // ── Admin exit + basic key lockdown (spec §19) ──────────────────

    private async void AdminExitHotspot_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new ExitKioskDialog(_rawHttp, _config.KioskId) { Owner = this };
        var result = dialog.ShowDialog();
        if (result == true && dialog.Authorized)
        {
            // Environment.Exit bypasses the Closing handler above (which otherwise
            // always cancels), so this is the only path that actually ends the process.
            Environment.Exit(0);
        }
        await Task.CompletedTask;
    }

    private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        // Best-effort app-level lockdown. This is a supplement to, not a replacement
        // for, OS-level lockdown (Windows Assigned Access / shell replacement — see
        // installer docs §26) which is what actually prevents desktop access.
        bool isAltF4 = e.SystemKey == Key.F4 && Keyboard.Modifiers == ModifierKeys.Alt;
        bool isAltTab = e.SystemKey == Key.Tab && Keyboard.Modifiers == ModifierKeys.Alt;
        bool isWinKey = e.Key == Key.LWin || e.Key == Key.RWin;

        if (isAltF4 || isAltTab || isWinKey)
        {
            e.Handled = true;
        }
    }
}
