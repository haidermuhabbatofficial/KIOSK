using System.Windows;
using System.Windows.Threading;

namespace KioskClient;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // The Windows Service (kiosk-service) is the real safety net — it detects
        // process exit and restarts the client. This handler exists so a recoverable
        // UI-thread exception doesn't take the whole process down unnecessarily.
        DispatcherUnhandledException += (_, args) =>
        {
            LogFatal(args.Exception);
            // Swallow it: staying on-screen (even if a feature glitches) beats dropping
            // to the desktop, which spec §37/§28 both treat as the failure mode to avoid.
            args.Handled = true;
        };

        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            LogFatal(args.ExceptionObject as Exception);
            // Non-UI-thread fatal exceptions can't be swallowed — the process will exit
            // and kiosk-service's watchdog will restart it (spec §28 automatic recovery).
        };
    }

    private static void LogFatal(Exception? ex)
    {
        try
        {
            var logDir = Environment.ExpandEnvironmentVariables(@"%PROGRAMDATA%\KioskClient\logs");
            Directory.CreateDirectory(logDir);
            File.AppendAllText(
                Path.Combine(logDir, "client-crash.log"),
                $"{DateTime.UtcNow:O} {ex}\n\n");
        }
        catch
        {
            // If we can't even log the crash, there's nothing further to do here.
        }
    }
}
