# Backup & Disaster Recovery

## What's backed up

- **PostgreSQL database** — everything: branches, kiosks, users, website rules,
  policies, audit logs, remote session records. This is the entire system's state;
  the API server and admin panel are stateless application code that can be
  redeployed from source at any time.
- **Config files** (`.env`, WiX installer properties) — not automated; keep these
  in your secrets manager or a private encrypted location, not in the repo.
- **Uploaded application/client installers** — currently referenced by URL
  (`installerUrl` fields) rather than stored in the database; back up wherever
  those files actually live (S3 bucket, file share, etc.) separately.

## Automated database backups

`infrastructure/backup/backup.sh` runs `pg_dump` in custom format (compressed,
supports parallel restore) and prunes dumps older than the retention window.

Set up as a nightly cron job on the server hosting Postgres (or wherever
`DATABASE_URL` is reachable from):

```bash
crontab -e
# Add:
0 2 * * * DATABASE_URL="postgresql://kiosk:***@localhost:5432/kiosk_platform" \
          BACKUP_DIR="/var/backups/kiosk-platform" \
          BACKUP_RETENTION_DAYS=14 \
          /opt/kiosk-platform/infrastructure/backup/backup.sh >> /var/log/kiosk-backup.log 2>&1
```

Verify backups are actually happening — a cron job that silently stops running is
worse than no backup strategy at all, because it creates false confidence. At
minimum, alert on `backup.sh` exiting non-zero, and periodically confirm dump files
are appearing in `BACKUP_DIR` with recent timestamps.

Store backups off the database host — a copy sitting next to the database it backs
up doesn't survive that host failing. Sync `BACKUP_DIR` to separate storage (S3,
another server, etc.) as a second step in the same cron job or a follow-up job.

## Restore procedure

1. **Stop the API server** so nothing writes to the database mid-restore.
2. **Identify the dump to restore from** — list `BACKUP_DIR` (or your off-host copy) and pick the right timestamp.
3. **Restore into a fresh or emptied database:**
   ```bash
   # Fresh database:
   createdb -U kiosk kiosk_platform_restored

   # Restore (parallel jobs speed this up on a large database):
   pg_restore -U kiosk -d kiosk_platform_restored -j 4 /path/to/kiosk-platform-<timestamp>.dump
   ```
4. **Point `DATABASE_URL` at the restored database** (either rename it into place,
   or update the API server's `.env`).
5. **Run `npx prisma migrate deploy`** against the restored database — if the
   backup predates a schema migration that's since been applied to the app code,
   this brings the restored data's schema up to date. (If the backup is *newer*
   than the running app's migrations, do this the other way: deploy the matching
   app version first.)
6. **Restart the API server** and verify: log in, check a few branches/kiosks load,
   confirm recent-looking data is present and nothing obviously missing.
7. **Re-issue device tokens if needed** — device tokens are long-lived JWTs signed
   with `JWT_DEVICE_SECRET`; if that secret didn't change, existing kiosks
   reconnect without re-registering. If you rotated the secret as part of incident
   response, kiosks will need to re-register with a fresh registration code.

## What a restore does *not* automatically fix

- Kiosks that registered or had policy changes *after* the backup's timestamp will
  have stale local state until their next successful sync — this is expected and
  is exactly what the fail-secure local policy cache is for (spec §25/§37): kiosks
  keep enforcing their last-known-good policy, they don't fall open.
- Any remote-support sessions active at backup time are gone — they're short-lived
  by design (spec §21) and aren't meant to survive this kind of event anyway.

## Testing this procedure

A backup you've never restored from is a hope, not a plan. Periodically (e.g.
quarterly) actually run the restore procedure against a scratch database and
confirm the result looks right — catching a corrupt or incomplete backup during a
drill costs nothing; catching it during a real incident costs everything.
