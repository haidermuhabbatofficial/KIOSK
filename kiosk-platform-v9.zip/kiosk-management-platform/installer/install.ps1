<#
.SYNOPSIS
    Kiosk Management Platform — client installer bootstrapper.

.DESCRIPTION
    Downloads the latest signed Kiosk Client MSI from this repo's GitHub Releases,
    verifies its SHA-256 hash, and runs a silent install with the server URL and
    one-time registration code pre-filled (spec section 44/30).

    Intended to be hosted at a stable, transparent URL (GitHub raw or your own
    domain) and run as:

        irm https://raw.githubusercontent.com/<owner>/<repo>/main/installer/install.ps1 | iex

    To pass the server URL and registration code in the same one-liner:

        iex "& { $(irm https://raw.githubusercontent.com/<owner>/<repo>/main/installer/install.ps1) } -ServerUrl 'https://kiosk.example.com' -RegistrationCode 'ABC123'"

    If ServerUrl / RegistrationCode are omitted, the script prompts interactively —
    matching the "ask for server URL / registration code" installer flow in the spec.

.NOTES
    Must be run as Administrator (installs a Windows Service + configures startup).
    Never hardcodes credentials — the registration code is short-lived and single-use,
    generated per-kiosk from the admin panel (POST /api/kiosks/registration-codes).
#>

[CmdletBinding()]
param(
    [string]$ServerUrl,
    [string]$RegistrationCode,
    # Override if you fork this repo or self-host releases elsewhere.
    [string]$GitHubRepo = "YOUR-ORG/kiosk-management-platform"
)

$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        throw "This installer must be run from an elevated (Administrator) PowerShell session."
    }
}

function Get-LatestRelease {
    param([string]$Repo)
    $uri = "https://api.github.com/repos/$Repo/releases/latest"
    Write-Host "Checking latest release: $uri"
    return Invoke-RestMethod -Uri $uri -Headers @{ "User-Agent" = "kiosk-installer" }
}

function Get-ReleaseAsset {
    param($Release, [string]$NamePattern)
    $asset = $Release.assets | Where-Object { $_.name -like $NamePattern } | Select-Object -First 1
    if (-not $asset) {
        throw "No release asset matching '$NamePattern' found on release $($Release.tag_name)."
    }
    return $asset
}

function Verify-Sha256 {
    param([string]$FilePath, [string]$ExpectedHash)
    $actual = (Get-FileHash -Path $FilePath -Algorithm SHA256).Hash
    if ($actual.ToLower() -ne $ExpectedHash.ToLower()) {
        throw "SHA-256 mismatch for $FilePath. Expected $ExpectedHash, got $actual. Refusing to install."
    }
    Write-Host "Hash verified: $actual"
}

Assert-Administrator

if (-not $ServerUrl) {
    $ServerUrl = Read-Host "Enter the Kiosk Management Server URL (e.g. https://kiosk.example.com)"
}
if (-not $RegistrationCode) {
    $RegistrationCode = Read-Host "Enter the one-time Kiosk Registration Code"
}

$release = Get-LatestRelease -Repo $GitHubRepo
$msiAsset = Get-ReleaseAsset -Release $release -NamePattern "KioskClientSetup*.msi"
$hashAsset = Get-ReleaseAsset -Release $release -NamePattern "KioskClientSetup*.sha256"

$tempDir = Join-Path $env:TEMP "kiosk-client-install"
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
$msiPath = Join-Path $tempDir $msiAsset.name
$hashPath = Join-Path $tempDir $hashAsset.name

Write-Host "Downloading $($msiAsset.name) ($([math]::Round($msiAsset.size / 1MB, 1)) MB)…"
Invoke-WebRequest -Uri $msiAsset.browser_download_url -OutFile $msiPath
Invoke-WebRequest -Uri $hashAsset.browser_download_url -OutFile $hashPath

$expectedHash = (Get-Content $hashPath -Raw).Trim().Split(" ")[0]
Verify-Sha256 -FilePath $msiPath -ExpectedHash $expectedHash

Write-Host "Installing silently…"
$msiArgs = @(
    "/i", "`"$msiPath`"",
    "/qn", "/norestart",
    "SERVERURL=`"$ServerUrl`"",
    "REGCODE=`"$RegistrationCode`"",
    "/l*v", "`"$tempDir\install.log`""
)
$proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $msiArgs -Wait -PassThru

if ($proc.ExitCode -ne 0) {
    throw "Install failed with exit code $($proc.ExitCode). See $tempDir\install.log"
}

Write-Host "Kiosk client installed and registered against $ServerUrl. Log: $tempDir\install.log"
