#!/usr/bin/env bash
# Kiosk Management Platform — database backup.
#
# Usage: run from cron, e.g. nightly at 2am:
#   0 2 * * * /opt/kiosk-platform/infrastructure/backup/backup.sh >> /var/log/kiosk-backup.log 2>&1
#
# Required environment (set in the crontab or a sourced .env, not hardcoded here):
#   DATABASE_URL          - same connection string the API server uses
#   BACKUP_DIR            - where dumps are written (default: /var/backups/kiosk-platform)
#   BACKUP_RETENTION_DAYS - how many days of dumps to keep (default: 14)

set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-/var/backups/kiosk-platform}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
DUMP_FILE="${BACKUP_DIR}/kiosk-platform-${TIMESTAMP}.dump"

if [ -z "${DATABASE_URL:-}" ]; then
  echo "DATABASE_URL is not set — aborting backup." >&2
  exit 1
fi

mkdir -p "$BACKUP_DIR"

echo "[$(date -Iseconds)] Starting backup to ${DUMP_FILE}"

# Custom format (-Fc): compressed, supports parallel restore, and restores with
# pg_restore rather than needing a plain-SQL replay.
pg_dump "$DATABASE_URL" -Fc -f "$DUMP_FILE"

echo "[$(date -Iseconds)] Backup complete: $(du -h "$DUMP_FILE" | cut -f1)"

echo "[$(date -Iseconds)] Pruning backups older than ${RETENTION_DAYS} days"
find "$BACKUP_DIR" -name 'kiosk-platform-*.dump' -mtime "+${RETENTION_DAYS}" -delete

echo "[$(date -Iseconds)] Done."
